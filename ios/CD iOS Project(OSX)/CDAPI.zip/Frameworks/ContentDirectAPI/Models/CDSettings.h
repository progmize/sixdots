//
//  CHSettings.h
//  Chicago
//
//  Created by Brian Cooke on 9/7/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CDSettings : NSObject {

}

@property (nonatomic, weak) NSString *deviceAuthenticationKey;
@property (nonatomic, weak) NSString *subscriberID;
@property (nonatomic, strong) NSString *loginName;

+ (CDSettings *) sharedCDSettings;
- (void) removeSubscriberInfo;
- (NSString *)deviceIDForLogin:(NSString *)aLogin;
- (void)setDeviceID:(NSString *)aDeviceID forLogin:(NSString *)aLogin;

@end
