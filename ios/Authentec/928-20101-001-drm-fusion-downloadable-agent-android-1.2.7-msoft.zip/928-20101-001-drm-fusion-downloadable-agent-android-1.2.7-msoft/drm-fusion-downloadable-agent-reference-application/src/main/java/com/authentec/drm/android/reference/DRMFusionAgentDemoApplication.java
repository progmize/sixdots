package com.authentec.drm.android.reference;

import android.app.Application;

/**
 * @author AuthenTec Inc.
 */
public class DRMFusionAgentDemoApplication extends Application
{
    private String TAG = "DRMFusionAgentDemoApplication";

    @Override
    public void onCreate()
    {
        super.onCreate();
        DRMAgentDelegate.intialize(this);
    }

}
