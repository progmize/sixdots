//
// CHLoginViewController.m
// Chicago
//
// Created by Brian Cooke on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHLoginViewController.h"
#import "TKLabelSwitchCell.h"
#import "TKLabelTextFieldCell.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"
#import "CHForgotPasswordViewController.h"
#import "CHUpdateTempPasswordViewController.h"
#import "CHSettings.h"

enum {
  kSigninSection,
  kSigninButtonSection,
  kButtonsSection,
  kSectionCount
};


@interface CHLoginViewController (private)
- (void)moveTextViewForKeyboard:(NSNotification *)aNotification up:(BOOL)up;
- (BOOL)deviceHasBeenRegisteredPreviously;
@end

@implementation CHLoginViewController

@synthesize cancelButton = ch_cancelButton;
@synthesize tableView = ch_tableView;
@synthesize progressHUD = ch_progressHUD;
@synthesize rememberSwitchCell = ch_rememberSwichCell;
@synthesize usernameCell = ch_usernameCell; 
@synthesize passwordCell = ch_passwordCell;
@synthesize delegate = ch_delegate;

- (void)cleanup {
  ch_cancelButton = nil;

  ch_tableView = nil;

  ch_rememberSwitchCell = nil;

  ch_usernameCell = nil;

  ch_passwordCell = nil;
}


- (void)viewDidUnload {
  [super viewDidUnload];
  [self cleanup];

  [[NSNotificationCenter defaultCenter] removeObserver:self];
}


- (void)dealloc {
  [self cleanup];
}


- (void)didReceiveMemoryWarning {
  [super didReceiveMemoryWarning];
}


- (id)init {
  if ((self = [super initWithNibName:@"CHLoginView" bundle:nil])) {
    isUpdatingTemporaryPassword = NO;
  }

  return self;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  return YES;
}


- (void)viewDidLoad {
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"ORDER_PROCESS_BILLING_CANCEL", @"Cancel")
                                                                             style:UIBarButtonItemStyleBordered
                                                                            target:self
                                                                            action:@selector(cancel:)];
	
  self.title = NSLocalizedString(@"CONTROL_CREDENTIAL_LOGIN", @"Login");
  
	self.view.backgroundColor = kCHViewBackgroundColor;
  self.tableView.backgroundColor = kCHTableViewBackgroundColor;
  /*
    UILabel *header = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, 320, 44.0)];
  header.text                    = NSLocalizedString(@"CONTROL_CREDENTIAL_LOGIN", @"Login");
  header.textAlignment           = UITextAlignmentCenter;
  header.backgroundColor         = [UIColor clearColor];
  header.textColor               = [UIColor whiteColor];
  header.font                    = [UIFont boldSystemFontOfSize:18.0];
  self.tableView.tableHeaderView = header;
  [header release];]
   */

  self.rememberSwitchCell = [[TKLabelSwitchCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"loginRememberMeCell"];
  self.rememberSwitchCell.label.text = NSLocalizedString(@"LOGIN_REMEMBER_TEXT", @"Remember");
  [self.rememberSwitchCell.switcher addTarget:self action:@selector(rememberMeChanged:) forControlEvents:UIControlEventValueChanged];

  // Default to Remember
  self.rememberSwitchCell.switcher.on = YES;

  self.usernameCell                              = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"loginUsernameCell"];
  self.usernameCell.label.text                   = NSLocalizedString(@"CONTROL_LOGIN_FORM_USERNAME", @"username");
  self.usernameCell.field.autocapitalizationType = UITextAutocapitalizationTypeNone;
  self.usernameCell.field.autocorrectionType     = UITextAutocorrectionTypeNo;
  self.usernameCell.field.returnKeyType          = UIReturnKeyNext;
  self.usernameCell.field.delegate               = self;

  self.passwordCell                       = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"loginPasswordCell"];
  self.passwordCell.label.text            = NSLocalizedString(@"CONTROL_LOGIN_FORM_PASSWORD", @"password");
  self.passwordCell.field.secureTextEntry = YES;
  self.passwordCell.field.returnKeyType   = UIReturnKeySend;
  self.passwordCell.field.delegate        = self;

  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(keyboardWillShow:)
                                               name:UIKeyboardWillShowNotification
                                             object:self.view.window];
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(keyboardWillHide:)
                                               name:UIKeyboardWillHideNotification
                                             object:self.view.window];
  keyboardIsShown = NO;
  
  shouldRegisterAndRememberTheDevice = self.rememberSwitchCell.switcher.on;
}


- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];

	self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
  // Load initial state of remember me
  [self rememberMeChanged:nil];
  
  if ([[CHSettings sharedCHSettings].loginName length] > 0) {
    self.usernameCell.field.text = [CHSettings sharedCHSettings].loginName;
  }
}


- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];

  if (isUpdatingTemporaryPassword) {
    isUpdatingTemporaryPassword = NO;
    // resume where we left off
    [self loginCompletedWithSessionID:[CDLockerAppDelegate sharedCDClient].sessionID usingTemporaryPassword:NO];
  }
}


- (void)viewDidDisappear:(BOOL)animated {
  [super viewDidDisappear:animated];

  // make sure we're not the delegate anymore
  if ([CDLockerAppDelegate sharedCDClient].delegate == self) {
    [CDLockerAppDelegate sharedCDClient].delegate = nil;
  }
}


#pragma mark -
#pragma mark actions
- (IBAction)cancel:(id)sender {
  [self.navigationController dismissModalViewControllerAnimated:YES];
  
  if ([self.delegate respondsToSelector:@selector(loginCancelled)]) {
    [self.delegate loginCancelled];
  }
}


- (IBAction)rememberMeChanged:(id)sender {
  shouldRegisterAndRememberTheDevice = self.rememberSwitchCell.switcher.on;
}


- (IBAction)login:(id)sender {
  registrationTries = 0;

  [self.usernameCell.field resignFirstResponder];
  [self.passwordCell.field resignFirstResponder];

  if ((self.passwordCell.field.text == nil) || (self.usernameCell.field.text == nil)) {
    [Fault showWithTitle:nil andMessage:NSLocalizedString(@"ERROR_MESSAGE_MISSING_LOGIN_FIELDS", @"Both username and password are required. Please fill in these fields and try again")];
    return;
  }
  
  // set the device ID for the username entered.
  // even if it's nil, that's good. because that will force us to register (if they want that).
  if ([[CDLockerAppDelegate sharedCDClient].loginName isEqualToString:self.usernameCell.field.text] == NO) 
  {
    [[CHSettings sharedCHSettings] removeSubscriberInfo];
    [CDLockerAppDelegate sharedCDClient].deviceID = nil;
  } 
  else if (shouldRegisterAndRememberTheDevice) 
  {
    [CDLockerAppDelegate sharedCDClient].deviceID = [[CHSettings sharedCHSettings] deviceIDForLogin:self.usernameCell.field.text];
  } 
  else 
  {
    [[CHSettings sharedCHSettings] setDeviceID:nil forLogin:self.usernameCell.field.text];
  }

  CHAPIOperation *op = [CHAPIOperation operationToLoginWithLogin:self.usernameCell.field.text password:self.passwordCell.field.text];
  op.delegate = self;
  [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];

  self.progressHUD.labelText = NSLocalizedString(@"AUTHENTICATION_TEXT", @"Authenticating...");
  [self.progressHUD show:YES];
}


#pragma mark -
#pragma mark tableview datasource & delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return kSectionCount;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  switch (section) {
    case kSigninSection:
      return 3;

    case kSigninButtonSection:
      return 1;

    case kButtonsSection:
      return 2;
  }
  return 0;
}


- (UITableViewCell *)signinCell:(NSInteger)row {
  switch (row) {
    case 0:
      //NSLog(@"%@", self.usernameCell);
      return self.usernameCell;

    case 1:
      //NSLog(@"%@", self.passwordCell);
      return self.passwordCell;

    case 2:
      //NSLog(@"%@", self.rememberSwitchCell);
      return self.rememberSwitchCell;
  }
  return nil;
}


- (UITableViewCell *)signinButtonCell:(NSInteger)row {
  static NSString *cellID = @"CHLoginButtonCells";
  UITableViewCell *cell   = [self.tableView dequeueReusableCellWithIdentifier:cellID];

  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
  }

  cell.textLabel.text          = NSLocalizedString(@"SIGN_IN_BUTTON_TEXT", @"Sign In");
  cell.accessoryType           = UITableViewCellAccessoryNone;
  cell.textLabel.textAlignment = UITextAlignmentCenter;

  return cell;
}


- (UITableViewCell *)buttonCell:(NSInteger)row {
  static NSString *cellID2 = @"CHLoginButtonCells2";
  UITableViewCell *cell    = [self.tableView dequeueReusableCellWithIdentifier:cellID2];

  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID2];
  }

  switch (row) {
    case 0:
      cell.textLabel.text          = NSLocalizedString(@"FORGOT_PASSWORD_BUTTON_TEXT", @"Forgot Password");
      cell.accessoryType           = UITableViewCellAccessoryDisclosureIndicator;
      cell.textLabel.textAlignment = UITextAlignmentLeft;
      break;

    case 1:
      cell.textLabel.text          = NSLocalizedString(@"CREATE_ACCOUNT_BUTTON_TEXT", @"Create Account");
      cell.accessoryType           = UITableViewCellAccessoryDisclosureIndicator;
      cell.textLabel.textAlignment = UITextAlignmentLeft;
      break;
  }

  return cell;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  switch (indexPath.section) {
    case kSigninSection:
      return [self signinCell:indexPath.row];

    case kSigninButtonSection:
      return [self signinButtonCell:indexPath.row];

    case kButtonsSection:
      return [self buttonCell:indexPath.row];
  }
  return nil;
}


- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == kSigninSection) {
    return nil;
  }

  return indexPath;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  switch (indexPath.section) {
    case kSigninButtonSection:
      [self login:self];
      [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
      break;

    case kButtonsSection:

      if (indexPath.row == 0) {
        CHForgotPasswordViewController *fpvc = [[CHForgotPasswordViewController alloc] initWithStyle:UITableViewStyleGrouped];
        [self.navigationController pushViewController:fpvc animated:YES];
      } else if (indexPath.row == 1) {
        //TODO: link to website?
      }

      // cause for some reason doing this in viewWillAppear doesn't work when
      // the keyboard was rolled up *ss*
      [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];

      break;
  }
}


#pragma mark -
#pragma mark overloaded accessors
- (MBProgressHUD *)progressHUD {
  if (ch_progressHUD) {
    return ch_progressHUD;
  }

  ch_progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
  [self.view addSubview:ch_progressHUD];

  return ch_progressHUD;
}


#pragma mark -
#pragma mark keyboard management
- (void)keyboardWillShow:(NSNotification *)aNotification {
  [self moveTextViewForKeyboard:aNotification up:YES];
}


- (void)keyboardWillHide:(NSNotification *)aNotification {
  [self moveTextViewForKeyboard:aNotification up:NO];
}


- (void)moveTextViewForKeyboard:(NSNotification *)aNotification up:(BOOL)up {
  NSDictionary *userInfo = [aNotification userInfo];

  // Get animation info from userInfo
  NSTimeInterval       animationDuration;
  UIViewAnimationCurve animationCurve;


  [[userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey] getValue:&animationCurve];
  [[userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey] getValue:&animationDuration];


  // Animate up or down
  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:animationDuration];
  [UIView setAnimationCurve:animationCurve];

  CGRect newFrame = self.tableView.frame;

  CGRect keyboardEndFrame;

  if (UIInterfaceOrientationIsPortrait([self interfaceOrientation])) {
    keyboardEndFrame = CGRectMake(0, 264, 320, 216);
    CGRect keyboardFrame = [self.view convertRect:keyboardEndFrame toView:nil];

    newFrame.size.height -= keyboardFrame.size.height * (up ? 1 : -1);
    self.tableView.frame  = newFrame;
  } else {
    CGFloat adjustmentHeight = 70.0;
    newFrame.size.height -= adjustmentHeight * (up ? 1 : -1);
    self.tableView.frame  = newFrame;
  }

  [UIView commitAnimations];

  [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:1] atScrollPosition:UITableViewScrollPositionBottom animated:YES];
}


#pragma mark -
#pragma mark UITextFieldDelegate
// ------------------------------------------------------------------------------
// textFieldShouldReturn:
// ------------------------------------------------------------------------------
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
  if (textField == self.usernameCell.field) {
    [self.passwordCell.field becomeFirstResponder];
  } else if (textField == self.passwordCell.field) {
    [textField resignFirstResponder];
    [self login:self];
  }

  return YES;
}


#pragma mark -
#pragma mark CDClientDelegate


- (void)getUserLibrary 
{
	// Get the subscriber products
	CHAPIOperation *op = [CHAPIOperation operationToRetrieveSubscriberProducts];
	op.delegate = self;
	[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}


- (void)dismissView {
  [self.progressHUD hide:YES];
  [self.delegate loginCompletedWithLogin:self.usernameCell.field.text password:self.passwordCell.field.text];
  [self dismissModalViewControllerAnimated:YES];
}


- (BOOL)deviceHasBeenRegisteredPreviously {
  // Assume that user has just logged in.
  // We can detect this if:
  // saved deviceID is not NULL and saved subscriberID equals current subscriberID
  return [[CDLockerAppDelegate sharedCDClient] deviceHasBeenRegisteredPreviously];
}


- (void)loginCompletedWithSessionID:(NSString *)sessionID usingTemporaryPassword:(BOOL)wasTempPass {
  if (wasTempPass) {
    isUpdatingTemporaryPassword = YES;
    // prompt for a new password
    CHUpdateTempPasswordViewController *uvc = [[CHUpdateTempPasswordViewController alloc] initWithCurrentPassword:self.passwordCell.field.text];
    UINavigationController             *nc  = [[UINavigationController alloc] initWithRootViewController:uvc];
    [self presentModalViewController:nc animated:YES];
    return;
  }

  if (shouldRegisterAndRememberTheDevice) {
    [CHSettings sharedCHSettings].loginName    = self.usernameCell.field.text;
    [CHSettings sharedCHSettings].subscriberID = [CDLockerAppDelegate sharedCDClient].subscriberID;
  } else if (shouldRegisterAndRememberTheDevice == NO && [self deviceHasBeenRegisteredPreviously]) {
    // unreg first. we'll be back.
    CHAPIOperation *op = [CHAPIOperation operationToUnregisterDeviceWithSubscriberID:[CDLockerAppDelegate sharedCDClient].subscriberID];
    op.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
    return;
  }


  // now we getUserLibrary, then it does some stuff.
  [self getUserLibrary];
}


- (void)loginFailedWithFault:(Fault *)fault {
  [Fault showWithTitle:NSLocalizedString(@"ERROR_AUTHENTICATION_FAILED_TEXT", @"Authentication Failure") andMessage:NSLocalizedString(@"ERROR_MESSAGE_LOGIN_NOTAUTHENTICATED", @"Your username and password were not correct.")];
  [self.progressHUD hide:YES];
}


- (void)deviceRegisteredWithDeviceID:(NSString *)deviceID deviceAuthenticationKey:(NSString *)deviceAuthenticationKey subscriberID:(NSString *)subscriberID {
  [[CHSettings sharedCHSettings] setDeviceID:deviceID forLogin:self.usernameCell.field.text];
  [CHSettings sharedCHSettings].deviceAuthenticationKey = deviceAuthenticationKey;
  [CHSettings sharedCHSettings].subscriberID            = subscriberID;

    [self dismissView];
	//NSLog(@"deviceID:%@", [[CHSettings sharedCHSettings] deviceIDForLogin:self.usernameCell.field.text]);
  //NSString *savedDeviceAuthenticationKey = [CHSettings sharedCHSettings].deviceAuthenticationKey;
  //NSLog(@"deviceAuthenticationKey (first 4 characters):%@", [savedDeviceAuthenticationKey substringToIndex:4]);

}


- (void)retrievedSubscriberProducts:(NSArray *)products {
  // Now register the device if shouldRegisterAndRememberTheDevice is set to YES
  if (shouldRegisterAndRememberTheDevice) {
    // If device has been registered previously for the same subscriberID, then don't register again.
    if ([self deviceHasBeenRegisteredPreviously]) {
      // Don't register again.
        [self dismissView];
    } else {
      // Register.
      CHAPIOperation *op = [CHAPIOperation operationToRegisterDevice];
      op.delegate = self;
      [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
      registrationTries += 1;
    }
  }
}


- (void)retrievedSubscriberProductsFailedWithFault:(Fault *)aFault {
  // move on, don't bother them with this at this time.
  // call success.
  [self retrievedSubscriberProducts:[NSArray array]];
}


- (void)deviceRegistrationFailedWithFault:(Fault *)fault 
{
  if (registrationTries < 2) 
  {
	  // Unregister the device, first make sure the deviceID is the last we remembered for this user!
	  [CDLockerAppDelegate sharedCDClient].deviceID = [[CHSettings sharedCHSettings] deviceIDForLogin:self.usernameCell.field.text];
    
	  //NSLog(@"Would be setting %@", [[CHSettings sharedCHSettings] deviceIDForLogin:self.usernameCell.field.text]);
	  
	  CHAPIOperation *op = [CHAPIOperation operationToUnregisterDeviceWithSubscriberID:[CDLockerAppDelegate sharedCDClient].subscriberID];
	  op.delegate = self;
	  [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
	  
	  registrationTries += 1;
  } 
  else 
  {
	  // Already twice twice, just give up for now.
	  [Fault showWithTitle:NSLocalizedString(@"LOGIN_REGISTRATION_TEXT", @"Registration") andMessage:NSLocalizedString(@"ERROR_DEVICE_NOT_REMEMBERED", @"Your device could not be remembered.") andFault:fault];
	  [self.progressHUD hide:YES];
      [self dismissView];
  }
}


- (void)deviceUnregistrationSucceeded {
  if (shouldRegisterAndRememberTheDevice) {
    // Register the device now.
    CHAPIOperation *op = [CHAPIOperation operationToRegisterDevice];
    
    op.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
    registrationTries += 1;
  } else {
    [self login:self];
  }
}


- (void)deviceUnregistrationFailedWithFault:(Fault *)fault {
  [Fault showWithTitle:@"Registration" andMessage:@"Your device could not be remembered." andFault:fault];
  [self.progressHUD hide:YES];
}


@end
