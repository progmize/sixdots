//
// CHBaseProductListViewController.m
// Chicago
//
// Created by louie on 8/13/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHBaseProductListViewController.h"
#import "CHProductListCell.h"
#import "CHDetailsViewController.h"
#import "CDClient.h"

@implementation CHBaseProductListViewController

@synthesize products = ch_products, tableView = ch_tableView;

- (id)init {
    if ((self = [super init])) {
        [self registerForImageCacheNotifications];
        self.libraryItem = NO;
        self.loggedInRequired = NO; // default to no
        self.authenticatedRequired = NO;
    }
    
    return self;
}


- (id) initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        [self registerForImageCacheNotifications];
        self.libraryItem = NO;
        self.loggedInRequired = NO; // default to no
        self.authenticatedRequired = NO;
    }
    
    return self;  
}


- (void)dealloc {
    [self unregisterForImageCacheNotifications];
}

-(void)loadNextPage {
    
}


#pragma mark -
#pragma mark Tableview delegate and datasource

- (void)viewDidLoad {
    [super viewDidLoad];
    ch_tableView.dataSource = self;
    ch_tableView.delegate   = self;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self setBackgroundImage:[[CDLockerAppDelegate sharedAppDelegate] backgroundImage]];
	[self.tableView reloadData];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 130;
}


// ------------------------------------------------------------------------------
// tableView:cellForRowAtIndexPath:
// ------------------------------------------------------------------------------
- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"CHProdCell";
    
    /*
    if (indexPath.row == [self.products count]) {
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:nextCellID];
        
        if (cell == nil) {
            cell = [[[UITableViewCell alloc] initWithStyle:UITableViewStylePlain reuseIdentifier:nextCellID] autorelease];
        }
        
        cell.textLabel.text = [NSString stringWithFormat:@"Next 8 Products >>"];
        cell.selectionStyle          = UITableViewCellSelectionStyleNone;
        cell.textLabel.shadowColor   = [UIColor colorWithWhite:0.20 alpha:1.];
        cell.textLabel.shadowOffset  = CGSizeMake(0., 1.);
        cell.textLabel.textColor     = [UIColor whiteColor];
        cell.textLabel.text          = [NSString stringWithFormat:NSLocalizedString(@"MEDIA_LIBRARY_NEXT_RESULTS", @"Next %d results"), 8];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        
        return cell;
    }
    else {
     */
        CHProductListCell * cell   = (CHProductListCell *)[aTableView dequeueReusableCellWithIdentifier:cellID];
        
        if (cell == nil) {
            cell = [[CHProductListCell alloc] initWithReuseIdentifier:cellID];
        }
        
        Product * product = [self.products objectAtIndex:indexPath.row];
        cell.delegate    = self;
        cell.libraryItem = [[CDLockerAppDelegate sharedCDClient] doesUserOwnProduct:product];
        [cell setProduct:product];
        
        return cell;
   // }
}


// ------------------------------------------------------------------------------
// tableView:numberOfRowsInSection:
// ------------------------------------------------------------------------------
- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section
{
    if (self.products == nil) {
        return 0;
    }
    
    return [self.products count];
}


// ------------------------------------------------------------------------------
// tableView:didSelectRowAtIndexPath:(NSIndexPath *)indexPath
// ------------------------------------------------------------------------------
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.products == nil) {
        return;
    } 
    
    CHDetailsViewController * details = [[CHDetailsViewController alloc] init];
    details.libraryItem = self.libraryItem;
    details.product     = [self.products objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:details animated:YES];
    
}


- (void)showDetailsForProduct:(Product *)product {
    CHDetailsViewController * detail = [[CHDetailsViewController alloc] init];
    
    detail.libraryItem = self.libraryItem;
    detail.product     = product;
    [self.navigationController pushViewController:detail animated:YES];
}


#pragma mark -
#pragma mark ImageCache notifications
- (void)imageWasDownloaded:(id)object {
    [ch_tableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:NO];    
}


@end
