var interface_d_a_content_info =
[
    [ "isProtected", "interface_d_a_content_info.html#a4f4abddb5a485d7ab7e9766a233cdb3b", null ],
    [ "rightsStatus", "interface_d_a_content_info.html#adb5cfff057c1b6abc7328b171714553b", null ],
    [ "licenseStartDate", "interface_d_a_content_info.html#aa3c7f54b096b1c95946fd2a5ccb0e842", null ],
    [ "licenseEndDate", "interface_d_a_content_info.html#a8a2d69d2840f68e85032ef53e1ee03a5", null ],
    [ "rightsExpireAfterFirstUse", "interface_d_a_content_info.html#a48710b144c69b941e6ca515be5e7a1a7", null ],
    [ "audioTrackNames", "interface_d_a_content_info.html#ab4c2f0678f58903e8b8f1e172eb3c961", null ]
];