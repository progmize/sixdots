//
// CHBaseViewController.h
// Chicago
//
// Created by louie on 8/13/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHLoginViewController.h"
#import "PurchasProductDelegate.h"


@interface CHBaseViewController : UIViewController <CDClientDelegate, PurchasProductDelegate, CHLoginViewControllerDelegate> {
    Product     * productToPurchase;
    BOOL          ch_libraryItem;
    UIImageView * ch_backgroundView;
}

@property (nonatomic, strong) UIImageView * backgroundView;
@property (strong) Product                * productToPurchase;
@property (nonatomic, assign) BOOL          libraryItem;

- (void)setBackgroundImage:(UIImage *)bgImage;
- (void)registerForImageCacheNotifications;
- (void)unregisterForImageCacheNotifications;
- (BOOL)loggedIn;
- (BOOL)authenticated;
- (void)showCSGBranding;
- (void)showLogoBranding;
- (void)showLoginView;
@end
