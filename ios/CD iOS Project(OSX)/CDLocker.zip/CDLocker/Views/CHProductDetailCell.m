//
// CHProductDetailView.m
// Chicago
//
// Created by Derr on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHProductDetailCell.h"
#import "Product.h"
#import "ProductCategory.h"
#import "ImageCache.h"
#import "CHStarsView.h"

@interface CHProductDetailCell (Private)
- (void)showThumbnailImage;
@end


// these are constants for the flip animation
static const CGRect frontViewFramePort = { { 122.f, 12.f }, { 75.f, 105.f } };
static const CGRect backViewFramePort = { { 58, 19 }, { 204, 262 } };
static const CGRect licensingBgFramePort = { { -5, -6 }, { 214, 273 } };
static const CGRect licensingTextFramePort = { { 13, 13 }, { 188, 222 } };
static const CGRect hideButtonFramePort = { { 164, 223 }, { 37, 36 } };
static const CGRect detailsTextFramePort = { { 20.0, 155.0 }, { 280.0, 60.0} };

static const CGRect frontViewFrameLand = { { 122.f, 12.f }, { 75.f, 105.f } };
static const CGRect backViewFrameLand = { { 58, 19 }, { 204, 262 } };
static const CGRect licensingBgFrameLand = { { -5, -6 }, { 214, 273 } };
static const CGRect licensingTextFrameLand = { { 13, 13 }, { 188, 222 } };
static const CGRect hideButtonFrameLand = { { 164, 223 }, { 37, 36 } };
static const CGRect detailsTextFrameLand = { { 20.0, 155.0 }, { 440.0, 60.0} };

static CGSize maxDescriptionPort = { 280.f, 60.f };
static CGSize maxDescriptionLand = { 440.f, 60.f };

@implementation CHProductDetailCell

@synthesize thumbnailURL;

- (id)init {
    if ((self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"DetailCell"])) {
#include "CHProductDetailViewLayout.h"
        ch_title             = label6;
        ch_time              = label9;
        ch_guidence          = label8;
        ch_rating            = view34;
        ch_details           = label18;
        ch_priceButton       = button10;
        ch_showLicenseButton = button24;
        imageview21.image    = [UIImage imageNamed:@"background.png"];
        imageview22.image    = [UIImage imageNamed:@"seperator.png"];
        [self.contentView addSubview:view3];
        
        ch_licensingBackground                  = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"overlay.png"]];
        ch_licensingBackground.contentMode      = UIViewContentModeScaleToFill;
        ch_licensingBackground.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        ch_licensingBackground.opaque           = NO;
        
        
        [ch_priceButton setBackgroundImage:[UIImage imageNamed:@"button.png"] forState:UIControlStateNormal];
        [ch_priceButton addTarget:self action:@selector(purchaseProduct) forControlEvents:UIControlEventTouchUpInside];
        [ch_showLicenseButton addTarget:self action:@selector(showLicense) forControlEvents:UIControlEventTouchUpInside];
        [ch_showLicenseButton setBackgroundImage:[UIImage imageNamed:@"button_usage.png"] forState:UIControlStateNormal];
        
        
        ch_hideLicensingButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [ch_hideLicensingButton setImage:[UIImage imageNamed:@"button_close.png"] forState:UIControlStateNormal];
        [ch_hideLicensingButton addTarget:self action:@selector(hideLicense) forControlEvents:UIControlEventTouchUpInside];
		
        if (UIInterfaceOrientationIsPortrait([[UIDevice currentDevice] orientation])) {
            ch_image1                    = [[UIImageView alloc] initWithFrame:frontViewFramePort];
            ch_licensingBackground.frame = licensingBgFramePort;
            ch_licensing                 = [[UILabel alloc] initWithFrame:licensingTextFramePort];
            ch_licenseView               = [[UIView alloc] initWithFrame:backViewFramePort];
            ch_hideLicensingButton.frame = hideButtonFramePort;
			ch_flippingParent           = [[CHFlippableView alloc] initWithFrame:frontViewFramePort];
        }
		else {
            ch_image1                    = [[UIImageView alloc] initWithFrame:frontViewFrameLand];
            ch_licensingBackground.frame = licensingBgFrameLand;
            ch_licensing                 = [[UILabel alloc] initWithFrame:licensingTextFrameLand];
            ch_licenseView               = [[UIView alloc] initWithFrame:backViewFrameLand];
            ch_hideLicensingButton.frame = hideButtonFrameLand;
			ch_flippingParent           = [[CHFlippableView alloc] initWithFrame:frontViewFrameLand];
		}
		
        ch_image1.autoresizesSubviews      = YES;
        ch_image1.autoresizingMask         = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        ch_flippingParent.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        ch_flippingParent.autoresizesSubviews      = YES;
        
        // build the flipping view
        ch_image1.contentMode = UIViewContentModeScaleToFill;
        
        ch_licensing.adjustsFontSizeToFitWidth = YES;
        ch_licensing.alpha                     = 1.000;
        ch_licensing.backgroundColor           = [UIColor colorWithWhite:1.000 alpha:0.000];
        ch_licensing.lineBreakMode             = UILineBreakModeTailTruncation;
        ch_licensing.font                      = [UIFont fontWithName:@"Helvetica" size:13];
        ch_licensing.minimumFontSize           = 13;
        ch_licensing.numberOfLines             = 25;
        ch_licensing.opaque                    = NO;
        ch_licensing.shadowColor               = [UIColor colorWithRed:0.138 green:0.138 blue:0.138 alpha:1.000];
        ch_licensing.shadowOffset              = CGSizeMake(0.0, 1.0);
        ch_licensing.text                      = @"";
        ch_licensing.textAlignment             = UITextAlignmentLeft;
        ch_licensing.textColor                 = [UIColor colorWithRed:1.000 green:1.000 blue:1.000 alpha:1.000];
        
        ch_licenseView.backgroundColor = [UIColor colorWithWhite:0.11 alpha:1.];
        
        ch_flippingParent.frontView = ch_image1;
        ch_flippingParent.backView  = ch_licenseView;
        ch_flippingParent.delegate  = self;
        [view3 addSubview:ch_flippingParent];
        
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    return self;
}

- (void)setProduct:(Product *)theProduct inCategory:(ProductCategory *)theCategory {
    ch_title.text = theProduct.name;
    
    CGRect newTextFrame = detailsTextFramePort;
    CGSize maxDescription = maxDescriptionPort;
    if (UIInterfaceOrientationIsLandscape([[UIDevice currentDevice] orientation])) {
        newTextFrame = detailsTextFrameLand;
        maxDescription = maxDescriptionLand;
    }
    
    newTextFrame.size =	[theProduct.shortDescription sizeWithFont:ch_details.font
                                                constrainedToSize:maxDescription
                                                    lineBreakMode:UILineBreakModeWordWrap];
    ch_details.frame = newTextFrame;
    ch_details.text  = theProduct.shortDescription;
    
    ch_rating.stars = theProduct.peerRating;
    
	ch_guidence.text = [theProduct getGuidanceRatingLabel];
	
	if (self.libraryItem) 
	{
        if (theProduct.isSubscription) 
		{
            [ch_priceButton setTitle:NSLocalizedString(@"LIBRARY_SUBSCRIBED_BUTTON_TEXT", @"Subscribed") forState:UIControlStateNormal];
        } 
		else 
		{
            [ch_priceButton setTitle:NSLocalizedString(@"DIALOG_POPUP_PURCHASE_SUCCESS_VIEW_BUTTON", @"View") forState:UIControlStateNormal];
        }
    } 
	else if ([theProduct.pricingPlanID isEqual:@"1832"] && [[CDLockerAppDelegate sharedCDClient] loggedIn]) 
	{
        [ch_priceButton setTitle:@"View" forState:UIControlStateNormal];
	} 
	else if([theProduct.orderingType isEqualToString:@"BrowseOnlyNotOrderable"])
	{
		ch_priceButton.hidden = true;
	}
	else 
	{
        [ch_priceButton setTitle:[theProduct formattedPrice] forState:UIControlStateNormal];
    }
    
    ch_showLicenseButton.enabled = theProduct.licensingText != nil;
    //ch_priceButton.enabled = (theProduct.licensingText != nil && (theProduct.isSubscription == NO || self.libraryItem == NO));
	if( (theProduct.licensingText != nil && (theProduct.isSubscription == NO || self.libraryItem == NO)) )
	{
		ch_priceButton.enabled = true;
	}
	else
	{
		ch_priceButton.enabled = false;
	}
    //NSLog(@"enabled? %d, %d", ch_priceButton.enabled, ch_showLicenseButton.enabled);
    ch_licensing.text      = theProduct.licensingText;
    
    // Set the runtime
    if (theProduct.runtime != nil) {
        ch_time.text = [NSString stringWithFormat:@"%@ min.", theProduct.runtime];
    } else {
        // If no runtime, then blank it out so it is not the default 29:37.
        ch_time.text = @"";
    }
    
    NSURL *thumbURL = [NSURL URLWithString:theProduct.thumbnailURL];
    UIImage *thumbnailImage = [UIImage imageWithData:[NSData dataWithContentsOfURL:thumbURL]];
    ch_image1.image = thumbnailImage;
    
    // Set instance variable
    ch_product = theProduct;
}


- (void)dealloc {
    ch_image1 = nil;
    ch_title = nil;
    ch_time = nil;
    ch_guidence = nil;
    ch_rating = nil;
    ch_licensing = nil;
    ch_details = nil;
    ch_priceButton = nil;
    ch_showLicenseButton = nil;
    ch_licenseView = nil;
    ch_flippingParent = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}


#pragma mark -
#pragma mark flipping view delegate

- (void)flippableView:(CHFlippableView *)flipView finishedFlippingToView:(UIView *)view {
    if (view == ch_image1 ) {
        ch_showLicenseButton.enabled = YES;
    }	else {
        [view addSubview:ch_licensingBackground];
        ch_licenseView.backgroundColor = [UIColor clearColor];
        ch_image1.alpha                = 0.;
        [view addSubview:ch_licensing];
        [view addSubview:ch_hideLicensingButton];
        ch_hideLicensingButton.alpha = 0.;
        
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:kFlipImageDuration];
        ch_licensing.alpha           = 1.;
        ch_hideLicensingButton.alpha = 1.;
        [UIView commitAnimations];
    }
}


- (NSTimeInterval)flippableView:(CHFlippableView *)flipView timeIntervalToWaitBeforFlippingToView:(UIView *)view {
    if (view == ch_image1 ) { // hiding the backView
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:kFlipImageDuration];
        [UIView setAnimationDelegate:self];
        [UIView setAnimationDidStopSelector:@selector(removeLicensing)];
        ch_licensing.alpha           = 0.;
        ch_hideLicensingButton.alpha = 0.;
        [UIView commitAnimations];
        
        return kFlipImageDuration;
    } else {
        ch_showLicenseButton.enabled = NO;
        return 0.;
    }
}


- (void)removeLicensing {
    ch_licenseView.backgroundColor = [UIColor colorWithWhite:0.11 alpha:1.];
    ch_image1.alpha                = 1.;
    [ch_licensingBackground removeFromSuperview];
    [ch_hideLicensingButton removeFromSuperview];
}


#pragma mark Actions
- (void)purchaseProduct {
    //NSLog(@"CHProductDetailCell -purchaseProduct:%@", ch_product.name);
    [self.delegate purchaseProduct:ch_product];
    //[self purchaseProduct];
}


- (void)hideLicense {
    [UIView beginAnimations:nil context:nil];
    ch_licenseView.backgroundColor = [UIColor colorWithWhite:0.11 alpha:1.];
    [UIView commitAnimations];
    [ch_flippingParent showFrontView];
}


- (void)showLicense {
    [ch_flippingParent showBackView];
}


@synthesize delegate, libraryItem = ch_libraryItem;
@end
