//
// CHVideoViewController.h
// Chicago
//
// Created by Derr on 8/19/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"
#import "MBProgressHUD.h"
#import "CHBaseViewController.h"

@class Product;
@class MPMoviePlayerController;

@interface CHVideoViewController : CHBaseViewController <CDClientDelegate> {
	MBProgressHUD           * ch_progressHUD;
	Product                 * ch_product;
	MPMoviePlayerController * ch_moviePlayerController;
	BOOL                      popWhenAppears;
	UIDeviceOrientation	oldDeviceOrientation;
	
	NSTimer *watchdogTimer;
	NSInteger watchdogCounter;
}

@property (nonatomic, strong) MBProgressHUD           * progressHUD;
@property (nonatomic, strong) Product                 * product;
@property (nonatomic, strong) MPMoviePlayerController * moviePlayerController;

- (void)petWatchdog;

@end
