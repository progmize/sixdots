//
// CHForgotPasswordViewController.h
// Chicago
//
// Created by Brian Cooke on 8/20/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"

@class TKLabelTextFieldCell;
@class MBProgressHUD;

@interface CHForgotPasswordViewController : UITableViewController<CDClientDelegate> {
  TKLabelTextFieldCell * ch_usernameCell;
  MBProgressHUD        * ch_progressHUD;
}

@property (nonatomic, strong) TKLabelTextFieldCell * usernameCell;
@property (nonatomic, strong) MBProgressHUD        * progressHUD;

@end
