//
// CHBrowseCategoryViewController.m
// Chicago
//
// Created by Derr on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHBrowseCategoryViewController.h"
#import "ProductCategory.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"
#import "MBProgressHUD.h"
#import "CHPlainTableViewCell.h"
#import "CHConfirmInAppPurchaseViewController.h"
#import "CHConfirmPurchaseViewController.h"
#import "CHProductListCell.h"
#import "CHDetailsViewController.h"

#define kProductsPerPage 5

@implementation CHBrowseCategoryViewController

- (id)init
{
    if ((self = [super initWithNibName:@"CHBrowseCategoryView" bundle:nil])) {}
    
    return self;
}

// ------------------------------------------------------------------------------
// cleanup
// ------------------------------------------------------------------------------
- (void)cleanup
{
    ch_progressHUD = nil;
    
    ch_tableView = nil;
}

// ------------------------------------------------------------------------------
// dealloc
// ------------------------------------------------------------------------------
- (void)dealloc
{
    [self cleanup];
    
    
    ch_products = nil;
    
}


- (void)viewDidLoad {
    self.currentPage = 0;
    self.pageToLoad = 1;
	[self showCSGBranding];
	self.view.backgroundColor = kCHViewBackgroundColor;
	self.tableView.backgroundColor = kCHTableViewBackgroundColor;
	self.tableView.separatorColor = kCHTableViewBackgroundColor;
    self.title = self.category.name;
}


- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
	[self.navigationController setNavigationBarHidden:NO animated:animated];
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:animated];
    
    if (self.products == nil) {
        // show loading....
        self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
        [self.view addSubview:self.progressHUD];
        
        self.progressHUD.labelText = NSLocalizedString(@"MEDIA_VIDEO_LOADING", @"Loading...");
        [self.progressHUD show:YES];
        
        // request the products for this category
        // get categories
        //CHAPIOperation * op = [CHAPIOperation operationToRetrieveProductsByCategoryID:self.category.categoryID limit:100];
        
        // get categories, paginated version
        CHAPIOperation *op = [CHAPIOperation operationToRetrieveProductsByCategoryID:self.category.categoryID page:self.pageToLoad itemsPerPage:kProductsPerPage];
        op.delegate = self;
        [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
    }
}

- (void)showCSGBranding {
    // Show the CSG branding in upper right corner.
    UIImage *csgBrandingImage = [UIImage imageNamed:@"cd-logo.png"];
    
    //  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:csgBrandingImage style:UIBarButtonItemStyleBordered target:nil action:nil];  
    UIImageView *brandingImageView = [[UIImageView alloc] initWithImage:csgBrandingImage];
    UIBarButtonItem *brandingButtonItem = [[UIBarButtonItem alloc] initWithCustomView:brandingImageView];
    self.navigationItem.rightBarButtonItem = brandingButtonItem;
}

-(void)loadPreviousPage {
    //NSLog(@"browseCategoryView - loadPreviousPage");
    //self.currentPage--;
    self.pageToLoad = self.currentPage -1;
    CHAPIOperation *op = [CHAPIOperation operationToRetrieveProductsByCategoryID:self.category.categoryID page:self.pageToLoad itemsPerPage:kProductsPerPage];
    op.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}

-(void)loadNextPage {
    //NSLog(@"browseCategoryView - loadNextPage");
    if (self.currentPage < self.pageCount) {
        //self.currentPage++;
        self.pageToLoad = self.currentPage + 1;
        CHAPIOperation *op = [CHAPIOperation operationToRetrieveProductsByCategoryID:self.category.categoryID page:self.pageToLoad itemsPerPage:kProductsPerPage];
        op.delegate = self;
        [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
    }
}

-(BOOL)isNextButtonAtIndexPath:(NSIndexPath *)indexPath {
    if (self.currentPage == 1 && indexPath.row == [self.products count]) {
        // if the last row on page 1
        return YES;
    } 
    else if (self.currentPage == self.pageCount) {
        // if the last page
        return NO;
    }
    else if (self.currentPage > 1 && [self.products count] > 0 && indexPath.row == [self.products count] + 1) {
        // if the last row on a following page *with* products
        return YES;
    }
    else {
        return NO;
    }

}

-(BOOL)isPreviousButtonAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0 && self.currentPage > 1) {
        // if the first row after the first page
        return YES;
    } 
    else {
        return NO;
    }

}

#pragma mark UITableViewDataSource methods

// ------------------------------------------------------------------------------
// tableView:cellForRowAtIndexPath:
// ------------------------------------------------------------------------------
- (UITableViewCell *)tableView:(UITableView *)aTableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"CHProdCell";
    static NSString *nextCellID = @"NextCellIdentifier";
    
    if ( [self isNextButtonAtIndexPath:indexPath] || [self isPreviousButtonAtIndexPath:indexPath] ) {
        UITableViewCell *cell = [aTableView dequeueReusableCellWithIdentifier:nextCellID];
        
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewStylePlain reuseIdentifier:nextCellID];
        }
        
        if ([self isPreviousButtonAtIndexPath:indexPath]) {
            cell.textLabel.text = [NSString stringWithFormat:NSLocalizedString(@"MEDIA_LIBRARY_PREVIOUS_RESULTS", @"Previous %d results"), kProductsPerPage];
            cell.contentView.backgroundColor = [UIColor darkGrayColor];
        } else {
            cell.textLabel.text = [NSString stringWithFormat:NSLocalizedString(@"MEDIA_LIBRARY_NEXT_RESULTS", @"Next %d results"), kProductsPerPage];
            cell.contentView.backgroundColor = [UIColor lightGrayColor];    
        }

        cell.selectionStyle          = UITableViewCellSelectionStyleNone;
        cell.textLabel.shadowColor   = [UIColor colorWithWhite:0.20 alpha:1.];
        cell.textLabel.shadowOffset  = CGSizeMake(0., 1.);
        cell.textLabel.textColor     = [UIColor whiteColor];
        cell.textLabel.textAlignment = UITextAlignmentCenter;
        
        return cell;
    }
    else {
        CHProductListCell * cell   = (CHProductListCell *)[aTableView dequeueReusableCellWithIdentifier:cellID];
        
        if (cell == nil) {
            cell = [[CHProductListCell alloc] initWithReuseIdentifier:cellID];
        }
        
        int selected = indexPath.row;
        if (self.currentPage > 1) {
            selected--;
        }
        Product * product = [self.products objectAtIndex:selected];
        cell.delegate    = self;
        cell.libraryItem = [[AppDelegate sharedCDClient] doesUserOwnProduct:product];
        [cell setProduct:product];
        
        return cell;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([self isNextButtonAtIndexPath:indexPath] || [self isPreviousButtonAtIndexPath:indexPath]) {
        return 44;
    }
    else {
        return 130;
    }
}

- (NSInteger)tableView:(UITableView *)aTableView numberOfRowsInSection:(NSInteger)section
{
    int rows = 0;
    if (self.currentPage > 1) {
        // show "Previous" row
        rows++;
    }
    if (self.currentPage != self.pageCount) {
        // show "Next" row
        rows++;
    }
    if ([self.products count] > 0) {
        // show product rows
        rows += [self.products count];
    }
    return rows;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self isPreviousButtonAtIndexPath:indexPath]) {
        // go to previous page
        [self loadPreviousPage];
    }
    else if ([self isNextButtonAtIndexPath:indexPath]) {
        //go to next page
        [self loadNextPage];
    } 
    else {
        CHDetailsViewController * details = [[CHDetailsViewController alloc] init];
        details.libraryItem = self.libraryItem;
        details.product     = [self.products objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:details animated:YES];
    }
}

#pragma mark -
#pragma mark CHBrowseCategoryViewController


- (void)productsRetrieved:(NSArray *)productArray {
    [self.progressHUD hide:YES];
    self.products = productArray;
    [self.tableView reloadData];
}

- (void)productRetrievalFailedWithFault:(Fault *)fault {
    [self.progressHUD hide:YES];
    [fault showWithTitle:@"Network error"];
}

// products are returned here when requested using pagination
- (void)fullTextSearchResults:(NSArray *)productArray pageCount:(int)pages{
    //NSLog(@"%d products returned, %d pages", [productArray count], pages);
    [self.progressHUD hide:YES];
    self.currentPage = self.pageToLoad;
    self.products = productArray;
    self.pageCount = pages;
    [self.tableView reloadData];
    NSIndexPath *top = [NSIndexPath indexPathForRow:0 inSection:0];
    if ([productArray count] > 0) {
        [self.tableView scrollToRowAtIndexPath:top atScrollPosition:UITableViewScrollPositionTop animated:YES];
    }
    else {
        //NSLog(@"NO subscriber products returned");
        CGFloat labelWidth = 300;
        CGFloat labelHeight = 100;
        CGRect labelRect = CGRectMake(self.view.frame.size.width / 2 - labelWidth/2, self.view.frame.size.height / 2 - labelHeight/2, labelWidth, labelHeight);
        UILabel *label = [[UILabel alloc] initWithFrame:labelRect];
        label.backgroundColor = [UIColor whiteColor];
        label.numberOfLines = 2;
        label.textAlignment = UITextAlignmentCenter;
        label.text = NSLocalizedString(@"CATEGORY_NO_ITEMS", @"No items were found for this category.");
        [self.view addSubview:label];
    }

    
}

// faults are returned here when requested using pagination
- (void)fullTextSearchFailedWithFault:(Fault *)fault {
    [self.progressHUD hide:YES];
    [fault showWithTitle:@"Network error"];
}

@synthesize progressHUD = ch_progressHUD, category = ch_category;
@synthesize currentPage;
@synthesize pageCount;
@synthesize pageToLoad;
@end
