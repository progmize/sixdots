//
//  ContentDirectAPI_ipadsimulator.h
//  ContentDirectAPI-ipadsimulator
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContentDirectAPI_ipadsimulator : NSObject

@end
