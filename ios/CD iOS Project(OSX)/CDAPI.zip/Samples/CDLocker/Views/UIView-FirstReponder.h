//
//  UIView-FirstReponder.h
//  Chicago
//
//  Created by louie on 8/11/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIView (FirstResponder)
- (UIView *)findFirstResponder;
@end
