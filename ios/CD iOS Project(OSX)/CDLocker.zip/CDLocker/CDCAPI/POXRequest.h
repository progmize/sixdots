//
//  POXRequest.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/28/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol POXClientDelegate;

@interface POXRequest : NSOperation {
  NSURL *urlEndpoint;
  NSDictionary *inputDictionary;
  id <POXClientDelegate> __unsafe_unretained delegate;
  
  NSMutableURLRequest *urlRequest;
  NSMutableData *data;
	NSInteger responseCode;

	BOOL isExecuting;
	BOOL isFinished;
}

@property (copy) NSURL *urlEndpoint;
@property (copy) NSDictionary *inputDictionary;
@property (unsafe_unretained) id <POXClientDelegate> delegate;

@end
