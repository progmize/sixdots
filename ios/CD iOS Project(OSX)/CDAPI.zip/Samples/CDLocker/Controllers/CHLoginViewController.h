//
// CHLoginViewController.h
// Chicago
//
// Created by Brian Cooke on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "CDClient.h"

@class TKLabelSwitchCell;
@class TKLabelTextFieldCell;


@protocol CHLoginViewControllerDelegate
@required
- (void)loginCompletedWithLogin:(NSString *)login password:(NSString *)password;

@optional
- (void)loginCancelled;
@end


@interface CHLoginViewController : UIViewController<UITableViewDelegate, UITableViewDataSource, CDClientDelegate, UITextFieldDelegate> {
  UIBarButtonItem *ch_cancelButton;
  UITableView     *ch_tableView;
  MBProgressHUD   *ch_progressHUD;

  TKLabelSwitchCell    *ch_rememberSwitchCell;
  TKLabelTextFieldCell *ch_usernameCell;
  TKLabelTextFieldCell *ch_passwordCell;

  NSObject<CHLoginViewControllerDelegate> *__unsafe_unretained ch_delegate;

  BOOL keyboardIsShown;

  BOOL shouldRegisterAndRememberTheDevice;

  BOOL isUpdatingTemporaryPassword;

  int registrationTries;
}

@property (nonatomic, strong) IBOutlet UIBarButtonItem *cancelButton;
@property (nonatomic, strong) IBOutlet UITableView     *tableView;
@property (nonatomic, strong) MBProgressHUD            *progressHUD;

@property (nonatomic, strong) TKLabelSwitchCell    *rememberSwitchCell;
@property (nonatomic, strong) TKLabelTextFieldCell *usernameCell;
@property (nonatomic, strong) TKLabelTextFieldCell *passwordCell;

@property (nonatomic, unsafe_unretained) NSObject<CHLoginViewControllerDelegate> *delegate;

- (IBAction)cancel:(id)sender;
- (IBAction)rememberMeChanged:(id)sender;
@end
