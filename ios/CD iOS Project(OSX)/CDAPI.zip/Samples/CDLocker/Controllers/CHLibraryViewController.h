// CHLibraryViewController.h
// Chicago
//
// Created by louie on 8/6/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHBaseProductListViewController.h"
#import "PurchasProductDelegate.h"
#import "CDClient.h"

@class MBProgressHUD;

@interface CHLibraryViewController : CHBaseProductListViewController <PurchasProductDelegate, CDClientDelegate> {
  NSInteger retryCount;
}

@property (nonatomic, strong) NSArray *       products;
@property (nonatomic, strong) MBProgressHUD * progressHUD;

@end
