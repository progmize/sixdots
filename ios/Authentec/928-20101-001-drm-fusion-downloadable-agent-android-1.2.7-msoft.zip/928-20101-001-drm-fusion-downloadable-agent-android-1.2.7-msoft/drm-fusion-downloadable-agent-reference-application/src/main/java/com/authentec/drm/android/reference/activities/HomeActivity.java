package com.authentec.drm.android.reference.activities;

import java.io.File;
import java.net.URL;
import java.util.*;

import android.app.*;
import android.content.*;
import android.graphics.drawable.Drawable;
import android.os.*;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.authentec.drm.android.reference.*;
import com.authentec.drmagent.v2.*;

/** Main activity responsible for displaying a list of known content and allowing basic manipulation (play, view, delete)
 * of them.
 * @author AuthenTec Inc.
 */
public class HomeActivity extends Activity
{
    private static final String TAG = "HomeActivity";

    private static DRMContentInfo sSelectedDrmContentInfo;
    private GridView mContentGrid;
    private List<DRMContentInfo> mContentInfoList;
    private ContentListAdapter mContentListAdapter;

    private static final int ABOUT_DIALOG = 1;
    private static final int CONTENT_INFO_DIALOG = 2;
    private static final int CONTENT_REFRESH_IN_PROGRESS = 3;
    private static final int UNTRUSTED_TIME = 4;
    private static final int DESCRIPTOR_LOADING_FAILED = 5;

    private static final int RETRIEVING_WEB_INITIATOR = 6;
    private static final int WEB_INITIATOR_RETRIEVED = 7;
    private static final int ERROR_RETRIEVING_WEB_INITIATOR = 8;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.home);

        mContentGrid = (GridView) findViewById(R.id.content_grid);

        mContentInfoList = new ArrayList<DRMContentInfo>();

        if (mContentListAdapter == null)
        {
            mContentListAdapter = new ContentListAdapter();
        }
        mContentGrid.setAdapter(mContentListAdapter);

    }

    @Override
    protected void onResume()
    {
        super.onResume();
        showDialog(HomeActivity.CONTENT_REFRESH_IN_PROGRESS);
        refreshContentList();
    }

    protected void onPause()
    {
        // Always release the agent once we are done in this activity
        for (DRMContentInfo drmContentInfo : mContentInfoList)
        {
            drmContentInfo.mDRMContent.release();
        }

        DRMAgentDelegate.uninitialize();

        super.onPause();

    }

    private void refreshContentList()
    {
        final List<DRMContentInfo> contentList = new ArrayList<DRMContentInfo>();
        final List<String> failedDescriptors = new ArrayList<String>();

        AsyncTask<Object, DRMContentInfo, DRMRights.DRMRightsType> asyncTask = new AsyncTask<Object, DRMContentInfo, DRMRights.DRMRightsType>()
        {
            @Override
            protected void onPreExecute()
            {
                showDialog(HomeActivity.CONTENT_REFRESH_IN_PROGRESS);
            }

            @Override
            protected void onProgressUpdate(final DRMContentInfo... values)
            {
                contentList.addAll(Arrays.asList(values));
                mContentInfoList.clear();
                mContentInfoList.addAll(contentList);
                mContentListAdapter.notifyDataSetChanged();
            }

            @Override
            protected DRMRights.DRMRightsType doInBackground(final Object... params)
            {
                final List<DRMContentInfo> drmContentInfos = ContentHandler.retrieveDRMContentInfos(HomeActivity.this, true, true, new ContentHandler.ContentRetrieverListener()
                {
                    public void drmContentInfoRetrieved(final DRMContentInfo drmContentInfo)
                    {
                        publishProgress(drmContentInfo);
                    }

                    public void drmContentInfoRetrievalFailed(final File name, final URL url)
                    {
                        failedDescriptors.add(name.getAbsolutePath());
                    }
                });

                // Check the availble content items for the status of their licenses
                // If any of them are found with a UNTRUSTED_TIME status, simply return
                // that rights type from this method.  Otherwise, return nothing
                DRMRights.DRMRightsType drmRightsType = null;
                for (DRMContentInfo drmContentInfo : drmContentInfos)
                {
                    if (!ContentHandler.isClearText(drmContentInfo))
                    {
                        if (ContentHandler.retrieveDRMRightsType(drmContentInfo) == DRMRights.DRMRightsType.UNTRUSTED_TIME)
                        {
                            drmRightsType = DRMRights.DRMRightsType.UNTRUSTED_TIME;
                            break;
                        }
                    }

                }

                return drmRightsType;
            }

            @Override
            protected void onPostExecute(final DRMRights.DRMRightsType drmRightsType)
            {
                mContentInfoList.clear();
                mContentInfoList.addAll(contentList);
                mContentListAdapter.notifyDataSetChanged();

                dismissDialog(HomeActivity.CONTENT_REFRESH_IN_PROGRESS);
                if (drmRightsType != null && drmRightsType == DRMRights.DRMRightsType.UNTRUSTED_TIME)
                {
                    // This means our system is in a bad state - need to reset clock!
                    showDialog(HomeActivity.UNTRUSTED_TIME);
                }

                if (!failedDescriptors.isEmpty())
                {
                    Log.d(TAG,"Processing of the following descriptors failed: " + failedDescriptors);
                    showDialog(HomeActivity.DESCRIPTOR_LOADING_FAILED);
                }

            }
        };
        asyncTask.execute();
    }

    @Override
    protected Dialog onCreateDialog(final int id)
    {
        Dialog dialog = null;
        switch (id)
        {
            case HomeActivity.ABOUT_DIALOG:
                dialog = createAboutDialog();
                break;
            case HomeActivity.CONTENT_INFO_DIALOG:
                dialog = createContentInfoDialog();
                break;
            case HomeActivity.CONTENT_REFRESH_IN_PROGRESS:
                dialog = Tools.createProgressDialog(this, getText(R.string.dialog_title), getText(R.string.dialog_text_refresh_content), false, null, null, null, null);
                break;
            case HomeActivity.UNTRUSTED_TIME:
                dialog = createAlertDialog(HomeActivity.UNTRUSTED_TIME, getText(R.string.dialog_text_untrusted_time));
                break;
            case HomeActivity.DESCRIPTOR_LOADING_FAILED:
                dialog = createAlertDialog(HomeActivity.DESCRIPTOR_LOADING_FAILED, getText(R.string.dialog_text_descriptor_loading_error));
                break;
            case RETRIEVING_WEB_INITIATOR:
                dialog = Tools.createProgressDialog(this, getText(R.string.dialog_title), getText(R.string.dialog_text_retrieving_web_initiator), false, null, null, null, null);
                break;
            case WEB_INITIATOR_RETRIEVED:
                dialog = createAlertDialogWithContentRefreshAfter(HomeActivity.WEB_INITIATOR_RETRIEVED, getText(R.string.dialog_text_web_initiator_retrieved));
                break;
            case ERROR_RETRIEVING_WEB_INITIATOR:
                dialog = createAlertDialogWithContentRefreshAfter(HomeActivity.ERROR_RETRIEVING_WEB_INITIATOR, getText(R.string.dialog_text_web_initiator_retrieval_error));
                break;
            default:
        }
        return dialog;
    }

    private Dialog createAlertDialog(final int dialogID, final CharSequence text)
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dismissDialog(dialogID);
            }
        };
        return Tools.createAlertDialog(this, getText(R.string.dialog_title), text, false, "Ok", positiveListener, null, null);
    }

    private Dialog createAlertDialogWithContentRefreshAfter(final int dialogID, final CharSequence text)
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dismissDialog(dialogID);
                refreshContentList();
            }
        };
        return Tools.createAlertDialog(this, getText(R.string.dialog_title), text, false, "Ok", positiveListener, null, null);
    }

    private Dialog createAboutDialog()
    {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.about_dialog);
        dialog.setTitle(getText(R.string.about_title));

        final TextView textCopyright = (TextView) dialog.findViewById(R.id.text_copyright);
        textCopyright.setText(getText(R.string.about_copyright));

        final TextView text = (TextView) dialog.findViewById(R.id.text);
        text.setText(getString(R.string.not_available));

        dialog.setOwnerActivity(HomeActivity.this);

        try
        {
            String s = DRMAgentDelegate.getDRMInformation(this);
            if (s != null)
            {
                text.setText(s);
            }

        }
        catch (Exception ex)
        {
            Log.d(TAG, "Unable to retrieve version information: " + ex.getMessage(), ex);
        }

        dialog.setCanceledOnTouchOutside(true);
        dialog.setCancelable(true);

        return dialog;

    }

    @Override
    protected void onPrepareDialog(final int id, final Dialog dialog)
    {
        super.onPrepareDialog(id, dialog);

        switch (id)
        {
            case HomeActivity.CONTENT_INFO_DIALOG:
                updateContentInfoDialog(dialog, sSelectedDrmContentInfo);
                break;
            case HomeActivity.CONTENT_REFRESH_IN_PROGRESS:
                break;
            default:
        }

    }

    private Dialog createContentInfoDialog()
    {
        if (sSelectedDrmContentInfo != null)
        {
            final Dialog dialog = new Dialog(this);
            updateContentInfoDialog(dialog, sSelectedDrmContentInfo);
            return dialog;
        }
        return null;

    }

    private void updateContentInfoDialog(Dialog dialog, DRMContentInfo drmContentInfo)
    {
        dialog.setContentView(R.layout.content_info_dialog);
        dialog.setTitle(getText(R.string.content_info_dialog_title));
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        TextView textView = (TextView) dialog.findViewById(R.id.content_info_drm_scheme);

        textView.setText(String.format(getString(R.string.content_info_dialog_drm_scheme), ContentHandler.retrieveDRMScheme(sSelectedDrmContentInfo)));

        textView = (TextView) dialog.findViewById(R.id.content_format);
        switch (drmContentInfo.mDRMContent.getDRMContentFormat())
        {
            case HTTP_LIVE_STREAMING:
                textView.setText(String.format(getString(R.string.content_info_dialog_content_format), "HTTP Live Streaming"));
                break;
            case SMOOTH_STREAMING:
                textView.setText(String.format(getString(R.string.content_info_dialog_content_format), "Smooth Streaming"));
                break;
            case WINDOWS_MEDIA:
                textView.setText(String.format(getString(R.string.content_info_dialog_content_format), "Windows Media ASF"));
                break;
            case PLAYREADY_ASF:
                textView.setText(String.format(getString(R.string.content_info_dialog_content_format), "PlayReady ASF"));
                break;
            case PIFF:
                textView.setText(String.format(getString(R.string.content_info_dialog_content_format), "Microsoft PIFF"));
                break;
            default:
                textView.setVisibility(View.GONE);
        }

        textView = (TextView) dialog.findViewById(R.id.content_info_uri);
        textView.setText(String.format(getString(R.string.content_info_dialog_uri), drmContentInfo.mContentLocation.toString()));

        textView = (TextView) dialog.findViewById(R.id.content_info_title);
        textView.setText(String.format(getString(R.string.content_info_dialog_content_title), drmContentInfo.mTitle));

        textView = (TextView) dialog.findViewById(R.id.content_info_content_playable);
        textView.setText(String.format(getString(R.string.content_info_dialog_playable), ContentHandler.hasRights(drmContentInfo) ? getString(R.string.yes) : getString(R.string.no)));

        // Only display the following information if the content is DRM protected
        if (ContentHandler.retrieveDRMScheme(drmContentInfo) != DRMScheme.CLEARTEXT)
        {
            textView = (TextView) dialog.findViewById(R.id.content_info_key_identifier);

            final String contentID = drmContentInfo.mDRMContent.getMetaData(DRMMetaData.CONTENT_ID);
            if (contentID != null)
            {
                textView.setText(String.format(getString(R.string.content_info_dialog_key_identifier), contentID));
            }
            else
            {
                textView.setVisibility(View.GONE);
            }

            textView = (TextView) dialog.findViewById(R.id.content_info_license_valid_from);
            if (drmContentInfo.mDRMContent.getDRMRights().getStartDate() != null)
            {
                textView.setText(String.format(getString(R.string.content_info_dialog_valid_from), formatDate(drmContentInfo.mDRMContent.getDRMRights().getStartDate())));
            }
            else
            {
                textView.setVisibility(View.GONE);
            }

            textView = (TextView) dialog.findViewById(R.id.content_info_license_valid_to);
            if (drmContentInfo.mDRMContent.getDRMRights().getEndDate() != null)
            {
                textView.setText(String.format(getString(R.string.content_info_dialog_valid_to), formatDate(drmContentInfo.mDRMContent.getDRMRights().getEndDate())));
            }
            else
            {
                textView.setVisibility(View.GONE);
            }
        }

        dialog.setOwnerActivity(HomeActivity.this);

    }

    private String formatDate(final Date validFrom)
    {
        return validFrom.toString();
    }

    @Override
    public boolean onPrepareOptionsMenu(final Menu menu)
    {
        Log.d(TAG,"Preparing options menu!");
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onCreateContextMenu(ContextMenu contextMenu, View v, ContextMenu.ContextMenuInfo contextMenuInfo)
    {
        super.onCreateContextMenu(contextMenu, v, contextMenuInfo);

        final MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.content_item_context_menu, contextMenu);

        MenuItem menuItem = contextMenu.findItem(R.id.delete_content);
        menuItem.setVisible(true);
        menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                if (sSelectedDrmContentInfo != null)
                {
                    Log.d(TAG, "Initiating Delete of Content: " + sSelectedDrmContentInfo.mContentDescriptorLocation);
                    ContentHandler.deleteContent(sSelectedDrmContentInfo);
                    mContentInfoList.remove(sSelectedDrmContentInfo);
                    mContentListAdapter.notifyDataSetInvalidated();
                    return true;
                }
                return false;
            }
        });

        MenuItem showContentInfoMenuItem = contextMenu.findItem(R.id.show_content_information);
        showContentInfoMenuItem.setVisible(true);
        showContentInfoMenuItem .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                if (sSelectedDrmContentInfo != null)
                {
                    Log.d(TAG, "Initiating Display of Content Information: " + sSelectedDrmContentInfo.mContentLocation);
                    showDialog(HomeActivity.CONTENT_INFO_DIALOG);
                    return true;
                }
                return false;
            }
        });

        MenuItem deleteRightsMenuItem = contextMenu.findItem(R.id.delete_rights);
        deleteRightsMenuItem.setVisible(true);
        deleteRightsMenuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                if (sSelectedDrmContentInfo != null)
                {
                    Log.d(TAG, "Initiating Delete of rights for: " + sSelectedDrmContentInfo.mContentLocation);
                    sSelectedDrmContentInfo.mDRMContent.deleteRights();
                    mContentListAdapter.notifyDataSetInvalidated();
                    return true;
                }
                return false;
            }
        });

        MenuItem acquireRightsMenuItem = contextMenu.findItem(R.id.acquire_rights_using_webinitiator);
        acquireRightsMenuItem.setVisible(true);
        acquireRightsMenuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                if (sSelectedDrmContentInfo != null)
                {
                    Log.d(TAG, "Initiating acquisition of rights for: " + sSelectedDrmContentInfo.mContentLocation);

                    if (LicenseAcquisitionHelper.canDoWebInitiator(HomeActivity.this,sSelectedDrmContentInfo))
                    {
                        Log.d(TAG, "Initiating acquisition of rights for: " + sSelectedDrmContentInfo.mContentLocation);

                        showDialog(HomeActivity.RETRIEVING_WEB_INITIATOR);

                        AsyncTask<Boolean,Boolean,Boolean> task = new AsyncTask<Boolean, Boolean, Boolean>()
                        {
                            @Override
                            protected Boolean doInBackground(final Boolean... booleans)
                            {
                                return LicenseAcquisitionHelper.retrieveAndInstallWebInitiator(HomeActivity.this,sSelectedDrmContentInfo);
                            }

                            @Override
                            protected void onProgressUpdate(final Boolean... values)
                            {
                                super.onProgressUpdate(values);
                            }

                            @Override
                            protected void onPostExecute(final Boolean successfullyRetrieved)
                            {
                                dismissDialog(HomeActivity.RETRIEVING_WEB_INITIATOR);
                                showDialog(successfullyRetrieved ? HomeActivity.WEB_INITIATOR_RETRIEVED : HomeActivity.ERROR_RETRIEVING_WEB_INITIATOR);
                            }
                        };
                        task.execute();
                    }
                    else
                    {
                        // TODO: Display something
                    }

                    return true;
                }
                return false;
            }
        });

        // Only display the delete rights for DRM protected content
        if (ContentHandler.isClearText(sSelectedDrmContentInfo))
        {
            deleteRightsMenuItem.setVisible(false);
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.home_menu, menu);

        MenuItem menuItem = menu.findItem(R.id.about);
        menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                Log.d(TAG, "Displaying About");
                showDialog(HomeActivity.ABOUT_DIALOG);
                return true;
            }
        });

        menuItem = menu.findItem(R.id.settings);
        menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                Log.d(TAG, "Going to Setting Activity");
                startActivity(new Intent(getBaseContext(), SettingsActivity.class));
                return true;
            }
        });

        menuItem = menu.findItem(R.id.refresh_content_list);
        menuItem.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
        {
            public boolean onMenuItemClick(final MenuItem menuItem)
            {
                Log.d(TAG, "Refreshing Home Page");
                refreshContentList();
                return true;
            }
        });

        return true;
    }

    private Drawable resolveIcon(final DRMContentInfo contentInfo)
    {
        final boolean isLocked = !(ContentHandler.retrieveDRMScheme(contentInfo) == DRMScheme.CLEARTEXT || ContentHandler.retrieveDRMRightsType(contentInfo) == DRMRights.DRMRightsType.VALID);

        switch (contentInfo.mDRMContent.getDRMContentFormat())
        {
            case HTTP_LIVE_STREAMING:
                return (isLocked ? getResources().getDrawable(R.drawable.apple_streaming_locked_selector) : getResources().getDrawable(R.drawable.apple_streaming_unlocked_selector));
            case SMOOTH_STREAMING:
            case WINDOWS_MEDIA:
            case PLAYREADY_ASF:
            default:
                return (isLocked ? getResources().getDrawable(R.drawable.video_locked) : getResources().getDrawable(R.drawable.video_unlocked));

        }
    }

    public class ContentListAdapter extends BaseAdapter
    {
        public View getView(int position, View convertView, ViewGroup parent)
        {
            final DRMContentInfo drmContentInfo = mContentInfoList.get(position);
            final Drawable drawable = resolveIcon(drmContentInfo);

            final View.OnLongClickListener onLongClickListener = new View.OnLongClickListener()
            {
                public boolean onLongClick(final View view)
                {
                    sSelectedDrmContentInfo = drmContentInfo;
                    return false;
                }
            };

            final DRMContentOnClickHandler drmContentOnClickHandler = new DRMContentOnClickHandler(drmContentInfo);


            final View v;
            if (convertView == null)
            {
                final LayoutInflater li = getLayoutInflater();
                v = li.inflate(R.layout.content_icon, null);
            }
            else
            {
                v = convertView;
            }
            registerForContextMenu(v);
            v.setLongClickable(true);
            v.setOnClickListener(drmContentOnClickHandler);
            v.setOnLongClickListener(onLongClickListener);


            final ImageView i = (ImageView) v.findViewById(R.id.icon_image);
            i.setClickable(true);
            i.setImageDrawable(drawable);
            i.setLongClickable(true);
            i.setContentDescription(drmContentInfo.mTitle);
            i.setOnClickListener(drmContentOnClickHandler);
            i.setOnLongClickListener(onLongClickListener);

            final TextView tv = (TextView) v.findViewById(R.id.icon_text);
            tv.setLongClickable(true);
            tv.setClickable(true);
            tv.setText(drmContentInfo.mTitle);
            tv.setOnClickListener(drmContentOnClickHandler);
            tv.setOnLongClickListener(onLongClickListener);

            return v;
        }

        @Override
        public int getViewTypeCount()
        {
            return 1;
        }

        public final int getCount()
        {
            return mContentInfoList.size();
        }

        public final Object getItem(int position)
        {
            return mContentInfoList.get(position);
        }

        public final long getItemId(int position)
        {
            return position;
        }

        @Override
        public boolean isEmpty()
        {
            return mContentInfoList.isEmpty();
        }

        @Override
        public boolean areAllItemsEnabled()
        {
            return true;
        }

        @Override
        public void notifyDataSetChanged()
        {
            Log.d(TAG, "Reloading content list");
            super.notifyDataSetChanged();
        }

        @Override
        public void notifyDataSetInvalidated()
        {
            Log.d(TAG, "Reloading content list");
            super.notifyDataSetInvalidated();
        }

    }

    public class DRMContentOnClickHandler implements View.OnClickListener
    {
        private DRMContentInfo _drmContentInfo;

        public DRMContentOnClickHandler(final DRMContentInfo drmContentInfo)
        {
            _drmContentInfo = drmContentInfo;
        }

        public void onClick(final View view)
        {
            final Intent intent = new Intent(getBaseContext(),LicenseAcquisitionActivity.class);
            intent.putExtra(Constants.DESCRIPTOR_LOCATION, _drmContentInfo.mContentDescriptorLocation);
            startActivity(intent);
        }
    }


}
