//
//  DADataTypes.h
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//


/**
 List of device model certificate types required by the PlayReady SDK.
 
 Both types of model certificates, together with their corresponding private keys, must be imported
 into the Agent before attempting to use it. See the static methods available for importing model certificates.
 */
typedef enum 
{
	/** PlayReady OEM device model certificate or private key */
	PlayReady_OEM_Certificate,
	
	/** WindowsMedia DRM OEM device model certificate or private key */
	WMDRM_OEM_Certificate
}
ModelCertificateType;


/** 
 List of content types supported by the Downloadable Agent.
 */
typedef enum
{
	/**
	 The content URL must point to a valid HTTP Live Streaming playlist, either the root or any variant playlist.
	 */
	HTTPLiveStreamingType,
	
	/**
	 The content URL must point to an Smooth Streaming manifest.
	 */
	SmoothStreamingType,
	
    /**
     The content URL must point to a PIFF file (.ismv), either stored locally on the file system (the URL must then be 
     the absolute path, with or without the 'file://' schema) or hosted on a remote HTTP server.
     */
    PIFFType
}
DAContentType;


/**
 List of all error codes reported by the Agent via NSError instances.
 */
typedef enum 
{	
	/** The DRM Agent failed to complete an operation.
	 
	 This is usually a severe error which requires further investigation. Please collect
	 all possible logs from the device in order to provide enough proper context.
	 */
	DAErrorInternalDRMAgentError,
	
	/** The content URL could not be retrieved successfully.
	 
	 Typically this indicates a network issue, a malformed URL or a missing file in the server.
	 If the content URL points to a HLS playlist which contains other variant playlists, the failure
	 to retrieve one of these would also trigger this error.
	 */
	DAErrorContentDownloadFailed,
	
	/** 
	 The content retrieved is invalid or does not match the expected format.
	 
	 The file(s) retrieved from the given URL do not match the expected format for the
	 type of content the Agent was initialized with.
	 */
	DAErrorInvalidOrUnexpectedContent,
	
	/** 
	 The Agent failed to perform the silent license acquisition.
	 
	 Indicates that the license acquisition was not successful, typically because the license
	 server is unreachable or returned an error or an invalid license.
	 */
	DAErrorSilentLicenseAcquisitionFailed,
	
	/** 
	 The delegate object failed to perform the license acquisition.
	 */
	DAErrorDelegatedLicenseAcquisitionFailed,
	
	/**
	 The delegate object failed to perform the join domain operation.
	 */
	DAErrorDelegatedJoinDomainFailed,
	
	/** 
	 The delegate object returned an invalid or unexpected server response which did not contain valid rights objects.
	 */
	DAErrorInvalidServerResponse,
	
	/**
	 The Agent does not support the join domain operation required by the license server.
	 */
	DAErrorJoinDomainNotSupported,
	
	/**
	 The delegate object does not support the join domain operation required by the license server.
	 
	 To prevent this error please implement the corresponding method of the LicenseAcquisitionDelegate protocol.
	 */
	DAErrorDelegatedJoinDomainNotSupported	
} 
DAErrorType;


/** 
 List of possible license status for a content.
 */
typedef enum 
{
    /** There are no valid rights */
    DANoRights,
    /** There are valid rights available now */
    DAValid,	
    /** Rights will be available in the future */
    DARightsInFuture,             
    /** Right have expired */
    DAExpired,                    
    /** Rights may exist but cannot be used as no trusted time is available */
    DAUntrustedTime,
	/** Default value for non DRM protected content */
	DAUnknown
} 
DARightsStatus;


/**
 List of possible client control HDMI modes.
 */
typedef enum
{
	/** The agent controls the HDMI based on info from the license. */
	DAHdmiDefault,
	/** The agent will fail the OPL check if HDMI video out is detected. */
	DAHdmiDisable,
	/** The agent will allow HDMI video out even if the license doesnt allow. */
	DAHdmiAllow,
	/** The agent will allow only audio via HDMI */
	DAHdmiAudioOnly,
	/** The client will provide alternative image for displaying on HDMI output. 
		Use the property hdmiAlternativeImage for setting the alternative UIView. */
	DAHdmiUseAlternative
}
DAClientControlHdmiMode;


/**
 List of possible status for a content stored in cache.
 */
typedef enum 
{
    /** the content is not cached */
    DACachingStatusNotCached,
    
    /** the content caching process is in progress */
    DACachingStatusInProgress,
    
    /** the content caching process has been cancelled/paused */
    DACachingStatusPaused,
    
    /** the content is now fully stored on cache */
    DACachingStatusCompleted,
    
    /** the content caching process has failed due to errors */
    DACachingStatusFailed
    
} DACachingStatus;

