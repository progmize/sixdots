//
//  CHSplash.h
//  Chicago
//
//  Created by Derr on 9/25/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CHSplash : UIViewController {
}

@end
