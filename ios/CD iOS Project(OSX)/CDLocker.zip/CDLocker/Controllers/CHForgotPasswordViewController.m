//
// CHForgotPasswordViewController.m
// Chicago
//
// Created by Brian Cooke on 8/20/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHForgotPasswordViewController.h"
#import "TKLabelTextFieldCell.h"
#import "CHAPIOperation.h"
#import "MBProgressHUD.h"
#import "CHResetpasswordViewController.h"

enum {
  kUsernameSection,
  kButtonsSection,
  kSectionCount
};

@implementation CHForgotPasswordViewController


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation) || toInterfaceOrientation == UIInterfaceOrientationPortrait;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  self.title = NSLocalizedString(@"FORGOT_PASSWORD_BUTTON_TEXT", @"Forgot Password");
	self.view.backgroundColor = kCHViewBackgroundColor;
	self.tableView.backgroundColor = kCHTableViewBackgroundColor;

  self.usernameCell                              = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"usernameCell"];
  self.usernameCell.label.text                   = NSLocalizedString(@"CONTROL_LOGIN_FORM_USERNAME", @"username");
  self.usernameCell.field.autocorrectionType     = UITextAutocorrectionTypeNo;
  self.usernameCell.field.autocapitalizationType = UITextAutocapitalizationTypeNone;

  self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
}


#pragma mark -
#pragma mark tableview datasource & delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return kSectionCount;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  if (section == kUsernameSection) {
    return 1;
  }

  return 2;
}


- (UITableViewCell *)buttonCellForRow:(NSInteger)row {
  static NSString * cellID = @"ButtonCell";
  UITableViewCell * cell   = [self.tableView dequeueReusableCellWithIdentifier:cellID];

  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
  }

  if (row == 0) {
    cell.textLabel.text = NSLocalizedString(@"CONTROL_PASSWORD_RETRIEVAL_EMAIL_OPTION", @"Email me a new password");
    cell.accessoryType  = UITableViewCellAccessoryNone;
  } else {
    cell.textLabel.text = NSLocalizedString(@"LOGIN_RESET_PASSWORD_BUTTON", @"Reset my password");
    cell.accessoryType  = UITableViewCellAccessoryDisclosureIndicator;
  }

  return cell;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == kButtonsSection) {
    return [self buttonCellForRow:indexPath.row];
  } else {
    return self.usernameCell;
  }
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  return nil;
}


- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == kUsernameSection) {
    return nil;
  }

  return indexPath;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  UIViewController * vc = nil;

  if ([self.usernameCell.field.text length] == 0) {
    [Fault showWithTitle:@"Login needed" andMessage:NSLocalizedString(@"FORGOT_PASSWORD_RESET_PASSWORD_ENTER_USERNAME_ERROR", @"You must enter your login to reset your password.")];
    [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
  } else {
    if (indexPath.row == 0) {
      // generate and email
      self.progressHUD.labelText = NSLocalizedString(@"PROCESSING_DATA_CREATING_TEXT", @"Generating...");
      [self.progressHUD show:YES];

      CHAPIOperation * op = [CHAPIOperation operationToGenerateNewPasswordForLogin:self.usernameCell.field.text];
      op.delegate = self;
      [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
    } else {
      vc = [[CHResetpasswordViewController alloc] initWithLogin:self.usernameCell.field.text];
    }
  }

  if (vc) {
    [self.navigationController pushViewController:vc animated:YES];
  }
}


#pragma mark -
#pragma mark CDClientDelegate
- (void)newPasswordSentTo:(NSString *)email {
  [Fault showWithTitle:NSLocalizedString(@"MESSAGE_PASSWORD_SUCCESSFFUL_HEADER", @"New password sent") andMessage:[NSString stringWithFormat:@"Your new password has been sent to %@.", email]];
  [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
  [self.navigationController popViewControllerAnimated:YES];
}


- (void)newPasswordFailed:(Fault *)fault {
  if ([[fault message] rangeOfString:@"ContentDirect.AuthorizationManagement.Contract.Fault.TemporaryPasswordViolation"].location != NSNotFound) {
    [Fault showWithTitle:NSLocalizedString(@"MESSAGE_PASSWORD_GENERAL", @"Failed to send new password") andMessage:@"A new password has already been sent."];
  } else {
    [fault showWithTitle:NSLocalizedString(@"MESSAGE_PASSWORD_GENERAL", @"Failed to send new password")];
  }
  [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
}


@synthesize usernameCell = ch_usernameCell, progressHUD = ch_progressHUD;

@end
