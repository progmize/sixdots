//
// CHBaseLoginRequiredViewController.m
// Chicago
//
// Created by Brian Cooke on 8/30/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHBaseLoginRequiredViewController.h"
#import "CHAPIOperation.h"
#import "NotLoggedInView.h"

@implementation CHBaseLoginRequiredViewController

- (void)cleanup {
  self.notLoggedInView = nil;
}


- (void)dealloc {
  [self cleanup];
}


- (void)viewDidLoad {
  [super viewDidLoad];

  self.notLoggedInView = [[NotLoggedInView alloc] initWithFrame:self.view.bounds];
  self.notLoggedInView.delegate = self;
  self.notLoggedInView.hidden = YES;
  [self.view addSubview:self.notLoggedInView];
}

- (void)viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
  
  if (self.loggedInRequired || self.authenticatedRequired) {
    if ([self loggedIn] && (self.authenticatedRequired == NO || [self authenticated])) {
      // Show the subscriber info
      [self showLoggedInUI];
    } else {
      // Prompt the user to login
      [self login:self];
      self.notLoggedInView.hidden = NO;
      
//      self.navigationItem.rightBarButtonItem = nil;

      [self showCSGBranding];
    }
  } else {
    [self showLoggedInUI];    
  }
}


- (void)showLoggedInUI {
  self.notLoggedInView.hidden = YES;
}


- (void)promptLogin {
  [self login:self];
}

#pragma mark -
#pragma mark actions
- (IBAction)login:(id)sender {
  CHLoginViewController * loginVC = [[CHLoginViewController alloc] init];

  loginVC.delegate = self;
  UINavigationController * nc = [[UINavigationController alloc] initWithRootViewController:loginVC];

  [self presentModalViewController:nc animated:YES];

}


#pragma mark -
#pragma mark CHLoginViewController
- (void)loginCompletedWithLogin:(NSString *)login password:(NSString *)password {
  // subclass should override this.
}


@synthesize notLoggedInView, loggedInRequired, authenticatedRequired;
@end
