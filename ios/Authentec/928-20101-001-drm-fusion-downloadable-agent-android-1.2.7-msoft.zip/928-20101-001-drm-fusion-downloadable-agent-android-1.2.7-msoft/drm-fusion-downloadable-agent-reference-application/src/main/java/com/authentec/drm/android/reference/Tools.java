package com.authentec.drm.android.reference;

import java.io.*;
import java.net.URI;

import android.app.*;
import android.content.*;
import android.net.http.AndroidHttpClient;
import android.util.Log;

/**
 * Various utility methods.
 *
 * @author AuthenTec Inc.
 */
public class Tools
{
    public static final String TAG = "Tools";

    /**
     * Creates a new <code>AndroidHttpClient</code> instance.
     *
     * @return The newly created HTTP client
     */
    public static AndroidHttpClient createHttpClient()
    {
        return AndroidHttpClient.newInstance(Constants.DRM_AGENT_USER_STRING);
    }

    /**
     * Copies the specified input stream onto the given output stream.
     *
     * @param inputStream  Input stream to read from
     * @param outputStream Output stream to write to
     * @return The number of bytes copied
     * @throws IOException If an error occurs while copying the data
     */
    public static long copyStream(final InputStream inputStream, final OutputStream outputStream) throws IOException
    {
        final int size = 16192;
        final byte[] buffer = new byte[size];

        int len;

        long totalCount = 0;
        while ((len = inputStream.read(buffer, 0, size)) != -1)
        {
            outputStream.write(buffer, 0, len);
            totalCount += len;

        }
        outputStream.flush();

        return totalCount;

    }

    /**
     * Method will check if the specified object is null and if so, generate and throw a <code>NullPointerException</code>.
     *
     * @param name The display name to use in the exception
     * @param obj  The object to check for null.
     */
    public static void DEFENSE(String name, Object obj)
    {
        if (obj == null)
        {
            throw new NullPointerException(name);
        }
    }

    public static ProgressDialog createProgressDialog(final Context owner, final CharSequence title, final CharSequence text, boolean cancelable,
                                              final CharSequence positiveText, final DialogInterface.OnClickListener positiveListener,
                                              final CharSequence negativeText, final DialogInterface.OnClickListener negativeListener)
    {
        ProgressDialog dialog = new ProgressDialog(owner);
        dialog.setTitle(title);
        dialog.setMessage(text);
        if (positiveText != null && positiveListener != null)
        {
            dialog.setButton(DialogInterface.BUTTON_POSITIVE, positiveText, positiveListener);
        }

        if (negativeText != null && negativeListener != null)
        {
            dialog.setButton(DialogInterface.BUTTON_NEGATIVE, negativeText, negativeListener);
        }

        dialog.setCancelable(cancelable);

        return dialog;
    }


    public static Dialog createAlertDialog(final Context owner, final CharSequence title, final CharSequence text, final boolean cancelable,
                                           final CharSequence positiveText, final DialogInterface.OnClickListener positiveListener,
                                           final CharSequence negativeText, final DialogInterface.OnClickListener negativeListener)
    {
        final AlertDialog.Builder builder = new AlertDialog.Builder(owner);
        builder.setTitle(title);
        builder.setMessage(text);
        builder.setCancelable(cancelable);
        if (positiveText != null && positiveListener != null)
        {
            builder.setPositiveButton(positiveText, positiveListener);
        }
        if (negativeText != null && negativeListener != null)
        {
            builder.setNegativeButton(negativeText, negativeListener);
        }
        return builder.create();
    }

    public static String convertToNiceTime(final int mPlayingTime)
    {
        int seconds = mPlayingTime / 1000;
        int minutes = seconds / 60;
        seconds = (seconds - (minutes * 60));
        int hours = minutes / 60;
        minutes = (minutes - (hours * 60));

        return zeroPad(hours) + ":" + zeroPad(minutes) + ":" + zeroPad(seconds);
    }

    public static String zeroPad(final int number)
    {
        return (number <= 9 ? "0" + number : "" + number);
    }

    public static String toHex(String txt)
    {
        return toHex(txt.getBytes());
    }

    public static String fromHex(String hex)
    {
        return new String(toByte(hex));
    }

    public static byte[] toByte(String hexString)
    {
        int len = hexString.length() / 2;
        byte[] result = new byte[len];
        for (int i = 0; i < len; i++)
        {
            result[i] = Integer.valueOf(hexString.substring(2 * i, 2 * i + 2), 16).byteValue();
        }
        return result;
    }

    public static String toHex(byte[] buf)
    {
        if (buf == null)
        {
            return "";
        }
        StringBuffer result = new StringBuffer(2 * buf.length);
        for (int i = 0; i < buf.length; i++)
        {
            appendHex(result, buf[i]);
        }
        return result.toString();
    }

    private final static String HEX = "0123456789ABCDEF";

    private static void appendHex(StringBuffer sb, byte b)
    {
        sb.append(HEX.charAt((b >> 4) & 0x0f)).append(HEX.charAt(b & 0x0f));
    }

    public static int extractStartFrom(final Context context, final Intent lastIntent, final URI uri)
    {
        // Figure out if we should start from the beginning or seeking into the content
        // The intent usually contains the startFrom time if the license expired and the play
        // was restarted
        Log.d(TAG, "Extracting timestamp for: " + uri.toString());
        int startFrom = 0;
        if (lastIntent != null)
        {
            startFrom = lastIntent.getIntExtra("startFrom", 0);
            Log.d(TAG, "Intent Timestamp: " + startFrom);
        }

        if (startFrom == 0)
        {
            // Try our settings to see if we can find a last place to play from
            final SharedPreferences authentec = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
            if (authentec.getBoolean(Constants.PREFERENCES_RESUME_PLAY_FROM_LAST_KNOWN_TIME,true))
            {
                final int aLong = (int) authentec.getLong(uri.toString() + ".time", -1);
                if (aLong != -1)
                {
                    Log.d(TAG, "Saved Timestamp: " + aLong);
                    startFrom = aLong;
                }
            }
        }
        Log.d(TAG, "Extracted timestamp: " + startFrom);
        return startFrom;
    }


    public static void saveStartFrom(final Context context, final long timestamp, final URI uri)
    {
        if (timestamp != 0)
        {
            final SharedPreferences authentec = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
            if (authentec.getBoolean(Constants.PREFERENCES_RESUME_PLAY_FROM_LAST_KNOWN_TIME,true))
            {
                Log.d(TAG, "Saving current timestamp for: " + uri.toString());
                Log.d(TAG, "Timestamp: " + timestamp);

                final SharedPreferences.Editor edit = authentec.edit();
                edit.putString(uri.toString() + ".uri", uri.toString());
                edit.putLong(uri.toString() + ".time", timestamp);
                edit.commit();
            }
        }
    }


    public static String toGUID(final byte[] raw)
    {
        byte[] first = new byte[4];
        byte[] second = new byte[2];
        byte[] third = new byte[2];
        byte[] fourth = new byte[2];
        byte[] fifth = new byte[6];

        System.arraycopy(raw, 0, first, 0, 4);
        System.arraycopy(raw, 4, second, 0, 2);
        System.arraycopy(raw, 6, third, 0, 2);
        System.arraycopy(raw, 8, fourth, 0, 2);
        System.arraycopy(raw, 10, fifth, 0, 6);

        final StringBuffer sb = new StringBuffer();

        sb.append(Tools.toHex(reverse(first)));
        sb.append('-');
        sb.append(Tools.toHex(reverse(second)));
        sb.append('-');
        sb.append(Tools.toHex(reverse(third)));
        sb.append('-');
        sb.append(Tools.toHex(fourth));
        sb.append('-');
        sb.append(Tools.toHex(fifth));

        return sb.toString().toUpperCase();

    }

    private static byte[] reverse(byte[] input)
    {
        byte[] output = new byte[input.length];

        int out = 0;
        for (int i = input.length-1; i >=0; i--)
        {
            output[out++] = input[i];
        }
        return output;
    }

}
