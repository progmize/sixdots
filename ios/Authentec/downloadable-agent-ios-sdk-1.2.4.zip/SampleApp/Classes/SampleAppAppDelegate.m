//
//  SampleAppAppDelegate.m
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "SampleAppAppDelegate.h"
#import "DownloadableAgent.h"


@implementation SampleAppAppDelegate

@synthesize window, viewController;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {

	[UIApplication sharedApplication].statusBarHidden = YES;

	//
	// Here we are importing the (encrypted) PlayReady device model certificates and keys into the DRM Agent
	// See the the PlayReady Device Porting Kit documentation for more information about these.
	// Note that both PlayReady OEM and WMDRM OEM certificates are required at this time.
	//
	
	BOOL importOK = YES;
	
	// import the PlayReady OEM device model certificate and private key
	NSData *playReadyPrivateKey = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"pr_privatekey" ofType:nil]];
	NSData *playReadyCertificate = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"pr_certificate" ofType:nil]];
	
	if (playReadyPrivateKey && playReadyCertificate)
	{
		importOK = importOK && [DownloadableAgent importDeviceModelPrivateKey:playReadyPrivateKey forModelCertificate:PlayReady_OEM_Certificate];
		importOK = importOK && [DownloadableAgent importDeviceModelCertificate:playReadyCertificate forModelCertificate:PlayReady_OEM_Certificate];
	}
	else
	{
		NSLog(@"ERROR: PlayReady OEM certificate or private key file not found");
		importOK = NO;
	}
	
	// import WMDRM OEM device model certificate and key
	NSData *wmdrmPrivateKey = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"wm_privatekey" ofType:nil]];
	NSData *wmdrmCertificate = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"wm_certificate" ofType:nil]];
	
	if (wmdrmPrivateKey && wmdrmCertificate)
	{
		importOK = importOK && [DownloadableAgent importDeviceModelPrivateKey:wmdrmPrivateKey forModelCertificate:WMDRM_OEM_Certificate];
		importOK = importOK && [DownloadableAgent importDeviceModelCertificate:wmdrmCertificate forModelCertificate:WMDRM_OEM_Certificate];	
    }
	else 
	{
		NSLog(@"ERROR: WMDRM OEM certificate or private key file not found");
		importOK = NO;
	}
	
	if (!importOK)
	{
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"ERROR" message:@"Device model certificates import failed" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]; 
		[alert show]; 
		[alert release];
	}
	
    return importOK;
}

- (void)applicationWillTerminate:(UIApplication *)application {

	// Save data if appropriate.
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
	NSLog(@"****** applicationDidReceiveMemoryWarning ******");
}

- (void)dealloc 
{
	[viewController release];
	[window release];
    [super dealloc];
}

@end

