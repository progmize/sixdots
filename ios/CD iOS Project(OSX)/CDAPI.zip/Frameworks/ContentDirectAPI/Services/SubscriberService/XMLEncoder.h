//  This will take NSDictionaries and NSStrings and turn them into XML.
//
//  XMLEncoder.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/28/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface XMLEncoder : NSObject {
  BOOL prettyPrint;
}

@property BOOL prettyPrint;

- (NSString *)xmlFromDictionary:(NSDictionary *)dictionary;

@end
