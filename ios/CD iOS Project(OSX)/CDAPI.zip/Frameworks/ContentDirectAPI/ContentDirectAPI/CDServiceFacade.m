//
//  CDServiceFacade.m
//  ContentDirectAPI
//
//  Created by Brandon on 2/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CDServiceFacade.h"

@implementation CDServiceFacade
{
    
}
- (BOOL)isAuthenticated {
//    if (self.subscriberID == nil) {
//        return NO;
//    }
//    
//    if ([self.sessionAuthenticationType isEqualToString:@"Authenticated"]) {
//        return YES;
//    }
//    
    return NO;
}


@end
