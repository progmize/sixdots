//
// CHFeaturedProductView.h
// Chicago
//
// Created by Derr on 8/5/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Product.h"
#import "PurchasProductDelegate.h"
#import "CHStarsView.h"
#import "SDWebImageManagerDelegate.h"

enum {
  CHFeaturedProductViewStyleFeatured,
  CHFeaturedProductViewStyleBrowse
};

#define CHFeaturedProductViewStyle    int

@interface CHFeaturedProductView : UIView <SDWebImageManagerDelegate> {
  UIButton                 * ch_image;
  UILabel                  * ch_title;
  UILabel                  * ch_subTitle;
  UIButton                 * ch_buyButton;
  CHStarsView              * ch_rating;
  UILabel                  * ch_guidence;
  id<PurchasProductDelegate> __unsafe_unretained delegate;
  NSURL                    * thumbnailURL;
  Product                  * ch_product;
  BOOL                       ch_libraryItem;
}

@property (unsafe_unretained) id<PurchasProductDelegate> delegate;
@property (assign) BOOL                       libraryItem;
@property (strong) NSURL                    * thumbnailURL;

- (id)initWithFrame:(CGRect)frame style:(CHFeaturedProductViewStyle)style;
- (void)setUpProductButton:(NSString *)buttonLabel isHidden:(BOOL)isHidden;

- (void)setProduct:(Product *)product;

@end
