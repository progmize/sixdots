//
//  SampleViewController.m
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "SampleViewController.h"
#import "ConsoleLogViewController.h"
#import "CachedContentViewController.h"
#import "ContentItem.h"
#import "CoreMedia/CMTime.h"


// Alert view tags
#define LICENSE_ALREADY_AVAILABLE_ALERT_TAG 10
#define ACQUIRE_LICENSE_ALERT_TAG 20
#define PLAY_UNPROTECTED_CONTENT_ALERT_TAG 30
#define RESET_DRM_DATABASE_ALERT_TAG 40


/* private methods */
@interface SampleViewController(Private)
- (void)playContent:(NSURL*)contentURL ofType:(DAContentType)contentType;
- (void)checkRights;
- (BOOL)contentCanBePlayedNow;
- (void)acquireLicenseAndPlay;
- (void)startPlayback;
- (void)pausePlayback;
- (void)subscribeAgentNotifications;
- (void)unsubscribeAgentNotifications;
- (void)printPlaybackStats;
- (void)alert:(NSString *) msg;
- (void)actionDialogWithMsg:(NSString *)msg buttonTitle:(NSString *)title tag:(int)tag;
- (void)showFinishedTaskHUD:(NSString *)label;
- (void)loadDebugTestContent;
- (DAContentType)contentTypeForURLString:(NSString *)urlString;

// notification handlers
- (void)playbackDidFinish:(NSNotification *)aNotification;
- (void)playbackRightsNotAvailable:(NSNotification *)aNotification;
- (void)systemTimeNotTrusted:(NSNotification *)aNotification;
- (void)invalidContentDownloaded:(NSNotification *)aNotification;
- (void)shouldAbortPlayback:(NSNotification *)aNotification;
- (void)willAbortPlayback:(NSNotification *)aNotification;
- (void)logMessage:(NSNotification *)aNotification;
@end


@implementation SampleViewController

@synthesize textbox;
@synthesize agent;
@synthesize HUD;
@synthesize contentList;
@synthesize messageLog;
@synthesize pickerView;
@synthesize selectedContentURL;

@synthesize mpPlayer;
@synthesize avPlayer;


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- Interface Builder action methods
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 * Action invoked when the user taps the 'play' button. It initiates the license checking and playback procedures.
 */
- (IBAction)playFromTextbox:(id)sender
{
	NSLog(@"Playing content URL from text box: %@", [textbox text]);
	
	// hides the keyboard and picker view if they were open
	[textbox resignFirstResponder];
	[pickerView setHidden:YES];
	
	NSString *urlString = [textbox text];
    DAContentType contentType = [self contentTypeForURLString:urlString];
    
    if (contentType == -1)
    {
        [self alert:@"Unable to guess the type of content for this URL. Please type in a valid URL in the box or select a movie from the content list"];
        return;
    }
	
	// create a NSURL instance with the URL string
	// make sure to scape any spaces it may contain otherwise the instantiation fails	
	urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];		
	NSURL *contentURL = [NSURL URLWithString:urlString];	
		
	if (contentURL && [[contentURL absoluteString] length] > 0)
	{
		[self playContent:contentURL ofType:contentType];
	}
	else
	{
		[self alert:@"Please type in a valid URL in the box or select a movie from the content list"];
	}
}

/*
 * Action invoked when the user taps the 'delete DRM store' button. Flushes all the installed licenses.
 */
- (IBAction)deleteDRMStore:(id)sender
{
	[self actionDialogWithMsg:@"All data in your DRM database will be lost. Do you want to continue?" buttonTitle:@"OK" tag:RESET_DRM_DATABASE_ALERT_TAG];
}

/*
 * Loads up the view controller for the console log and presents it with a flip animation
 */
- (IBAction)showLogView:(id)sender
{    	
	ConsoleLogViewController *controller = [[ConsoleLogViewController alloc] initWithNibName:@"ConsoleLogView" bundle:nil];
	controller.loggedMessages = messageLog;	
	controller.modalTransitionStyle = UIModalTransitionStyleFlipHorizontal;
    
	[self presentModalViewController:controller animated:YES];
	
	[controller release];
}

/*
 * Loads up the view controller for a content cached (or to be cached) on disk
 */
- (IBAction)showCachedContentView:(id)sender
{    	
	// hides the keyboard and picker view if they were open
	[textbox resignFirstResponder];
	[pickerView setHidden:YES];
	
	NSString *urlString = [textbox text];
    DAContentType contentType = [self contentTypeForURLString:urlString];
    
    if (contentType == -1)
    {
        [self alert:@"Unable to guess the type of content for this URL. Please type in a valid URL in the box or select a movie from the content list"];
        return;
    }    
    
    // this feature is currently only supported for PIFF files!
    if (contentType != PIFFType)
    {
        [self alert:@"Download & Play Offline is only supported for PIFF files"];
        return;
    }
	
	// create a NSURL instance with the URL string
	// make sure to scape any spaces it may contain otherwise the instantiation fails	
	urlString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];		
	NSURL *contentURL = [NSURL URLWithString:urlString];	
    
	if (contentURL && [[contentURL absoluteString] length] > 0)
	{
        CachedContentViewController *controller = [[CachedContentViewController alloc] initWithContentURL:contentURL ofType:contentType];
        controller.modalTransitionStyle = UIModalTransitionStylePartialCurl;
        
        [self presentModalViewController:controller animated:YES];
        
        [controller release];
	}
	else
	{
		[self alert:@"Please type in a valid URL in the box or select a movie from the content list"];
	}
}

/*
 * Shows/hides the UIPickerView populated with a list of content items
 */
- (IBAction)showContentPicker:(id)sender
{
	[pickerView setHidden:![pickerView isHidden]];
}

/*
 * Responds to changes in the switch to decide whether to use the AVFoundation or the MediaPlayer framework
 */
- (IBAction)changePlayerSwitch:(id)sender
{
    useAVFoundationPlayer = playerSwitch.on;
    
    // save to user settings
    [[NSUserDefaults standardUserDefaults] setBool:useAVFoundationPlayer forKey:@"useAVFoundationPlayer"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (IBAction)dismissKeyboard:(id)sender 
{
	[textbox resignFirstResponder];
}

- (IBAction)testAction1:(id)sender
{
	//
	// Get the PlayReady device unique ID (16 bytes)
	//
    
    NSData *guid = [DownloadableAgent getPlayReadyDeviceID];
    
    if (guid)
    {
        NSLog(@"PlayReady device unique ID retrieved successfully");
    }
}

- (IBAction)testAction2:(id)sender
{
	//
	// Check if the device security has been compromised (i.e. it is 'jailbroken')
	//	
	if ([DownloadableAgent isSecureDevice])
	{
		[self alert:@"This device seems to be secure"];
	}
	else 
	{
		[self alert:@"This device seems to be jailbroken!"];
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- Checking rights and acquiring a license
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (DAContentType)contentTypeForURLString:(NSString *)urlString
{
    // Find the URL in the textbox in our internal content list
	ContentItem *selectedContentItem = nil;	
	BOOL found = NO;
    
	for (int i=0; i < [contentList count]; i++)
	{
		selectedContentItem = (ContentItem *) [contentList objectAtIndex:i];
		
		if ([selectedContentItem.contentURL isEqualToString:urlString])
		{
			found = YES;
			break;
		}
	}
	
	// Set the type of content (HLS, SS, PIFF) for this URL
	DAContentType contentType;
	
	if (found)
	{
		// use the content type defined for the selected content item
		contentType = selectedContentItem.contentType;
	}
	else
	{
		// the URL has been typed manually in the text box
		// try to guess the type of content by looking at the URL format		
		NSString *file = [[urlString lastPathComponent] lowercaseString];
		
		if ([file hasSuffix:@".m3u8"])
		{
			contentType = HTTPLiveStreamingType;
		}
		else if ([file isEqualToString:@"manifest"])
		{
			contentType = SmoothStreamingType;
		}
		else if ([file hasSuffix:@".ismv"])
		{
			contentType = PIFFType;
		}
		else
		{	
			return -1;
		}
	}
    
    return contentType;
}

- (void)playContent:(NSURL*)contentURL ofType:(DAContentType)contentType
{
	self.selectedContentURL = contentURL;
	
	// Create an instance of the DownloadableAgent initialized with the URL of the content and its
	// corresponding type using the DownloadableAgent class custom initialization method.	
	// Note that the type of content (whether it is HLS, SS, PIFF, etc) must be known beforehand
	self.agent = [[[DownloadableAgent alloc] initWithContentURL:contentURL type:contentType] autorelease];
	
	// Proceed to check the existing rights for the content (in case it is actually DRM protected)
	// Important: license checks should always be performed in a background thread to avoid blocking the UI
	// so it is also convenient to display visual feedback indicating that a task is currently in progress.
	self.HUD = [MBProgressHUD showHUDAddedTo:[self view] animated:YES];		
	HUD.labelText = @"Checking rights for content...";
	
	[agent setHdmiMode:DAHdmiAudioOnly];
	[agent setHdmiAlternativeImage:nil];
	
	// execute license check and acquisition on a background thread
	[HUD showWhileExecuting:@selector(checkRights) onTarget:self withObject:nil animated:YES];		
}

- (void)checkRights
{	
	// since this is happening in a background thread, we should allocate our own autorelease pool
	// but the MBProgressHUD class already takes care of that when calling 'showWhileExecuting'
	// NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    
	// check whether there are rights already installed for this content
	NSError *error;
	DAContentInfo *contentInfo;

	if (![agent contentInfo:&contentInfo error:&error])
	{
		// show an error...
		[self alert:[NSString stringWithFormat:@"Unable to validate the content: %@", [error localizedDescription]]];		
		
		// release the Agent
		self.agent = nil;
		
		return;
	}
    
    // For Smooth Streaming: see if there are multiple audio tracks available
    if (contentInfo.audioTrackNames.count > 0)
    {
        NSLog(@"Available audio tracks: %@", contentInfo.audioTrackNames);
    }
	
    // check the installed playback rights
	if (!contentInfo.isProtected)
	{
		// the content is not DRM protected
		// there is no need to perform license check / acquisition
		
		// if the content is not protected but its format is anything different than what the
		// native player supports natively (i.e. HLS) then you still need to use the Agent to play it
		shouldUseAgentForPlayback = (agent.contentType != HTTPLiveStreamingType);
		
		[self actionDialogWithMsg:@"This content is not DRM protected" buttonTitle:@"Play" tag:PLAY_UNPROTECTED_CONTENT_ALERT_TAG];						
	}
	else
	{
		// protected content is always played with the Agent
		shouldUseAgentForPlayback = YES;		
		
		// the date formatter we'll use to produce strings with the license start/end dates
		// this will also help converting these dates to the device's current time zone
		NSDateFormatter *dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
		[dateFormatter setTimeStyle:NSDateFormatterMediumStyle];					
		[dateFormatter setDateStyle:NSDateFormatterMediumStyle];
		
		switch (contentInfo.rightsStatus)
		{
			case DAValid:
			{				
				// rights are already installed for this content
				NSString *message = [NSString stringWithFormat:@"A license is already installed for this content"];
						
                if (contentInfo.rightsExpireAfterFirstUse)
                {
                    // the license is only valid for a certain interval after it's been used for the first time
                    // Note that the PlayReady SDK does not report the interval duration until after the playback has begun
                    message = [message stringByAppendingString:@"\n-Expires after first use-"];
                }
				else if (contentInfo.licenseEndDate != nil)
				{
					// the license has an expiration date set, otherwise it would be unlimited playback time					
					message = [message stringByAppendingFormat:@"\n-Expires on %@-", [dateFormatter stringFromDate:[contentInfo licenseEndDate]]];
				}
                     
				[self actionDialogWithMsg:message buttonTitle:@"Play" tag:LICENSE_ALREADY_AVAILABLE_ALERT_TAG];

				break;
			}
			case DANoRights:
			case DAExpired:
			{			
				// ask the user for consent to proceed with license acquisition
				[self actionDialogWithMsg:@"A license is required to play this content" buttonTitle:@"Get License" tag:ACQUIRE_LICENSE_ALERT_TAG];

				break;
			}
			case DARightsInFuture:
			{
				NSString *message = [NSString stringWithFormat:@"The license installed for this content does not allow playback at the current date"];
				
				if (contentInfo.licenseStartDate != nil)
				{
					// the license has an start date set in the future
					message = [message stringByAppendingFormat:@"\n(Rights begin on %@)", [dateFormatter stringFromDate:[contentInfo licenseStartDate]]];
				}
				
				[self alert:message];
				break;
			}
			case DAUntrustedTime:
			{			
				[self alert:@"A rollback to the system clock has been detected. Please correct the date & time in order to play this content"];
				
				// release the Agent
				self.agent = nil;
				break;
			}
            case DAUnknown:
            {
				[self alert:@"Warning: Unknown license status."];
				
				// release the Agent
				self.agent = nil;
				break;
            }
		}
	}
	
	//[pool release];
}

- (BOOL)contentCanBePlayedNow
{	
	// A simple and quick method to check whether the installed rights for the current content
	// allow playback at the current date & time
	
	DAContentInfo *contentInfo = nil;
		
	return ([agent contentInfo:&contentInfo error:nil] && [contentInfo rightsStatus] == DAValid);
}

- (void)acquireLicenseAndPlay
{
	// acquire rights for the content
	
	// if you want to add custom data to the license acquisition challenge sent to the server, set it now
	// NSData *customData = [@"<em:credentials xmlns:em='http://opencase.extend.com/em'><em:credential em:name='COMPONENT_ID'>2d48b15c-02ba-42c1-8198-a09d22108a9a</em:credential><em:credential em:name='ENTITLEMENT_ID'>0a6b364e-3331-43a8-a041-5b6023e0408c</em:credential></em:credentials>" dataUsingEncoding:NSUTF8StringEncoding];
	// [agent setCustomLicenseChallengeData:customData];
    
	// In this example we're setting ourselves as delegate, which means that the Agent generates a license acquisition challenge and passes
	// it to our implementation of the LicenseAcquisitionDelegate protocol. We're then responsible for sending it to the license server 
    // and returning the response to the Agent.
    
	NSError *error = nil;
	BOOL licenseAcquired = [agent acquireLicenseWithDelegate:self error:&error];	
	//BOOL licenseAcquired = [agent acquireLicenseWithDelegate:nil error:&error];	// non-delegated mode (the Agent performs the entire process)
	
	if (licenseAcquired)
	{	
		[self showFinishedTaskHUD: @"License acquired successfully"];		
		
		[NSThread sleepForTimeInterval:2];	// hacky! - doesn't work always...
		
		if ([self contentCanBePlayedNow])
		{
			// rights check successful
			// begin playback on main thread
			[self performSelectorOnMainThread:@selector(startPlayback) withObject:nil waitUntilDone:NO];
		}
		else
		{
			[self alert:@"License acquisition was successful but it does not allow playback at the current date & time"];
		}
	}
	else
	{
		NSLog(@"License acquisition failed: %@", [error localizedDescription]);
		[self alert:@"License acquisition failed, can not play the content"];
	}
}

- (void)renewExpiredLicense
{	
	// this method handles license renewal when the existing license has expired during playback
	// see method -playbackRightsNotAvailable:
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	NSLog(@"Acquiring a new license for the content being played...");
	
	NSError *error = nil;
	
	// initiate the license acquisition protocol using the same delegate
	BOOL licenseAcquired = [agent acquireLicenseWithDelegate:self error:&error];	
	
	// verify that the acquired license allows playback in the present time (it could contain rights in the future only)
	if (licenseAcquired && [self contentCanBePlayedNow])
	{	
		// the new license was acquired successfully and allows playback at he current date & time
		// if we did not pause the player before, the playback should continue uninterruptedly
		
		NSLog(@"License has been renewed successfully");
	}
	else
	{
		// either the license acquisition failed or the new license does not allow playback 
		// at the current date & time. In any case we shall stop the player.
		
		[self alert:@"The license to play this content could not be renewed. Playback finished"];
		
		if (error)
		{
			NSLog(@"License acquisition failed: %@", [error localizedDescription]);			
		}
		
		// stop the player
		[self performSelectorOnMainThread:@selector(stopPlayback) withObject:nil waitUntilDone:NO];
	}
	
	[pool drain];
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- Playing the content
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (BOOL)isAffectedByTheProxyBug
{	
    return NO;
    
	// HTTP proxy detection code
	//	 
	// Detects if there is any HTTP proxy defined in the current network configuration and whether HTTPS requests
	// addressed to the loopback interface will use it, in which case playback of DRM protected content
	// becomes impossible (See the "Known Issues" section in the documentation for more information).
	//
	// This issue affects firmwares 4.2 and newer but it is not necessary to perform a version check.
	// The CFNetworkCopyProxiesForURL() function will tell us whether the device this is running on is affected or not.
    
	NSLog(@"Checking whether an HTTPS proxy is configured...");	
	
	// retrieve the current global proxy settings
	CFDictionaryRef proxySettings = CFNetworkCopySystemProxySettings();
	
	// ask the system if a proxy will be used for requests addressed to 'localhost' using the HTTPS protocol
	NSURL *serverURL = [NSURL URLWithString:@"https://localhost"];
	CFArrayRef proxyList = CFNetworkCopyProxiesForURL((CFURLRef)serverURL, proxySettings);
	
	// examine the first item returned
	CFDictionaryRef firstProxy = CFArrayGetValueAtIndex(proxyList, 0);
	
	BOOL proxyDetected = NO;
	
	if (CFDictionaryGetValue(firstProxy, kCFProxyTypeKey) != kCFProxyTypeNone)
	{
		// protected content cannot be played while a proxy is in use
		NSLog(@"HTTP proxy check failed: protected content can not be played currently");
		proxyDetected = YES;
	}
    else
    {
        // unaffected iOS version or proxy not currently in use
        NSLog(@"HTTP proxy check successful: protected content can be played");
    }
	
	CFRelease(proxySettings);
	CFRelease(proxyList);
	
	return proxyDetected;
}

- (void)startPlayback
{
	if (shouldUseAgentForPlayback)
	{
        // HTTP Proxy check
        // See the "Known Issues" section of the documentation for more info about this check.
        if ([self isAffectedByTheProxyBug])
        {
            [self alert:@"Your Internet connection is currently using an HTTP proxy, content playback is not supported when a proxy is configured"];
            
            // release the Agent
            self.agent = nil;			
            return;
        }
		
        // For Smooth Streaming streams with multiple audio tracks, you may tell the Agent which one to use
        // Use the contentInfo method to retrieve the list of available audio tracks.
        // [agent setSelectedAudioTrackName:@"preferred_audio_track_name"];
        
        // if we are using the AVFoundation framework
        if (useAVFoundationPlayer)
        {
            AVPlayerItem *playerItem = [agent avPlayerItem];
            
            AVPlayerViewController *avPlayerController = [[AVPlayerViewController alloc] initWithAVPlayerItem:playerItem];
            avPlayerController.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
                        
            // save a reference to the player to be able to control it programmatically when necessary
            self.avPlayer = avPlayerController.player;
                        
            [self presentModalViewController:avPlayerController animated:YES];            
            [avPlayerController release];
        }        
        else
        {
            // or using the MediaPlayer framework
            // obtain a MPMoviewPlayerViewController instance via the Agent
            MPMoviePlayerViewController *mpViewController = [agent moviePlayerViewController];
            
            // save a reference to the player to be able to control it programmatically when necessary
            self.mpPlayer = mpViewController.moviePlayer;
            
            // if you wish to disable AirPlay to prevent the user from streaming the protected content to other devices
            // use the player API to disable it (comes enabled by default on iOS 5.0+)
            if ([mpPlayer respondsToSelector:@selector(setAllowsAirPlay:)])
            {
                [mpPlayer setAllowsAirPlay:NO];
            }
            
            // recommended  iOS 5.0+
            [mpPlayer prepareToPlay];
            
            [self presentMoviePlayerViewControllerAnimated:mpViewController];
            
            // subscribe to notifications sent by the player
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:mpPlayer];		
        }

		// subscribe to the notifications sent by the Agent	
        [self subscribeAgentNotifications];
	}
	else
	{
        NSLog(@"Playing clear text HLS content with the vanilla player");
        
		// obtain a MPMoviewPlayerViewController instance as usual
        MPMoviePlayerViewController *mpViewController = [[MPMoviePlayerViewController alloc] initWithContentURL:selectedContentURL];
        
        [self presentMoviePlayerViewControllerAnimated:mpViewController];        
        [mpViewController release];
        
        // subscribe to notifications sent by the player
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackDidFinish:) name:MPMoviePlayerPlaybackDidFinishNotification object:mpViewController.moviePlayer];		
	}
}

// programmatically pause the player
- (void)pausePlayback
{    
    if (useAVFoundationPlayer)
    {
        [avPlayer pause];
    }
    else
    {
        [mpPlayer pause];
    }
}

// programmatically stop the player
- (void)stopPlayback
{	
    NSArray *playbackStats = nil;
    
    // check if playback statistics are available (iOS 4.3 and later only)
	BOOL supportPlaybackStats = NSClassFromString(@"MPMovieAccessLog") && NSClassFromString(@"MPMovieErrorLog");
    
    if (useAVFoundationPlayer)
    {
        [avPlayer pause];
        
        if (supportPlaybackStats)
        {
            playbackStats = [[NSArray arrayWithObjects:[avPlayer currentItem].accessLog, [avPlayer currentItem].errorLog, nil] retain];            
        }
    }
    else
    {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:mpPlayer];
        
        [mpPlayer pause];
        [mpPlayer stop];

        if (supportPlaybackStats)
        {
            playbackStats = [[NSArray arrayWithObjects:mpPlayer.accessLog, mpPlayer.errorLog, nil] retain];            
        }
    }
    
    // print playback stats in the console
    if (supportPlaybackStats)
    {
        [self performSelectorInBackground:@selector(printPlaybackStats:) withObject:playbackStats];
    }
    else
    {
        NSLog(@"Playback statistics are not available in this device's iOS version");        
    }

    if (shouldUseAgentForPlayback)
    {
        // unsubscribe from Agent notifications
        [self unsubscribeAgentNotifications];
    }
    
    // remove the player view
	[self dismissModalViewControllerAnimated:YES];
    
    // release the player and the agent
    self.avPlayer = nil;
    self.mpPlayer = nil;
    self.agent = nil;
}

- (void)subscribeAgentNotifications
{
    // Subscribe to the Downloadable Agent notifications
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playbackRightsNotAvailable:) name:DownloadableAgentPlaybackRightsNotAvailableNotification object:agent];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(systemTimeNotTrusted:) name:DownloadableAgentUntrustedSystemTimeNotification object:agent];	
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(invalidContentDownloaded:) name:DownloadableAgentDidDownloadInvalidContentNotification object:agent];		
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(receivedServerError:) name:DownloadableAgentDidReceiveServerErrorNotification object:agent];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shouldAbortPlayback:) name:DownloadableAgentPlaybackShouldBeAbortedNotification object:agent];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(willAbortPlayback:) name:DownloadableAgentPlaybackWillBeAbortedNotification object:agent];
}

- (void)unsubscribeAgentNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentPlaybackRightsNotAvailableNotification object:agent];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentUntrustedSystemTimeNotification object:agent];	
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentDidDownloadInvalidContentNotification object:agent];	
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentDidReceiveServerErrorNotification object:agent];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentPlaybackShouldBeAbortedNotification object:agent];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:DownloadableAgentPlaybackWillBeAbortedNotification object:agent];			
}

- (void)printPlaybackStats:(NSArray *)playerStatsArray
{
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
    // the output here may be large so we wait a bit here to
    // allow the deallocated stuff to get done in order to have a clear console    
    [NSThread sleepForTimeInterval:1];
    
    NSArray *events = nil;
    
// compile time check in case the app is being built with an old SDK
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 40300
		    
    if (playerStatsArray.count > 0)
    {
        MPMovieAccessLog *accesslog = [playerStatsArray objectAtIndex:0];	
        events = [accesslog events];
        
        if (events.count > 0)
        {	
            NSLog(@"--- Access Log ----------------------------------------------");
            
            // print the access log events
            for (int i=0; i < events.count; i++)
            {
                MPMovieAccessLogEvent *event = [events objectAtIndex:i];
                
                NSLog(@"--- AccessLogEvent #%i ---", i+1);
                NSLog(@"URI: %@", [event URI]);
                NSLog(@"playbackStartDate: %@", [event playbackStartDate]);
                NSLog(@"durationWatched: %f", [event durationWatched]);			
                NSLog(@"numberOfSegmentsDownloaded: %i", [event numberOfSegmentsDownloaded]);
                NSLog(@"segmentsDownloadedDuration: %f", [event segmentsDownloadedDuration]);
                NSLog(@"numberOfBytesTransferred: %qu", [event numberOfBytesTransferred]);
                NSLog(@"numberOfDroppedVideoFrames: %i", [event numberOfDroppedVideoFrames]);				
                NSLog(@"numberOfStalls: %i", [event numberOfStalls]);
                NSLog(@"indicatedBitrate (of largest ts segment): %.0f Kbps", [event indicatedBitrate] / 1000);	
                NSLog(@"observedBitrate (i.e. connection speed): %.0f Kbps", [event observedBitrate] / 1000);					
            }
        }
    }
    
    if (playerStatsArray.count > 1)
    {
        MPMovieErrorLog *errorLog = [playerStatsArray objectAtIndex:1];
        events = [errorLog events];
            
        if (events.count > 0)
        {		
            NSLog(@"--- Error Log -----------------------------------------------");
            
            // print the error log events
            for (int i=0; i < events.count; i++)
            {
                MPMovieErrorLogEvent *event = [events objectAtIndex:i];
                
                NSLog(@"--- ErrorLogEvent #%i ---", i+1);
                NSLog(@"URI: %@", [event URI]);
                NSLog(@"errorStatusCode: %i", [event errorStatusCode]);
                NSLog(@"errorDomain: %@", [event errorDomain]);			
                NSLog(@"errorComment: %@", [event errorComment]);				
            }
        }
    }
#endif
    
    [playerStatsArray release];
	[pool drain];
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- Notification handlers
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)playbackDidFinish:(NSNotification *)aNotification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:mpPlayer];
    
    // show the reason why the playback finished
	NSNumber *reason = (NSNumber *) [[aNotification userInfo] valueForKey:MPMoviePlayerPlaybackDidFinishReasonUserInfoKey];
	NSString *reasonString;
	
	switch ([reason intValue])
	{
		case MPMovieFinishReasonPlaybackEnded:
			reasonString = @"PlaybackEnded";
			break;
			
		case MPMovieFinishReasonPlaybackError:
		{		
            reasonString = @"PlaybackError";
            
			NSError *error = (NSError *) [[aNotification userInfo] valueForKey:@"error"];
			if (error)
			{
				reasonString = [@"PlaybackError: " stringByAppendingString:[error localizedDescription]];
			}
			break;
		}	
		case MPMovieFinishReasonUserExited:
			reasonString = @"UserExited";
			break;
			
		default:
			reasonString = [NSString stringWithFormat:@"UnknownReason(%i)", [reason intValue]];
	}
	
	NSLog(@"Received notification MPMoviePlayerPlaybackDidFinish (reason: '%@')", reasonString);    
    
    [self stopPlayback];
}

- (void)playbackRightsNotAvailable:(NSNotification *)aNotification
{	
	// triggered during playback when the Agent has failed to decrypt a piece of content due to expired play rights.
	// At this point you can opt for either acquiring a new license silently while the playback continues
	// (note that the player typically has around 1 minute of buffered content so it will likely continue playing) while
    // the license is being renewed or pause the playback, ask the user for permission to acquire a license and  then
    // resume the playback when the new license has been installed successfully.
	
	NSLog(@"License for the current content has expired, will try to acquire a new license...");
	
	// [[mpView moviePlayer] pause];
	
	// renew the license for the content being played
	[self performSelectorInBackground:@selector(renewExpiredLicense) withObject:nil];
}


- (void)systemTimeNotTrusted:(NSNotification *)aNotification
{	
	// triggered during playback when a rollback to the system clock has been detected and the Agent can not trust the current
	// system time in order to validate time based rights. You should show some sort of warning to the user with instructions	
	// to revert the date and time to the right value.
	//
	// It is recommended to enable the "Set Automatically" switch in  Settings -> General -> Date & Time.
	// Network connectivity with Microsoft's NTP server will be required by the Agent in order to validate the new date & time.
	//
	// This security check has no effect when using life-time licenses (without an expiration date).
		
	NSLog(@"Local system time modification detected!");
	
	[self alert:@"A rollback to the system clock has been detected. Please correct the date & time in order to continue playing the content"];
	
	// stop the player
	[self performSelectorOnMainThread:@selector(stopPlayback) withObject:nil waitUntilDone:NO];	
}


- (void)invalidContentDownloaded:(NSNotification *)aNotification
{	
	// triggered during playback when the Agent has downloaded some content (either a playlist or a piece of protected video) 
	// on request of the player but the file downloaded has been determined to be invalid (i.e. it is not a valid playlist 
	// or a DRM protected file). The most common cause for this error is that the device has roamed to a WiFi hotspot that 
	// requires user authentication or to accept some sort of challenge in order to be able to use the Internet connection,
	// and therefore the Agent is getting an HTML page rather than the content requested.
	//
	// Note that the player will internally keep requesting this file to the Agent until the request succeeds so that the 
	// playback can be resumed. This happens even while the player is paused.
	
	NSLog(@"Invalid content downloaded notification received");

    [self pausePlayback];

	[self alert:@"Your Internet connection appears not to be working properly. Please verify and then resume the playback"];
}


- (void)receivedServerError:(NSNotification *)aNotification
{
	// triggered during playback when the Agent has failed to download a piece of content due to an error in the content server.
	// The underlying error is included in the UserInfo dictionary.
	// You should log and perhaps report this error for further investigation, as it might signal issues in your content 
	// distribution network.
	
	NSString *failedURL = (NSString *) [[aNotification userInfo] objectForKey:DownloadableAgentDidReceiveServerErrorURLUserInfoKey];
	NSNumber *errorCode = (NSNumber *) [[aNotification userInfo] objectForKey:DownloadableAgentDidReceiveServerErrorCodeUserInfoKey];
	
	NSLog(@"A request to download the file with URL '%@' failed with the error code %i", failedURL, [errorCode intValue]);
}


- (void)shouldAbortPlayback:(NSNotification *)aNotification
{
	// triggered when the Agent has encountered a critical issue that prevents from processing a request properly and is not 
	// expecting to be able to recover successfully from it, therefore it is recommended to abort the playback. Should you 
	// choose not to do so, the Agent is likely to enter into an error loop as the player silently retries the same or the
	// next piece of content.
	//
	// The condition that causes this error is often caused by an invalid license being installed that does not correctly 
	// decrypt the protected content. In order to debug the exact cause, you should look at the error codes printed by the 
	// Agent in the console while attempting to play the content.
	
	NSLog(@"Playback should be aborted notification received");
	
	[self alert:@"Content playback has failed. Please report this error"];
	
	// stop the player
	[self performSelectorOnMainThread:@selector(stopPlayback) withObject:nil waitUntilDone:NO];
}


- (void)willAbortPlayback:(NSNotification *)aNotification
{
	// triggered when the Agent has determined that a condition exists that prevents playback from working, such as for example
	// when a security breach has been detected (someone is trying to break into the DRM security).
	//
	// In this case the Agent will shutdown some internals components that will eventually force the player to quit, but you should
	// proactively terminate the playback from your side.
	
	NSLog(@"Playback will be aborted notification received");
	
	[self alert:@"Content playback has been aborted. Please report this error."];
	
	// stop the player
	[self performSelectorOnMainThread:@selector(stopPlayback) withObject:nil waitUntilDone:NO];
}


- (void)logMessage:(NSNotification *)aNotification
{	
	NSString *message = [aNotification object];
	
    @synchronized(messageLog)
    {
        // add this message to the array that keeps the logged messages
        [messageLog addObject:message];	
        
        // keep only the last 10000 lines
        if (messageLog.count > 10000)
        {
            [messageLog removeObjectAtIndex:0];
        }
    }
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- Modal dialogs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (void)alert:(NSString *)msg
{	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"SampleApp" message:msg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]; 
	[alert show]; 
	[alert release]; 
}


- (void)actionDialogWithMsg:(NSString *)msg buttonTitle:(NSString *)title tag:(int)tag
{
	UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"SampleApp" message:msg delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:title, nil];
	[alert setTag:tag];
	[alert show];
	[alert release];	
}


- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex
{
	if (alertView.tag == ACQUIRE_LICENSE_ALERT_TAG) 
	{    		
        if (buttonIndex == 1) 
		{   
			NSLog(@"User clicked on 'Get License' button");

			self.HUD = [MBProgressHUD showHUDAddedTo:[self view] animated:YES];
			HUD.labelText = @"Acquiring license...";
			
			[HUD showWhileExecuting:@selector(acquireLicenseAndPlay) onTarget:self withObject:nil animated:YES];
			return;
        }
		else
		{
			NSLog(@"User canceled the license acquisition");
		}		
    }
	else if (alertView.tag == LICENSE_ALREADY_AVAILABLE_ALERT_TAG || alertView.tag == PLAY_UNPROTECTED_CONTENT_ALERT_TAG)
	{		
		if (buttonIndex == 1)
		{
			[self performSelectorOnMainThread:@selector(startPlayback) withObject:nil waitUntilDone:NO];
			return;
		}
	}			
	else if (alertView.tag == RESET_DRM_DATABASE_ALERT_TAG)
	{
		if (buttonIndex == 1)
		{
			if ([DownloadableAgent resetDRMDatabase])
			{
				NSLog(@"DRM database reset successful");
				
				[self showFinishedTaskHUD: @"Database deleted"];
			}
			else 
			{
				[self alert:@"Failed to reset DRM database"];
			}
			return;
		}
	}
	
	// if the action was cancelled, release the Agent
	self.agent = nil;
}


- (void)showFinishedTaskHUD:(NSString *)label
{	
	if (!HUD)
	{
		self.HUD = [MBProgressHUD showHUDAddedTo:[self view] animated:YES];	
	}
	
	HUD.customView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"37x-Checkmark.png"]] autorelease];
	HUD.mode = MBProgressHUDModeCustomView;
	HUD.minShowTime = 2;
	HUD.labelText = label;
		
	[MBProgressHUD hideHUDForView:self.view animated:YES];		
	HUD = nil;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- View stuff
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // support only portrait orientation
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)didReceiveMemoryWarning 
{
    @synchronized(messageLog)
    {
        // purge the log messages
        [messageLog removeAllObjects];
    }
    
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidLoad
{
	// initialize the array the log storage
	self.messageLog = [NSMutableArray array];
	self.contentList = [NSMutableArray array];
    
    // load the saved user settings
    useAVFoundationPlayer = [[NSUserDefaults standardUserDefaults] boolForKey:@"useAVFoundationPlayer"];
    playerSwitch.on = useAVFoundationPlayer;
    
	/* Populate the list of content items */
    
	// Progressive download demo content	
    [contentList addObject:[ContentItem contentItemWithName:@" --- Progressive Download PIFF-----------------------------------" andURL:nil ofType:PIFFType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"The Simpsons Trailer 700Kbps" andURL:@"http://drmproducts-eu.authentec.com/content/device/PD/encrypted/TheSimpsonsMovie-Trailer_708.ismv" ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Dust to Glory 1 Mbps" andURL:@"http://drmproducts-eu.authentec.com/content/device/PD/encrypted/Dust_to_Glory_720_1000.ismv" ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Dust to Glory 2.5 Mbps" andURL:@"http://drmproducts-eu.authentec.com/content/device/PD/encrypted/Dust_to_Glory_720_2000.ismv" ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Big Buck Bunny 1.6 Mbps *RAW*" andURL:@"http://drmproducts-eu.authentec.com/content/device/PD/raw/BigBuckBunnyFULL_MOVIE_1644.ismv" ofType:PIFFType]];	
	
    // Local demo content
    [contentList addObject:[ContentItem contentItemWithName:@" --- Local PIFF files -------------------------------------------" andURL:nil ofType:PIFFType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"Simpsons" andURL:[[NSBundle mainBundle] pathForResource:@"simpsons_enc" ofType:@"ismv"] ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Wallstreet" andURL:[[NSBundle mainBundle] pathForResource:@"wallstreet_enc" ofType:@"ismv"] ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Super Speedway" andURL:[[NSBundle mainBundle] pathForResource:@"speed_enc" ofType:@"ismv"] ofType:PIFFType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Super Speedway *RAW*" andURL:[[NSBundle mainBundle] pathForResource:@"speed" ofType:@"ismv"] ofType:PIFFType]];

	// Smooth Streaming demo content
	[contentList addObject:[ContentItem contentItemWithName:@" --- Smooth Streaming test content ------------------------------" andURL:nil ofType:SmoothStreamingType]];		
	[contentList addObject:[ContentItem contentItemWithName:@"AuthenTec Downloadable Agent" andURL:@"http://drmproducts-eu.authentec.com/AuthenTecDRM/Manifest.ism/Manifest" ofType:SmoothStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"AuthenTec Downloadable Agent LIVE" andURL:@"http://drmproducts-eu.authentec.com/live/live.isml/Manifest" ofType:SmoothStreamingType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"Simpsons" andURL:@"http://drmproducts2.authentec.com/SimpsonsEncrypted/Manifest.ism/Manifest" ofType:SmoothStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Simpsons *RAW*" andURL:@"http://drmproducts2.authentec.com/simpsonsclear/manifest.ism/manifest" ofType:SmoothStreamingType]];		
	[contentList addObject:[ContentItem contentItemWithName:@"WallStreet" andURL:@"http://drmproducts2.authentec.com/WallStreet/Manifest.ism/Manifest" ofType:SmoothStreamingType]];	
	
	// HTTP Live Streaming demo content
	[contentList addObject:[ContentItem contentItemWithName:@" --- HTTP Live Streaming test content ---------------------------" andURL:nil ofType:HTTPLiveStreamingType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"Drifters for iPad" andURL:@"http://drmproducts-eu.authentec.com/content/iPad/HLS/encrypted/drifters/index.m3u8" ofType:HTTPLiveStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Drifters for iPhone" andURL:@"http://drmproducts-eu.authentec.com/content/iPhone/HLS/encrypted/drifters/index.m3u8" ofType:HTTPLiveStreamingType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"Drifters for iPad *RAW*" andURL:@"http://drmproducts-eu.authentec.com/content/iPad/HLS/raw/drifters/index.m3u8" ofType:HTTPLiveStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Drifters for iPhone *RAW*" andURL:@"http://drmproducts-eu.authentec.com/content/iPhone/HLS/raw/drifters/index.m3u8" ofType:HTTPLiveStreamingType]];	
	[contentList addObject:[ContentItem contentItemWithName:@"Bunny for iPad" andURL:@"http://drmproducts-eu.authentec.com/content/iPad/HLS/encrypted/bunny/index.m3u8" ofType:HTTPLiveStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Bunny for iPad *RAW*" andURL:@"http://drmproducts-eu.authentec.com/content/iPad/HLS/raw/bunny/index.m3u8" ofType:HTTPLiveStreamingType]];		
	[contentList addObject:[ContentItem contentItemWithName:@"NASA Live protected" andURL:@"http://drmproducts-eu.authentec.com/hls-live/index.m3u8" ofType:HTTPLiveStreamingType]];
	
	// other content items
	[contentList addObject:[ContentItem contentItemWithName:@" --- Other HLS Content ------------------------------" andURL:@"" ofType:HTTPLiveStreamingType]];
	[contentList addObject:[ContentItem contentItemWithName:@"Apple's keynote *RAW*" andURL:@"http://qthttp.apple.com.edgesuite.net/1009qpeijrfn2/0640_vod.m3u8" ofType:HTTPLiveStreamingType]];

    // for development/testing purposes only!
	// the file referenced in this method is not included in release packages.
	[self loadDebugTestContent];
    
	// set default URL in the text box to the first content item
	textbox.text = [(ContentItem *) [contentList objectAtIndex:0] contentURL];	

	// subscribe to debug logging messages broadcasted by the Agent (not available in production/protected library)
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(logMessage:) name:DownloadableAgentDidPostLogMessageNotification object:nil];	
}


- (void)viewDidUnload 
{		
	[[NSNotificationCenter defaultCenter] removeObserver:self];	

	self.messageLog = nil;
	self.contentList = nil;
    
    [super viewDidUnload];
}

/*
 Loads content URLs from a text file - not included in the SDK
 */
- (void)loadDebugTestContent
{
	NSString *testContentListPath = [[NSBundle mainBundle] pathForResource:@"testcontent" ofType:@"txt"];
	NSString *testContentList = [NSString stringWithContentsOfFile:testContentListPath encoding:NSUTF8StringEncoding error:nil];
	
	if (testContentList)
	{
		// split the playlist content in lines
		NSArray *lines = [NSArray arrayWithArray:[testContentList componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]];	
		
		for (int i=lines.count - 1; i>=0; i--)
		{
			NSString *contentItem = [[lines objectAtIndex:i] stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			
			if (!contentItem.length || [contentItem hasPrefix:@"//"] || [contentItem hasPrefix:@"#"])
			{
				continue;
			}
			
			NSArray *tokens = [contentItem componentsSeparatedByString:@","];
			
			if (tokens.count == 3)
			{
				NSString *name = [tokens objectAtIndex:0];
				NSString *url = [tokens objectAtIndex:1];
				DAContentType type = [[tokens objectAtIndex:2] intValue];			
				
                if (type == PIFFType && ![url hasPrefix:@"http"])
                {
                    // this is a local PIFF file embedded as an app resource, we need to obtain its absolute path
                    NSString *fileName = [url stringByDeletingPathExtension];
                    
                    url = [[NSBundle mainBundle] pathForResource:fileName ofType:@"ismv"];
                    
                    if (!url)
                    {
                        NSLog(@"ERROR: cannot find local PIFF file '%@.ismv'", fileName);
                        continue;
                    }
                }
                
                // insert at the begining
                [contentList insertObject:[ContentItem contentItemWithName:name andURL:url ofType:type] atIndex:0];
			}
			else 
			{
				NSLog(@"Malformed content item: %@", contentItem);
			}
		}
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- LicenseAcquisitionDelegate protocol implementation
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
 * This method performs a delegated license acquisition by sending an HTTP POST request to the license server
 * with the given URL and license challenge. On a successful response, the SOAP data received is passed onto the
 * agent in order to install the rights.
 *
 * If user authentication is desired before issuing a license, it should be done here.
 */
- (NSData *)performDelegatedLicenseAcquisition:(NSURL *)licenseAcquisitionURL withChallenge:(NSData *)challenge
{			
	NSLog(@"Delegated license acquisition callback");

	NSLog(@"LA_URL: %@", [licenseAcquisitionURL absoluteString]);
	NSLog(@"Challenge:\n%@", [[[NSString alloc] initWithData:challenge encoding:NSUTF8StringEncoding] autorelease]);
	
	// Craft the HTTP request that will be sent to the license server
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:licenseAcquisitionURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:30.0];	
		
	// This is a SOAP 1.1 request:
	[request setHTTPMethod:@"POST"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://schemas.microsoft.com/DRM/2007/03/protocols/AcquireLicense\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:challenge];
	
	NSHTTPURLResponse *response = nil;
	NSError *error = nil;
	
    NSLog(@"Sending the request to the server...");
    
	// send the request to the license server
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
	
	if (error != nil)
	{
		NSLog(@"License acquisition request failed with error: %@", [error localizedDescription]);					
	}
	else 
	{	
		// Note that a PlayReady license server might respond with HTTP status codes other than 200 when a domain is required
		// so it's a good idea to check the content-type header and at least ensure that the response body is a SOAP message.
		if (/*[response statusCode] == 200 && (*/ [[response MIMEType] hasPrefix:@"text/xml"] || [[response MIMEType] hasPrefix:@"application/soap+xml"] /*)*/) 
		{
			NSLog(@"License acquisition response obtained from the server:\n%@", [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease]);
			
			// return the server response to be processed by the Agent			
			return responseData;
		}
		else
		{
			NSLog(@"Invalid license acquisition response, it does not appear to be SOAP (content-type was: '%@')", [response MIMEType]);
		}
		
		NSLog(@"Server response: %@", [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease]);
	}
	
	// if the request failed or the response returned is not a SOAP message, just return nil to propagate the failure.
	return nil;
}


- (NSData *)performDelegatedJoinDomain:(NSURL *)domainControllerURL withChallenge:(NSData *)challenge
{
	NSLog(@"Delegated join domain callback");
	
	//NSLog(@"Domain server URL: %@", [domainControllerURL absoluteString]);
	//NSLog(@"Challenge:\n%@", [[[NSString alloc] initWithData:challenge encoding:NSUTF8StringEncoding] autorelease]);

	// Craft the HTTP request that will be sent to the domain server
	NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:domainControllerURL cachePolicy:NSURLRequestReloadIgnoringCacheData timeoutInterval:30.0];	
	
	// This is a SOAP 1.1 request:
	[request setHTTPMethod:@"POST"];
	[request setValue:@"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
	[request setValue:@"\"http://schemas.microsoft.com/DRM/2007/03/protocols/JoinDomain\"" forHTTPHeaderField:@"SOAPAction"];
	[request setHTTPBody:challenge];
	
	NSHTTPURLResponse *response = nil;
	NSError *error = nil;
	
	// send the request to the license server
	NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:&response error:&error];
	
	if (error != nil)
	{
		NSLog(@"Join domain request failed with error: %@", [error localizedDescription]);					
	}
	else 
	{	
		if ([response statusCode] == 200)
		{		
			if ([[response MIMEType] hasPrefix:@"text/xml"] || [[response MIMEType] hasPrefix:@"application/soap+xml"]) 
			{
				NSLog(@"Join domain response obtained from the server:\n%@", [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease]);
				
				// return the response to be processed by the Agent
				return responseData;
			}			
			else 
			{
				NSLog(@"Invalid join domain response, it does not appear to be SOAP (content-type was: '%@')", [response MIMEType]);
			}
		}
		else
		{
			NSLog(@"The domain controller replied with HTTP status code %i", [response statusCode]);
		}
		
		NSLog(@"Server response: %@", [[[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding] autorelease]);
	}
	
	// if the request failed or the response returned is not a SOAP message, just return nil to propagate the failure.
	return nil;	
}

/** end of protocol implementation **/


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#pragma mark -- UIPickerView delegate
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)thePickerView 
{	
	return 1;
}


- (NSInteger)pickerView:(UIPickerView *)thePickerView numberOfRowsInComponent:(NSInteger)component 
{	
	return [contentList count];
}


- (void)pickerView:(UIPickerView *)thePickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component 
{	
	// sets the textbox's URL to that of the item selected
	textbox.text = [(ContentItem *) [contentList objectAtIndex:row] contentURL];
}


- (UIView *)pickerView:(UIPickerView *)thePickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view 
{
	UILabel *retval = (id)view;
	
	if (!retval) 
		retval= [[[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, [thePickerView rowSizeForComponent:component].width, [thePickerView rowSizeForComponent:component].height)] autorelease];
	
	retval.text = [(ContentItem *) [contentList objectAtIndex:row] contentName];
	
	if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
		retval.font = [UIFont systemFontOfSize:14];
	else 
		retval.font = [UIFont systemFontOfSize:10];
	
	return retval;
}


@end
