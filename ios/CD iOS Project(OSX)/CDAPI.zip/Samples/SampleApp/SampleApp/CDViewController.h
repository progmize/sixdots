//
//  CDViewController.h
//  SampleApp
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDViewController : UIViewController

@end
