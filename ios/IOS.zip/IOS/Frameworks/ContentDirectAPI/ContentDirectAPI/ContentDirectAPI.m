//
//  ContentDirectAPI.m
//  ContentDirectAPI
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContentDirectAPI.h"

@implementation ContentDirectAPI

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
