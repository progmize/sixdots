package com.authentec.drm.android.reference;

import java.net.*;

import android.content.*;
import android.util.Log;
import com.authentec.drmagent.v2.*;
import com.authentec.drmagent.v2.utils.*;
import com.nextreaming.nexplayerengine.*;
import org.apache.http.client.methods.HttpRequestBase;

import static com.authentec.drm.android.reference.Tools.DEFENSE;

/**
* @author Authentec Inc.
*/
public class DRMAgentDelegate
{
    private static final String TAG = "DRMAgentDelegate";
    public static DRMAgent DRMAGENT;

    public static void intialize(final Context context)
    {
        if (DRMAGENT != null)
        {
            Log.d(TAG, "Already initialized, will not do that again");

            // Always update any of the preferences that are used dynamically
            final DRMAgentConfiguration drmAgentConfiguration = DRMAGENT.getDRMAgentConfiguration();

            final SharedPreferences authentec = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);

            drmAgentConfiguration.setNativePlayerBufferSize(authentec.getInt(Constants.PREFERENCES_NATIVE_PLAYER_BUFFER_SIZE,10000));
            drmAgentConfiguration.setUseNativePlayer(authentec.getBoolean(Constants.PREFERENCES_USE_NATIVE_PLAYER, false));
            drmAgentConfiguration.setIgnoreMimetypeValidationErrors(authentec.getBoolean(Constants.PREFERENCES_IGNORE_MIMETYPE_VALIDATION_ERRORS,true));

            DRMAGENT.setDRMAgentConfiguration(drmAgentConfiguration);

            return;
        }

        if (!DRMAgent.DRMAgentFactory.isInitialized())
        {
            // Load the certificates now
            try
            {
                Log.i(TAG, "Importing certificates and keys");
                DRMAgent.DRMAgentFactory.installPKI(context, PKIType.WMDRMPD_PRIVATE_KEY, context.getResources().openRawResource(R.raw.wm_privatekey));
                DRMAgent.DRMAgentFactory.installPKI(context, PKIType.WMDRMPD_TEMPLATE_CERTIFICATE, context.getResources().openRawResource(R.raw.wm_certificate));
                DRMAgent.DRMAgentFactory.installPKI(context, PKIType.PLAYREADY_MODEL_PRIVATE_KEY, context.getResources().openRawResource(R.raw.pr_privatekey));
                DRMAgent.DRMAgentFactory.installPKI(context, PKIType.PLAYREADY_MODEL_CERTIFICATE, context.getResources().openRawResource(R.raw.pr_certificate));
                Log.i(TAG, "Certificates and keys imported");
            }
            catch (Exception e)
            {
                Log.w(TAG, "Could not import certificates and keys: " + e.getMessage(), e);
            }
        }

        Log.d(TAG,"Device State: " + (DRMAgent.DRMAgentFactory.isSecureDevice(context) ? "Secure" : "Insecure"));

        // Setup and instantiate the DRM agent using the factory provided

        final SharedPreferences authentec = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        int logLevel = authentec.getInt(Constants.PREFERENCES_AGENT_LOG_LEVEL, 0);

        // Ensure the value is within bounds
        if (logLevel < 0 || logLevel >= DRMLogLevel.values().length)
        {
            if (logLevel < 0)
            {
                logLevel = 0;
            }
            else
            {
                logLevel = DRMLogLevel.values().length;
            }
        }

        Log.d(TAG,"Initializing DRM Agent with log level: " + logLevel + " : (" + DRMLogLevel.values()[logLevel] + ")");

        DRMAGENT = DRMAgent.DRMAgentFactory.getInstance(context, DRMLogLevel.values()[logLevel]);

        final DRMAgentConfiguration drmAgentConfiguration = DRMAGENT.getDRMAgentConfiguration();

        drmAgentConfiguration.setNativePlayerBufferSize(authentec.getInt(Constants.PREFERENCES_NATIVE_PLAYER_BUFFER_SIZE,10000));
        drmAgentConfiguration.setUseNativePlayer(authentec.getBoolean(Constants.PREFERENCES_USE_NATIVE_PLAYER,false));
        drmAgentConfiguration.setIgnoreMimetypeValidationErrors(authentec.getBoolean(Constants.PREFERENCES_IGNORE_MIMETYPE_VALIDATION_ERRORS,false));

        // This adds a global license acquisition handler - in the case where no acquisition handler is added to
        // the acquisition request, this instance will be used
        final PlayReadyDRMLicenseAcquisitionHandler drmLicenseAcquisitionHandler = new PlayReadyDRMLicenseAcquisitionHandler()
        {
            @Override
            protected void licenseInstalled()
            {
                Log.d(TAG,"License installed using the global DRM license acquisition handler");
                super.licenseInstalled();
            }
        };
        drmAgentConfiguration.setDRMLicenseAcquisitionHandler(drmLicenseAcquisitionHandler);

        drmAgentConfiguration.setHttpConnectionHelper(new HTTPConnectionHelperImpl()
        {
            @Override
            public void setupRequest(final HttpRequestBase httpRequestBase, final URL url)
            {
                // Allow the super class to do what it needs to do to the request (if anything)
                super.setupRequest(httpRequestBase, url);
                httpRequestBase.addHeader("AuthenTec", "1.0");

            }
        });

        // Update the configuration to be used
        drmAgentConfiguration.setUserAgent(Constants.DRM_AGENT_USER_STRING);

        // Update the configuration in the Agent
        DRMAGENT.setDRMAgentConfiguration(drmAgentConfiguration);

        // Add the DRM callback listener
        DRMAGENT.addDRMCallbackListener(new DRMCallbackListener()
        {
            public void contentActivated(final URI uri)
            {
                Log.d(TAG, "Content Activated: " + uri);
            }

            public void errorReceived(final DRMError drmError, final URI uri)
            {
                Log.d(TAG, "Error received: " + drmError);
            }

        });
    }

    public static String getDRMInformation(Context context)
    {
        final DRMAgentVersionInfo drmVersion = getDRMAgentVersionInfo(context);

        final NexPlayerGuard nexPlayerGuard = NexPlayerHandler.getNexPlayerGuard(context, 4);
        final NexPlayer nexPlayer = nexPlayerGuard.getNexPlayerInstance();

        String versionString = "Unknown";

        try
        {   versionString = nexPlayer.getVersion(0) + "." +
                nexPlayer.getVersion(1) + "." +
                nexPlayer.getVersion(2) + "." +
                nexPlayer.getVersion(3);
        }
        finally
        {
            nexPlayerGuard.release();
        }

        if (drmVersion != null)
        {
            return String.format("%s\t%s\n%s\t%s\n%s\t%s\n%s\t%s\n%s\t%s\n%s\t%s",
                    context.getString(R.string.drm_api_version_text), context.getString(R.string.drm_api_version),
                    context.getString(R.string.drm_native_version_text), drmVersion.getVersion(),
                    context.getString(R.string.drm_native_build_text), drmVersion.getBuildDate(),
                    context.getString(R.string.drm_playready_device_id),getDRMAgentInstance(context).getPlayReadyDeviceID().toString() ,
                    context.getString(R.string.drm_security_state), (DRMAgent.DRMAgentFactory.isSecureDevice(context) ? context.getString(R.string.drm_security_state_secure) : context.getString(R.string.drm_security_state_compromised)), context.getString(R.string.nexplayer_version_text),versionString
            );
        }
        return null;
    }

    public static DRMAgentVersionInfo getDRMAgentVersionInfo(Context context)
    {
        DRMAgentDelegate.intialize(context);

        return DRMAGENT.getDRMVersion();
    }

    public static void purgeCachedFiles(final Context context)
    {
        DRMAgentDelegate.intialize(context);
        DRMAGENT.purgeDatabase(DRMPurgeOption.CACHED_FILES);
        ContentHandler.clearCache();
    }

    public static void purgeLicenses(final Context context)
    {
        DRMAgentDelegate.intialize(context);
        // Time to purge the database
        DRMAGENT.purgeDatabase(DRMPurgeOption.LICENSES);
    }

    public static boolean joinDomain(final Context context, final byte[] acquireLicenseResponse, final PlayReadyDRMJoinDomainHandler playReadyDRMJoinDomainHandler)
    {
        DRMAgentDelegate.intialize(context);

        try
        {
            if (playReadyDRMJoinDomainHandler == null)
            {
                final JoinDomainRequest joinDomainRequest = new JoinDomainRequest(acquireLicenseResponse);
                return DRMAGENT.joinDomain(joinDomainRequest);
            }
            else
            {
                final JoinDomainRequest joinDomainRequest = new JoinDomainRequest(acquireLicenseResponse, playReadyDRMJoinDomainHandler);
                return DRMAGENT.joinDomain(joinDomainRequest);
            }
        }
        catch (DRMAgentException e)
        {
            Log.e(TAG, e.getMessage(), e);
            return false;
        }
    }

    public static boolean activateDRMContent(final Context context, final DRMContent drmContent, final DRMLicenseAcquisitionHandler drmLicenseAcquisitionHandler)
    {
        DRMAgentDelegate.intialize(context);

        try
        {
            DEFENSE("drmContent", drmContent);

            final AcquireLicenseRequest acquireLicenseRequest;
            if (drmLicenseAcquisitionHandler == null)
            {
                acquireLicenseRequest = new AcquireLicenseRequest(drmContent);
                acquireLicenseRequest.setDRMScheme(drmContent.getDRMScheme());
            }
            else
            {
                acquireLicenseRequest = new AcquireLicenseRequest(drmContent, drmLicenseAcquisitionHandler);
                acquireLicenseRequest.setDRMScheme(drmLicenseAcquisitionHandler.getRequiredDRMScheme());
            }
            acquireLicenseRequest.setCustomData("PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjxMaWNlbnNlUmVxdWVzdEN1c3RvbURhdGEgeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSIgeG1sbnM6eHNkPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYSI+DQogIDxVc2VyVG9rZW4+YTIyOTQzNzctNmFiOC00ZTVlLWFiNTItZTVkYTBlMzk5ZTVjPC9Vc2VyVG9rZW4+DQogIDxCcmFuZEd1aWQ+ZjlmNjJjMDMtOGU0My00Y2VhLWFlYzItMDU4ZDg0OTAyMzRjPC9CcmFuZEd1aWQ+DQo8L0xpY2Vuc2VSZXF1ZXN0Q3VzdG9tRGF0YT4=");
            return DRMAGENT.acquireLicense(acquireLicenseRequest);
        }
        catch (DRMAgentException e)
        {
            Log.e(TAG, e.getMessage(), e);
            return false;
        }
    }


    public static DRMContent getDRMContent(final Context context, final URI uri, DRMContentFormat drmContentFormat, DRMScheme drmScheme)
    {
        DRMAgentDelegate.intialize(context);

        return DRMAGENT.getDRMContent(uri, drmContentFormat, drmScheme);
    }

    public static DRMAgent getDRMAgentInstance(final Context context)
    {
        DRMAgentDelegate.intialize(context);
        return DRMAGENT;
    }

    public static void addDRMCallbackListener(final Context context, final DRMCallbackListener drmCallbackListener)
    {
        DRMAgentDelegate.intialize(context);
        DRMAGENT.addDRMCallbackListener(drmCallbackListener);
    }

    public static void addHDMIBroadcastReceiver(final Context context)
    {
        DRMAgentDelegate.intialize(context);
        DRMAGENT.addHDMIBroadcastReceiver(context);
    }

    public static void removeHDMIBroadcastReceiver(final Context context)
    {
        DRMAgentDelegate.intialize(context);
        DRMAGENT.removeHDMIBroadcastReceiver(context);
    }


    public static void uninitialize()
    {
        DRMAgent.DRMAgentFactory.releaseInstance();
        DRMAGENT = null;
    }

    public static void removeDRMCallbackListener(final Context context, final DRMCallbackListener drmCallbackListener)
    {
        DRMAgentDelegate.intialize(context);
        DRMAGENT.removeDRMCallbackListener(drmCallbackListener);
    }
}
