//
//  StarsView.m
//  Chicago
//
//  Created by Derr on 9/13/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHStarsView.h"


@implementation CHStarsView

- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
			starImage = [UIImage imageNamed:@"star.png"];
    }
    return self;
}


- (int)stars {
    return stars;
}
- (void)setStars:(int)howMany {
	stars = howMany;
	[self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect {
	CGContextRef current = UIGraphicsGetCurrentContext();
	CGContextScaleCTM(current, 1., -1.);
	for (int star = 0; star < self.stars; ++star) {
		CGContextDrawImage(current, CGRectMake(star * starImage.size.width, -starImage.size.height, starImage.size.width, starImage.size.height), [starImage CGImage]);
	}
}

- (void)dealloc {
	starImage = nil;
}


@end
