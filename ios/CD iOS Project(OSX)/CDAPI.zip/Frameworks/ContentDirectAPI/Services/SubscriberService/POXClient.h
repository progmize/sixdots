//
//  POXClient.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/28/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "Fault.h"

// Forward declaration of POXClientDelegate.
@protocol POXClientDelegate;


@interface POXClient : NSObject {
	NSOperationQueue *operationQueue;

  id <POXClientDelegate> delegate;
}

// The delegate is passed in to the call.
//@property (assign) id<POXClientDelegate> delegate;

// This is synchronous.
- (NSDictionary *)callPOXEndpoint:(NSURL *)urlEndpoint input:(NSDictionary *)inputDictionary;

// Async - but this is limited to one call at a time.
// This overrides the previous delegate.
- (void)callPOXEndpoint:(NSURL *)urlEndpoint input:(NSDictionary *)inputDictionary delegate:(id)aDelegate;
@end


@protocol POXClientDelegate
// Async callback after calling callPOXEndpoint:input:delegate:
- (void)resultsForLastCallPOXEndpoint:(NSURL *)urlEndpoint output:(NSDictionary *)outputDictionary;
- (void)lastCallFailedForPOXEndpoint:(NSURL *)urlEndpoint fault:(Fault *)fault;
@end
