//
//  AVPlayerViewController.h
//
//  This implementation is partially based on Apple's example code at:
//  http://developer.apple.com/library/ios/#samplecode/AVPlayerDemo/
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

/*
 The view to be used by the player to render video on
 */
@interface AVPlayerView : UIView 

@property (nonatomic, retain) AVPlayer *player;

@end

/*
 A view controller that implements an AVPlayer with a simple UI.
 The playback is initiated automatically for the AVPlayerItem passed on initialization.
 */
@interface AVPlayerViewController : UIViewController
{
    // the video player instance
    AVPlayer *player;
    
    // UI elements
    IBOutlet UISlider *mScrubber;
    IBOutlet UIToolbar *mToolbar;
    IBOutlet UIBarButtonItem *mPlayButton;
    IBOutlet UIBarButtonItem *mPauseButton;
    IBOutlet UIBarButtonItem *mDoneButton;
    IBOutlet AVPlayerView *playerView;
    
    float mRestoreAfterScrubbingRate;
	BOOL seekToZeroBeforePlay;
	id mTimeObserver;
}

@property (nonatomic, retain) AVPlayer *player;
@property (nonatomic, retain) IBOutlet UIToolbar *mToolbar;
@property (nonatomic, retain) IBOutlet UISlider* mScrubber;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *mPlayButton;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *mPauseButton;
@property (nonatomic, retain) IBOutlet UIBarButtonItem *mDoneButton;
@property (nonatomic, retain) IBOutlet AVPlayerView *playerView;

- (id)initWithAVPlayerItem:(AVPlayerItem *)playerItem;

- (IBAction)play:(id)sender;
- (IBAction)pause:(id)sender;
- (IBAction)done:(id)sender;

@end


