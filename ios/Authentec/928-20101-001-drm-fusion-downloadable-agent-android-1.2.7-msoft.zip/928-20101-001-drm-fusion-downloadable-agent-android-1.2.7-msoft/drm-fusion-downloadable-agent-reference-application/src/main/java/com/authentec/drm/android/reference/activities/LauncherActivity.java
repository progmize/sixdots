package com.authentec.drm.android.reference.activities;


import android.app.Activity;
import android.content.Intent;
import android.os.*;
import android.view.*;

import android.widget.TextView;
import com.authentec.drm.android.reference.*;

/**
 * @author AuthenTec Inc.
 */
public class LauncherActivity extends Activity
{
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.launcher);

        final Handler handler = new Handler(Looper.myLooper());

        final Runnable runnable = new Runnable()
        {
            public void run()
            {
                startActivity(new Intent(getBaseContext(), HomeActivity.class));
                finish();
            }
        };
        handler.postDelayed(runnable, 1000);


        final TextView text = (TextView) findViewById(R.id.init_messages);
        String formatted = String.format("%s v%s",getText(R.string.dialog_title),getText(R.string.drm_api_version));
        text.setText(formatted);

        final View id = this.findViewById(R.id.launcher);


        id.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(final View view)
            {
                handler.removeCallbacks(runnable);
                startActivity(new Intent(getBaseContext(), HomeActivity.class));
                finish();
            }
        });
        id.setClickable(true);

    }

}
