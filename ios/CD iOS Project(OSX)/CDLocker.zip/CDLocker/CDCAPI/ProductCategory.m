//
//  ProductCategory.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "ProductCategory.h"


@implementation ProductCategory

@synthesize categoryID;
@synthesize name;


- (NSString *)description {
  return [NSString stringWithFormat:@"ProductCategory ID:%@ Name:%@", self.categoryID, self.name];
}

@end
