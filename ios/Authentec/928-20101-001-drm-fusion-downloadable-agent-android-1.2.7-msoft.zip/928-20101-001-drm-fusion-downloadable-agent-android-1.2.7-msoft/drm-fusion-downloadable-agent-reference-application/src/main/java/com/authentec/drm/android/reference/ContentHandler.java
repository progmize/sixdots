package com.authentec.drm.android.reference;

import java.io.*;
import java.net.*;
import java.util.*;

import android.content.*;
import android.content.res.AssetManager;
import android.net.Uri;
import android.util.Log;
import com.authentec.drmagent.v2.*;
import org.xmlpull.v1.*;

/** Represents a basic content management system to keep track of references to content that is available on the device.
 * The content is loaded via XML descriptor files located in <i>/sdcard/authentec</i>.
 *
 * @author AuthenTec Inc.
 */
public class ContentHandler
{
    public static final String TAG = "ContentHandler";
    public static final String CONTENT_DESCRIPTOR_PATH = "/sdcard/authentec";

    private static XmlPullParserFactory mParserFactory;
    private static XmlPullParser mParser;

    private static Set<String> mLastLoadedListFileNames = new HashSet<String>();
    private static List<DRMContentInfo> mLastLoadedDRMContentInfos = new ArrayList<DRMContentInfo>();

    /**
     *
     */
    public static void initialize()
    {
        try
        {
            final File f = new File(CONTENT_DESCRIPTOR_PATH);

            if (!f.exists())
            {
                if (!f.mkdir())
                {
                    Log.w(TAG, "Could not create content directory: " + CONTENT_DESCRIPTOR_PATH);
                }
                else
                {
                    Log.d(TAG, "Created content directory: " + CONTENT_DESCRIPTOR_PATH);
                }
            }
            else
            {
                // Verfify it is a directory!
                if (!f.isDirectory())
                {
                    Log.e(TAG, "Content directory is actually a file!");
                }
            }

        }
        catch (Exception e)
        {
            Log.e(TAG, e.getMessage(), e);
        }
    }

    /**
     *
     * @param context
     */
    public static void addDefaultContent(final Context context)
    {
        try
        {
            final AssetManager assetManager = context.getAssets();

            String[] assets = assetManager.list("cdesc");

            for (String asset : assets)
            {
                Log.d(TAG,"Opening asset: " + asset);
                try
                {
                    InputStream open = assetManager.open("cdesc/" + asset);
                    FileOutputStream outputStream = new FileOutputStream(CONTENT_DESCRIPTOR_PATH + "/" + asset);
                    Tools.copyStream(open, outputStream);
                    open.close();
                    outputStream.flush();
                    outputStream.close();
                }
                catch (Exception e)
                {
                    Log.e(TAG, "Error while opening asset: " + asset,e);
                }
            }
        }
        catch (Exception e)
        {
            Log.e(TAG,"Error while listing assets: " + e.getMessage(),e);
        }

    }

    /**
     *
     * @param context
     * @param contentDescriptorLocation
     * @param validateLocalFiles
     * @return
     */
    public static DRMContentInfo retrieveDRMContentInfo(final Context context, final String contentDescriptorLocation, final boolean validateLocalFiles, final boolean loadDRMInformation)
    {
        initialize();
        return processContentDescriptor(context, new File(contentDescriptorLocation), validateLocalFiles, loadDRMInformation);
    }

    /**
     *
     * @param context
     * @param uri
     * @return
     */
    public static DRMContentInfo createDRMContentInfoForUnknownURI(final Context context, final URI uri)
    {
        boolean sufficientInformationFound = true;

        DRMContentInfo drmContentInfo = null;
        DRMContentFormat drmContentFormat = null;

        if (uri.getScheme() != null && uri.getScheme().equals("http"))
        {
            if(uri.toString().endsWith("m3u8") || uri.toString().endsWith("m3u"))
            {
                drmContentFormat = DRMContentFormat.HTTP_LIVE_STREAMING;
            }
            else if(uri.toString().endsWith("manifest") || uri.toString().endsWith("Manifest"))
            {
                drmContentFormat = DRMContentFormat.SMOOTH_STREAMING;
            }
            else if(uri.toString().endsWith(".wmv") || uri.toString().endsWith(".wma"))
            {
                drmContentFormat = DRMContentFormat.WINDOWS_MEDIA;
            }
            else if(uri.toString().endsWith(".pyv") || uri.toString().endsWith(".pya") || uri.toString().endsWith(".asf"))
            {
                drmContentFormat = DRMContentFormat.PLAYREADY_ASF;
            }
            else if(uri.toString().endsWith(".piff"))
            {
                drmContentFormat = DRMContentFormat.PIFF;
            }
            else
            {
                //format not recognized
                sufficientInformationFound = false;
            }
        }
        else
        {
            //format not recognized
            sufficientInformationFound = false;
        }

        if (sufficientInformationFound)
        {
            Log.d(TAG,"Sufficient information available, will populate an object instance for " + uri);
            drmContentInfo = new DRMContentInfo();
            drmContentInfo.mContentLocation = uri;
            drmContentInfo.mDRMContent = DRMAgentDelegate.getDRMAgentInstance(context).getDRMContent(uri,drmContentFormat);
        }
        else
        {
            URL uRLToUse = null;
            try
            {
                uRLToUse = uri.toURL();
            }
            catch (MalformedURLException malformedURLException)
            {
                throw new DescriptorLoadException(null,null , "Format not recognized from url (" + uri.toString() + ")");
            }

            throw new DescriptorLoadException(null,uRLToUse , "Format not recognized from url.");
        }

        return drmContentInfo;

    }

    public static void clearCache()
    {
        mLastLoadedListFileNames.clear();
        mLastLoadedDRMContentInfos.clear();
    }

    /** Listener API which is called as valid descriptor files are found.
     */
    public static interface ContentListener
    {
        /** Method invoked whenever a content descriptor has been added to the content handler.
         *
         * @param contentDescriptorLocation The path to the content descriptor
         */
        public void contentAdded(final String contentDescriptorLocation);
    }

    public static void signalContentAdded(final String contentDescriptorLocation)
    {

    }

    /** Listener API which is called as valid descriptor files are found.
     */
    public static interface ContentRetrieverListener
    {
        /** Method invoked whenever a valid content descriptor has been found.
         *
         * @param drmContentInfo A valid content descriptor
         */
        public void drmContentInfoRetrieved(final DRMContentInfo drmContentInfo);

        /** Method invoked whenever a error occured while processing a descriptor
         *
         * @param name The name of the file being processed
         * @param url The URL (may be null if could not be read) of the content.
         */
        public void drmContentInfoRetrievalFailed(final File name, final URL url);
    }

    /** Retrieves the list of content information found.  This will attempt to load all the descriptors available and
     * may impose some network I/O.
     *
     * @param context The context to use for resolving information as need be
     * @param validateLocalFiles Whether the content descriptors found should be validated if pointing to local media files
     * @param contentRetrieverListener Listener which is invoked for each valid descriptor found.  Allows for progressive
     * updates of content lists for example
     * @return The fully loaded list of valid content descriptors
     */
    public static List<DRMContentInfo> retrieveDRMContentInfos(final Context context, boolean validateLocalFiles, final boolean loadDRMInformation, final ContentRetrieverListener contentRetrieverListener)
    {
        initialize();

        Log.d(TAG, "Retrieving content");

        final List<DRMContentInfo> drmContentInfos = new ArrayList<DRMContentInfo>();

        final File[] files = retrieveContentDescriptorFiles();

        final Set<String> loadedFileNames = convertToNameSet(files);

        if (loadedFileNames.size() == mLastLoadedListFileNames.size() && mLastLoadedListFileNames.containsAll(loadedFileNames))
        {
            Log.d(TAG, "Using cached content for now");

            if (contentRetrieverListener != null)
            {
                for (DRMContentInfo drmContentInfo : mLastLoadedDRMContentInfos)
                {
                    contentRetrieverListener.drmContentInfoRetrieved(drmContentInfo);
                }
            }
            // Return cached list
            return mLastLoadedDRMContentInfos;
        }

        loadedFileNames.clear();

        if (files != null)
        {
            for (final File file : files)
            {
                try
                {
                    final DRMContentInfo drmContentInfo = processContentDescriptor(context, file, validateLocalFiles, loadDRMInformation);
                    if (drmContentInfo != null)
                    {
                        if (contentRetrieverListener != null)
                        {
                            contentRetrieverListener.drmContentInfoRetrieved(drmContentInfo);
                        }
                        loadedFileNames.add(file.getAbsolutePath());
                        drmContentInfos.add(drmContentInfo);
                    }
                    else
                    {
                        // Error loading the descriptor in question
                        if (contentRetrieverListener != null)
                        {
                            contentRetrieverListener.drmContentInfoRetrievalFailed(file,null);
                        }
                    }
                }
                catch (DescriptorLoadException e)
                {
                    // Error loading the descriptor in question
                    if (contentRetrieverListener != null)
                    {
                        contentRetrieverListener.drmContentInfoRetrievalFailed(e.mDescriptorFile, e.mURl);
                    }
                }

            }

        }

        mLastLoadedListFileNames = loadedFileNames;
        mLastLoadedDRMContentInfos = drmContentInfos;

        return drmContentInfos;
    }

    private static Set<String> convertToNameSet(final File[] files)
    {
        Set<String> names = new HashSet<String>();
        if (files != null)
        {
            for (File file : files)
            {
                names.add(file.getAbsolutePath());
            }
        }
        return names;
    }

    public static List<DRMContentInfo> retrieveDRMContentInfos(final Context context, final boolean validateLocalFiles, final boolean loadDRMInformation)
    {
       return retrieveDRMContentInfos(context, validateLocalFiles, loadDRMInformation,null);
    }

    private static File[] retrieveContentDescriptorFiles()
    {
        final File baseDir = new File("/sdcard/authentec");
        return baseDir.listFiles(new FileFilter()
        {
            public boolean accept(final File file)
            {
                return (file.isFile() && file.getName().endsWith(".cdesc"));
            }
        });
    }

    private static DRMContentInfo processContentDescriptor(final Context context, final File file, final boolean validateLocalFiles, final boolean loadDRMInformation)
    {
        try
        {
            Log.d(TAG,"Processing descriptor: " + file);
            // First try to parse it as XML
            DRMContentInfo drmContentInfo = parseAsXML(context, file,validateLocalFiles, loadDRMInformation);

            if (validateLocalFiles && drmContentInfo != null)
            {
                // Perform some sanity checking of the content - this will check if the content is actually
                // DRM protected (if the descriptors indicate they are).  Prevents errors further down the
                // road
                try
                {
                    if (drmContentInfo.mDRMContent.getDRMScheme() != DRMScheme.CLEARTEXT)
                    {
                        drmContentInfo.mDRMContent.getDRMRights();
                    }
                }
                catch (DRMAgentException e)
                {
                    // If this happens in the above call, there is some inconsistency with the content!
                    Log.d(TAG, "Peeking at content caused error: " + e.getMessage());
                    Log.d(TAG, "This indicates the content located at " +
                            "'" + drmContentInfo.mContentLocation + "' " +
                            "is marked as DRM protected and the DRM Agent detected the content to be CLEARTEXT.  " +
                            "Please verify your content descriptor");
                    throw new DescriptorLoadException(file, drmContentInfo.mContentLocation.toURL(), e.getMessage());
                }
            }

            // The try property
            return drmContentInfo;
        }
        catch (DescriptorLoadException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            Log.e(TAG, "Error while parsing XML: " + e.getMessage(), e);
            throw new DescriptorLoadException(file, null, e.getMessage());
        }
    }

    private static URI performValidationAndRewrite(final boolean validateLocalFiles, final String uriStr) throws URISyntaxException
    {
        if (uriStr == null)
        {
            throw new NullPointerException("No URI specified");
        }

        Log.d(TAG,"Resolving URI: " + uriStr);

        URI uri;
        if (uriStr.startsWith("file://") || uriStr.startsWith("http://")|| uriStr.startsWith("https://") )
        {
            uri = new URI(uriStr);
        }
        else
        {
            File f = new File("/sdcard/authentec/",uriStr);
            uri = f.toURI();
        }

        Log.d(TAG,"URI resolved to: " + uri);

        if (validateLocalFiles && (uri.getScheme() == null || "file".equals(uri.getScheme())))
        {
            Log.d(TAG,"Verifying local URI: " + uri );
            // Verify the file exists as well!
            File f = new File(uri.getPath());
            if (!f.exists())
            {
                throw new RuntimeException("Local file specified by '" + uriStr + "' could not be found");
            }
        }

        return uri;
    }

    public static DRMContentInfo parseAsXML(final Context context, final File file, final boolean validateLocalFiles, final boolean attemptLoadDRMInformation)
    {
        URL contentLocation = null;

        try
        {
            Log.d(TAG, "Attempting to parse " + file + " as XML content descriptor");

            long t1 = System.currentTimeMillis();

            if (mParserFactory == null)
            {
                mParserFactory = XmlPullParserFactory.newInstance();
            }
            if (mParser == null)
            {
                mParser = mParserFactory.newPullParser();
            }

            mParser.setInput(new BufferedReader(new FileReader(file), 8192));

            long t2 = System.currentTimeMillis();

            Log.d(TAG, "Parser setup and initialized in " + (t2 - t1) + " millisecond(s)");


            t1 = System.currentTimeMillis();

            int parserEvent = mParser.getEventType();
            String tag = null;
            DRMContentInfo drmContentInfo = null;
            DRMScheme drmScheme = null;
            DRMContentFormat drmContentFormat = null;

            while (parserEvent != XmlPullParser.END_DOCUMENT)
            {
                switch (parserEvent)
                {
                    case XmlPullParser.START_TAG:
                        tag = mParser.getName();
                        if ("Descriptor".equals(tag))
                        {
                            drmContentInfo = new DRMContentInfo();
                        }
                    case XmlPullParser.END_TAG:
                        break;
                    case XmlPullParser.TEXT:
                        String text = mParser.getText();
                        if (text.trim().length() == 0)
                        {
                            break;
                        }
                        if (drmContentInfo != null)
                        {
                            if (text.trim().length() == 0) break;
                            else if (tag.compareTo("Title") == 0)
                            {
                                drmContentInfo.mTitle = text;
                            }
                            else if (tag.compareTo("URL") == 0)
                            {
                                drmContentInfo.mContentLocation = performValidationAndRewrite(validateLocalFiles, text);
                                contentLocation = drmContentInfo.mContentLocation.toURL();
                            }
                            else if (tag.compareTo("LA_URL_OVERRIDE") == 0)
                            {
                                verifyURL(text);
                                drmContentInfo.mLaURLOverride = text;
                            }
                            else if (tag.compareTo("Protection") == 0)
                            {
                                drmScheme = resolveDRMScheme(text);
                            }
                            else if (tag.compareTo("LocalFile_ServerPath") == 0)
                            {
                                // What now?
                                drmContentInfo.mLocalFileServerPath = text;
                            }
                            else if (tag.compareTo("StreamType") == 0)
                            {
                                drmContentFormat = resolveDRMContentFormat(text);
                                drmContentInfo.mContentFormatFromCdesc = text;
                            }
                            else if (tag.compareTo("StreamLive") == 0)
                            {
                                drmContentInfo.mStreamLive = ("1".equals(text));
                            }
                            else if (tag.compareTo("Author") == 0)
                            {
                                drmContentInfo.mAuthor = text;
                            }
                            else if (tag.compareTo("Genres") == 0)
                            {
                                drmContentInfo.mGenres = text;
                            }
                            else if (tag.compareTo("Language") == 0)
                            {
                                drmContentInfo.mLanguage= text;
                            }
                            else if (tag.compareTo("ShortDescription") == 0)
                            {
                                drmContentInfo.mShortDescription= text;
                            }
                            else if (tag.compareTo("LongDescription") == 0)
                            {
                                drmContentInfo.mLongDescription= text;
                            }
                            else if (tag.compareTo("Container") == 0)
                            {
                                drmContentInfo.mContainer= text;
                            }
                            else if (tag.compareTo("AudioCodec") == 0)
                            {
                                drmContentInfo.mAudioCodec= text;
                            }
                            else if (tag.compareTo("AudioChannels") == 0)
                            {
                                drmContentInfo.mAudioChannels= text;
                            }
                            else if (tag.compareTo("VideoCodec") == 0)
                            {
                                drmContentInfo.mVideoCodec= text;
                            }
                            else if (tag.compareTo("Width") == 0)
                            {
                                drmContentInfo.mWidth= text;
                            }
                            else if (tag.compareTo("Height") == 0)
                            {
                                drmContentInfo.mHeight= text;
                            }
                            else if (tag.compareTo("BitDepth") == 0)
                            {
                                drmContentInfo.mBitDepth= text;
                            }
                            else if (tag.compareTo("BitRate") == 0)
                            {
                                drmContentInfo.mBitRate= text;
                            }
                            else if (tag.compareTo("Framerate") == 0)
                            {
                                drmContentInfo.mFramerate= text;
                            }
                            else if (tag.compareTo("Runtime") == 0)
                            {
                                drmContentInfo.mRuntime= text;
                            }
                            else if (tag.compareTo("Picture") == 0)
                            {
                                drmContentInfo.mPicture= text;
                            }
                            else if (tag.compareTo("Thumbnail") == 0)
                            {
                                drmContentInfo.mThumbnail= text;
                            }
                          break;


                        }
                        break;
                }
                parserEvent = mParser.next();
            }
            t2 = System.currentTimeMillis();
            Log.d(TAG, "Content descriptor parsed in " + (t2 - t1) + " millisecond(s)");

            if (drmContentInfo != null && drmScheme != null && drmContentFormat != null)
            {
                Log.d(TAG, "Have sufficient information from parsing the XML, will return DRM content info");
                if (attemptLoadDRMInformation)
                {
                    drmContentInfo.mDRMContent = DRMAgentDelegate.getDRMContent(context, drmContentInfo.mContentLocation, drmContentFormat, drmScheme);
                }
                drmContentInfo.mContentDescriptorLocation = file.getAbsolutePath();

                return drmContentInfo;
            }
            else
            {
                Log.d(TAG, "Not enough information retrieved during parsing");
                Log.d(TAG, "DRMContentInfo: " + drmContentInfo);
                Log.d(TAG, "DRMScheme: " + drmScheme);
                Log.d(TAG, "DRM Content Format: " + drmContentFormat);
                return null;
            }
        }
        catch (Exception e)
        {
            Log.e(TAG, "Error while parsing XML descriptor '" + file.getAbsolutePath() + "' : " + e.getMessage(), e);
            throw new DescriptorLoadException(file,contentLocation, e.getMessage());
        }
    }

    private static void verifyURL(final String urlStr)
    {
        try
        {
            new URL(urlStr);
        }
        catch (MalformedURLException e)
        {
            Log.e(TAG,"Error while validating URL: " + urlStr);
            throw new RuntimeException("Error while validating URL: " + urlStr, e);
        }
    }

    private static DRMContentFormat resolveDRMContentFormat(final String text)
    {
        try
        {
            return DRMContentFormat.valueOf(text);
        }
        catch (IllegalArgumentException e)
        {
            if (text.equals("PR ASF"))
            {
                return DRMContentFormat.PLAYREADY_ASF;
            }
            else if (text.equals("WM ASF"))
            {
                return DRMContentFormat.WINDOWS_MEDIA;
            }
            else if (text.equals("HLS"))
            {
                return DRMContentFormat.HTTP_LIVE_STREAMING;
            }
            else if (text.equals("Smooth Streaming"))
            {
                return DRMContentFormat.SMOOTH_STREAMING;
            }
            else if (text.equals("PR ENVELOPE"))
            {
                return DRMContentFormat.PLAYREADY_ENVELOPE;
            }
            else if (text.equals("OMA DCF"))
            {
                return DRMContentFormat.OMA20_DCF;
            }
            else
            {
                throw new RuntimeException("Unrecognized DRM scheme: " + text);
            }
        }
    }

    private static DRMScheme resolveDRMScheme(final String text)
    {
        try
        {
            return DRMScheme.valueOf(text);
        }
        catch (IllegalArgumentException e)
        {
            if (text.equals("Unprotected"))
            {
                return DRMScheme.CLEARTEXT;
            }
            else if (text.equals("MS PlayReady"))
            {
                return DRMScheme.PLAYREADY;
            }
            else if (text.equals("WM DRM"))
            {
                return DRMScheme.WMDRM;
            }
            else if (text.equals("OMA DRM"))
            {
                return DRMScheme.WMDRM;
            }
            else
            {
                throw new RuntimeException("Unrecognized DRM scheme: " + text);
            }
        }
    }

    public static void deleteContent(DRMContentInfo drmContentInfo, boolean removeFromList)
    {
        initialize();
        final File f = new File(drmContentInfo.mContentDescriptorLocation);
        Log.d(TAG, "Deleting " + f);
        if (!f.delete())
        {
            Log.d(TAG, "Deleted file, but for some reason it was not properly deleted");
        }
        //delete local file (if needed)
        if(drmContentInfo.mContentLocation.getScheme().compareToIgnoreCase("file")==0)
        {
            //delete local file
            final File localFile = new File(drmContentInfo.mContentLocation);
            Log.d(TAG, "Deleting local file " + localFile);
            if (!localFile.delete())
            {
                Log.d(TAG, "Deleted local file, but for some reason it was not properly deleted");
            }
        }

        if(removeFromList)
        {
            mLastLoadedDRMContentInfos.remove(drmContentInfo);
            mLastLoadedListFileNames.remove(f.getAbsolutePath());
        }
    }
    public static void deleteContent(DRMContentInfo drmContentInfo)
    {
        deleteContent(drmContentInfo,  true);
    }

    public static void deleteAllContent()
    {
        initialize();

        Log.d(TAG, "Deleting all content (including local files)");

        for (DRMContentInfo drmContentInfo : mLastLoadedDRMContentInfos)
        {
            deleteContent(drmContentInfo, false);
        }

        mLastLoadedDRMContentInfos.clear();
        mLastLoadedListFileNames.clear();
    }

    public static boolean isClearText(final DRMContentInfo drmContentInfo)
    {
        return drmContentInfo.mDRMContent.getDRMScheme() == DRMScheme.CLEARTEXT;
    }

    public static DRMRights.DRMRightsType retrieveDRMRightsType(final DRMContentInfo drmContentInfo)
    {
        return drmContentInfo.mDRMContent.getDRMRights().getDRMRightsType();
    }

    public static DRMScheme retrieveDRMScheme(final DRMContentInfo contentInfo)
    {
        return contentInfo.mDRMContent.getDRMScheme();
    }

    public static boolean hasRights(final DRMContentInfo drmContentInfo)
    {
        return drmContentInfo.mDRMContent.getDRMScheme() == DRMScheme.CLEARTEXT
                || drmContentInfo.mDRMContent.getDRMRights().getDRMRightsType() == DRMRights.DRMRightsType.VALID;
    }

    private static class DescriptorLoadException extends RuntimeException
    {
        File mDescriptorFile;
        URL mURl;
        String mErrorMessage;

        private DescriptorLoadException(final File mDescriptorFile, final URL mURl, final String mErrorMessage)
        {
            super("Error loading descriptor at " + mDescriptorFile + " (" + mURl + ") with error message: " + mErrorMessage);
            this.mDescriptorFile = mDescriptorFile;
            this.mURl = mURl;
            this.mErrorMessage = mErrorMessage;
        }
    }
}
