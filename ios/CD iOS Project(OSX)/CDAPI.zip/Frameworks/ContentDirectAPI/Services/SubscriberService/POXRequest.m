//
// POXRequest.m
// ContentDirect POX API
//
// Created by Luis de la Rosa on 7/28/10.
// Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "POXRequest.h"
#import "POXClient.h"
#import "XPathQuery.h"
#import "XMLEncoder.h"
#import "OrderedDictionary.h"


@implementation POXRequest

@synthesize urlEndpoint;
@synthesize inputDictionary;
@synthesize delegate;

#pragma mark NSObject
#pragma mark -
- (id)init {
  self = [super init];

  if (self != nil) {
    data         = [[NSMutableData alloc] init];
    urlRequest   = nil;
    responseCode = -1;
  }

  return self;
}




#pragma mark XML
#pragma mark -

- (NSString *)convertInputDictionaryToXMLString {
  // Convert an NSDictionary to NSString
  XMLEncoder *xmlEncoder = [[XMLEncoder alloc] init];

  xmlEncoder.prettyPrint = YES;
  NSString *outputString = [xmlEncoder xmlFromDictionary:self.inputDictionary];
  return outputString;

}


#pragma mark Error Handling
#pragma mark -
- (void)handleError:(NSError *)error {
  //NSLog(@"POXRequest Error:%@", error);

  // Call delegate error callback
  Fault *fault = [[Fault alloc] init];
  fault.typeName = @"Connection failed.";
  fault.message  = [error localizedDescription];
  [delegate lastCallFailedForPOXEndpoint:urlEndpoint fault:fault];
}


#pragma mark NSOperation
#pragma mark -
- (NSTimeInterval)maximumTimeout {
  return 10;
}


- (BOOL)isConcurrent {
  return YES;
}


- (void)setExecuting:(BOOL)b {
  [self willChangeValueForKey:@"isExecuting"];
  isExecuting = b;
  [self didChangeValueForKey:@"isExecuting"];

  // TODO allow client of API to determine if they want to show network activity indicator.
// [UIApplication sharedApplication].networkActivityIndicatorVisible = b;
}


- (BOOL)isExecuting {
  return isExecuting;
}


- (void)setFinished:(BOOL)b {
  [self willChangeValueForKey:@"isFinished"];
  isFinished = b;
  [self didChangeValueForKey:@"isFinished"];
}


- (BOOL)isFinished {
  return isFinished;
}


- (void)start {
  // iOS4_FIX: Ensure it executes on main thread.
  if (![NSThread isMainThread]) {
    [self performSelectorOnMainThread:@selector(start) withObject:nil waitUntilDone:NO];
    return;
  }

  urlRequest = [NSMutableURLRequest requestWithURL:self.urlEndpoint
                                        cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                    timeoutInterval:[self maximumTimeout]];
  NSString *xmlString = [self convertInputDictionaryToXMLString];

  NSData *xmlData = [xmlString dataUsingEncoding:NSUTF8StringEncoding];
  [urlRequest setHTTPBody:xmlData];
  [urlRequest setHTTPMethod:@"POST"];
  [urlRequest setValue:@"text/xml" forHTTPHeaderField:@"Content-Type"];

  [NSURLConnection connectionWithRequest:urlRequest delegate:self];
}


- (void)done {
  [self setExecuting:NO];
  [self setFinished:YES];
}


#pragma mark NSURLConnection delegate callbacks
#pragma mark -
- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
  [self handleError:error];
  [self done];
}


- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
  if ((response != nil) && [response respondsToSelector:@selector(statusCode)]) {
    responseCode = [(NSHTTPURLResponse *) response statusCode];
    //NSLog(@"POXCall responseCode:%d", responseCode);
  }

  [data setLength:0];
}


- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)someData {
  [data appendData:someData];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
  // If responseCode == 200, then call callback
  if (responseCode == 200) {
    NSString *dataAsString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	  NSLog(@"%@", dataAsString);
    //NSLog(@"responseCode:%d", responseCode);

    // Transform XML into NSDictionary
    NSDictionary *outputDictionary = GetEntireDocumentTree(data);

    NSArray      *allKeys                = [outputDictionary allKeys];
    NSString     *firstKey               = [allKeys objectAtIndex:0];
    NSDictionary *responseDictionary     = [outputDictionary objectForKey:firstKey];
    NSDictionary *faultDetailsDictionary = [responseDictionary objectForKey:@"FaultDetails"];

    if (faultDetailsDictionary == nil) {
      // Pass to delegate
      [delegate resultsForLastCallPOXEndpoint:urlEndpoint output:outputDictionary];
    } else {
      // Error as specified within 200 error code.
      Fault *fault = [[Fault alloc] init];
      fault.details  = dataAsString;
      fault.typeName = [faultDetailsDictionary objectForKey:@"DetailTypeName"];
      fault.message  = [faultDetailsDictionary objectForKey:@"Message"];

      NSDictionary *altDetailsDictionary = GetEntireDocumentTree([[faultDetailsDictionary objectForKey:@"SerializedDetails"] dataUsingEncoding:NSUTF8StringEncoding]);

      if (altDetailsDictionary) {
        if ([[altDetailsDictionary allKeys] indexOfObject:@"Description"] != NSNotFound) {
          fault.displayMessage = [altDetailsDictionary objectForKey:@"Description"];          
        }
        else if ([[altDetailsDictionary allKeys] indexOfObject:@"LogMessage"] != NSNotFound) {
          fault.displayMessage = [altDetailsDictionary objectForKey:@"LogMessage"];
        } else {
          for (NSString *key in [altDetailsDictionary allKeys]) {
            OrderedDictionary *cur = [altDetailsDictionary objectForKey:key];
            if ([cur isKindOfClass:[OrderedDictionary class]]) {
              if ([[cur allKeys] indexOfObject:@"Description"] != NSNotFound) {
                fault.displayMessage = [[altDetailsDictionary objectForKey:key] objectForKey:@"Description"];                
              } else {
                fault.displayMessage = [[altDetailsDictionary objectForKey:key] objectForKey:@"LogMessage"];
              }
            }
          }
        }
      }

      if (fault.displayMessage == nil) {
        fault.displayMessage = fault.message;
      }

      [delegate lastCallFailedForPOXEndpoint:urlEndpoint fault:fault];
    }
    
  } else {
    // Else call error callback
    NSString *output = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    //NSLog(@"responseCode:%d", responseCode);
    Fault *fault = [[Fault alloc] init];
    fault.typeName = [NSString stringWithFormat:@"Response Code %d", responseCode];
    fault.message  = output;
    [delegate lastCallFailedForPOXEndpoint:urlEndpoint fault:fault];
  }
  [self done];
}


@end
