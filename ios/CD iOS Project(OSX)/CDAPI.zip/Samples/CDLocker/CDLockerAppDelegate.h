//
//  CDLockerAppDelegate.h
//  CDLocker
//
//  Created by Kelly Lein on 2/6/12.
//  Copyright (c) 2012 Content Direct. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"
#import "MKStoreManager.h"

#define kCHCDClientStoreFrontInitialized    @"CHCDClientStoreFrontInitialized"

@class Reachability;

@interface CDLockerAppDelegate : UIResponder <UIApplicationDelegate, CDClientDelegate>
{
	MKStoreManager *storeManager;
	CDClient     *cdClient;
	NSURL        *imageLogoURL;
	NSURL        *backgroundImageURL;
	NSArray      *featuredProducts;
	NSDictionary *codeTypesToCodes;
	NSTimer      *pingTimer;
    
	UIWindow           * _window;
	UIImage *logoImage;
	UIImage *landscapeLogoImage;
	UIImage *backgroundImage;
	Reachability *internetReachable;
    Reachability *hostReachable;
}

@property (nonatomic, strong) MKStoreManager *storeManager;
@property (nonatomic, strong) CDClient *cdClient;
@property (nonatomic, strong) NSURL    *imageLogoURL;
@property (nonatomic, strong) NSURL    *backgroundImageURL;
@property (nonatomic, strong) NSArray  *featuredProducts;
@property (nonatomic, strong) NSTimer  *pingTimer;

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navigationController;
@property	(nonatomic)			BOOL internetConnected;
@property	(nonatomic)			BOOL connectMessageDisplayed;

+ (CDLockerAppDelegate *)sharedAppDelegate;
+ (CDClient *)sharedCDClient;

- (UIImage *)logoImage;
- (UIImage *)landscapeLogoImage;
- (UIImage *)backgroundImage;

- (NSArray *)passwordChallengeCodes;
- (NSArray *)ratingCodes;

- (void) checkNetworkStatus:(NSNotification *)notice;
- (void) showConnectionMessage;

@end
