//
// FlippableThumbnailView.m
// Chicago
//
// Created by Derr on 8/28/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHFlippableView.h"


@interface CHFlippableView (Private)
@property (readonly)UIView *blackOutView;
@end


@implementation CHFlippableView

- (id)initWithFrame:(CGRect)frame {
  if ((self = [super initWithFrame:frame])) {
    ch_frontVisible = YES;
  }

  return self;
}


- (void)setFrontView:(UIView *)front {
  // out with the old
  [ch_frontView removeFromSuperview];

  // in with the new
  ch_frontView  = front;
  [self addSubview:ch_frontView];

  if (ch_frontVisible) {
    self.frame         = ch_frontView.frame;
    ch_frontView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    [self bringSubviewToFront:ch_frontView];
  }	else {
    [self bringSubviewToFront:ch_backView];
  }
}


- (void)setBackView:(UIView *)back {
  [ch_backView removeFromSuperview];

  ch_backView  = back;
  ch_backFrame = ch_backView.frame;
  ch_backView.opaque = YES;
  if (ch_frontVisible) {
    ch_backView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    [self bringSubviewToFront:ch_frontView];
  }	else {
    [self bringSubviewToFront:ch_backView];
  }
}

- (void)dealloc {
  ch_frontView = nil;
  ch_backView = nil;

}


#pragma mark -
#pragma mark Flipping animation
- (void)showBackView {
	NSTimeInterval dt = [self.delegate flippableView:self timeIntervalToWaitBeforFlippingToView:self.backView];
  [UIView beginAnimations:nil context:nil];
	[UIView setAnimationDelay:dt];
  [UIView setAnimationDuration:kFlipImageDuration];
  [UIView setAnimationDelegate:self];
  [UIView setAnimationDidStopSelector:@selector(finishedFlippingToBackView)];
  [UIView setAnimationCurve:UIViewAnimationCurveEaseOut];
  [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self cache:YES];
  [ch_frontView removeFromSuperview];
  [self addSubview:ch_backView];
  [UIView commitAnimations];
}


- (void)finishedFlippingToBackView {
	UIView *mainWindow = [[[[CDLockerAppDelegate sharedAppDelegate] navigationController] topViewController] view];
  self.blackOutView.frame = mainWindow.bounds;
  self.backView.frame  = [mainWindow convertRect:self.frontView.frame fromView:self];
  
  self.backView.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin;
	
  [mainWindow addSubview:self.blackOutView];
  [self.blackOutView addSubview:self.backView];
  
  CGRect backFrame = ch_backFrame;
  // This is causing the bug https://pushio.lighthouseapp.com/projects/55151-vail/tickets/151-user-details-pop-over-will-not-close-when-device-is-laying-flat#ticket-151-3
//  if (UIInterfaceOrientationIsLandscape([[UIDevice currentDevice] orientation]))
  
  // This is a good workaround for determining landscape and fixes the above bug.
  BOOL areWeInLandscape = UIDeviceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation);
  if (areWeInLandscape)
    backFrame.origin = CGPointMake(mainWindow.center.y - backFrame.size.width / 2.0,
                                   mainWindow.center.x - backFrame.size.width / 2.0);
  else
    backFrame.origin = CGPointMake(mainWindow.center.x - backFrame.size.width/2.0, 
                                   mainWindow.center.y - backFrame.size.height/2.0);
	
  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:kFlipImageDuration];
  [UIView setAnimationDelegate:self];
  [UIView setAnimationDidStopSelector:@selector(finishedResizingToBack)];
  self.backView.frame  = backFrame;
  [UIView commitAnimations];
}


- (void)finishedResizingToBack {
  [self.delegate flippableView:self finishedFlippingToView:self.backView];

  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:kFlipImageDuration];
  self.blackOutView.backgroundColor = [UIColor colorWithWhite:0. alpha:0.33];
  [UIView commitAnimations];
}


- (void)showFrontView {
  NSTimeInterval dt = [self.delegate flippableView:self timeIntervalToWaitBeforFlippingToView:self.frontView];

  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:dt];
  [UIView setAnimationDelegate:self];
  [UIView setAnimationDidStopSelector:@selector(finishedFading)];
  self.blackOutView.backgroundColor = [UIColor clearColor];
  [UIView commitAnimations];
}


- (void)finishedFading {
	UIView *mainWindow = [[[[CDLockerAppDelegate sharedAppDelegate] navigationController] topViewController] view];
  CGRect convertedFrontFrame = [self convertRect:self.frontView.frame toView:mainWindow];
  
  // resize the image and licensing views
  [UIView beginAnimations:nil context:nil];
  [UIView setAnimationDuration:kFlipImageDuration];
  [UIView setAnimationDelegate:self];
  [UIView setAnimationDidStopSelector:@selector(finishedResizingToFront)];
  [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
  self.backView.frame  = convertedFrontFrame;
  [UIView commitAnimations];
}


- (void)finishedResizingToFront {
  [self addSubview:self.backView];
  self.backView.frame  = CGRectMake(0, 0, self.frontView.frame.size.width, self.frontView.frame.size.height);
  [self.blackOutView removeFromSuperview];
  
  [self performSelector:@selector(flipBackToFront) withObject:self afterDelay:0.001];
}

- (void)flipBackToFront {
  [UIView beginAnimations:nil context:nil];
  
  [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self cache:YES];
  [UIView setAnimationDuration:kFlipImageDuration];
  [UIView setAnimationDelegate:self];
  [UIView setAnimationDidStopSelector:@selector(finishedFlippingToFront)];
  [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
  [self.backView removeFromSuperview];
  [self addSubview:self.frontView];
  [UIView commitAnimations];
}


- (void)finishedFlippingToFront {
	[self.delegate flippableView:self finishedFlippingToView:self.frontView];
}


- (UIView *)blackOutView {
  if (ch_blackOutView != nil) {
    return ch_blackOutView;
  }
  ch_blackOutView = [[UIView alloc] initWithFrame:CGRectZero];
  ch_blackOutView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  return ch_blackOutView;
}


@synthesize frontView = ch_frontView, backView = ch_backView, delegate = ch_delegate;
@end
