//
//  SampleAppAppDelegate_iPhone.h
//  SampleApp
//
//  Copyright (c) 2010 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SampleAppAppDelegate.h"

@interface SampleAppAppDelegate_iPhone : SampleAppAppDelegate {
}


@end
