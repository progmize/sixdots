//
// CHDetailsViewController.m
// Chicago
//
// Created by Derr on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHDetailsViewController.h"
#import "Product.h"
#import "MBProgressHUD.h"
#import "CHProductListCell.h"
#import "CHProductDetailCell.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"

enum {
    kDetailSectionVideo,
    kDetailSectionCount
};

@implementation CHDetailsViewController

- (id)init {
    if ((self = [super initWithNibName:@"CHDetails" bundle:nil])) {
    }
    
    return self;
}

- (void)viewDidLoad {
	[super viewDidLoad];
	
	self.view.backgroundColor = kCHViewBackgroundColor;
	self.tableView.separatorColor = kCHTableViewBackgroundColor;
	self.tableView.backgroundColor = kCHTableViewBackgroundColor;
    self.title = self.product.name;
    
    // Load the branding logo
    CDLockerAppDelegate *appDelegate = (CDLockerAppDelegate *)[CDLockerAppDelegate sharedAppDelegate];
    UIImage *logoImage = [appDelegate logoImage];
    if (logoImage) {
        self.navigationItem.titleView = [[UIImageView alloc] initWithImage:logoImage];
    }
    
    [self showCSGBranding];
    
	self.tableView.sectionHeaderHeight = 25;
    
    if ([[CDLockerAppDelegate sharedCDClient] doesUserOwnProduct:self.product]) {
        [self setLibraryItem:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated {
    //NSLog(@"CHDetailsViewController -viewWillAppear:");
    [super viewDidAppear:animated];
	[self.navigationController setNavigationBarHidden:NO animated:animated];
    
    CHAPIOperation *apiOperation = [CHAPIOperation operationToRetrieveProductByProductID:self.product.productID];
    apiOperation.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:apiOperation];  
    
	[self setBackgroundImage:[[CDLockerAppDelegate sharedAppDelegate] backgroundImage]];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] cancelAllOperations]; 
    [super viewWillDisappear:animated];
}



#pragma mark -
#pragma mark UITableViewDataSource/Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return kDetailSectionCount;
}


- (CGFloat)tableView:(UITableView *)tableView heightForSection:(NSInteger)section {
	return tableView.sectionHeaderHeight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	if (section == kDetailSectionVideo) {
		return nil;
	}
//	
//    CGRect headerFrame = CGRectMake(0., 0., 320, self.tableView.sectionHeaderHeight);
//	UILabel *headerLabel = [[UILabel alloc] initWithFrame:headerFrame];
//	headerLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:14];
//	headerLabel.text = NSLocalizedString(@"PRODUCT_VIEWERS_ALSO_BOUGHT_TEXT", @"USERS ALSO BOUGHT");
//	headerLabel.textAlignment = UITextAlignmentCenter;
//	headerLabel.textColor = [UIColor whiteColor];
//	headerLabel.shadowColor = [UIColor blackColor];
//	headerLabel.shadowOffset = CGSizeMake(0., -1.);
//	headerLabel.backgroundColor = [UIColor clearColor];
//    
//	UIView *headerView = [[UIView alloc] initWithFrame:headerFrame];
//	
//	UIImageView *imageView = [[UIImageView alloc] initWithFrame:headerFrame];
//	imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
//	imageView.contentMode = UIViewContentModeScaleToFill;
//	imageView.image = [UIImage imageNamed:@"dark_title_background.png"];
//	
//	[headerView addSubview:imageView];
//	[headerView addSubview:headerLabel];
//	
//	return headerView;
    return nil;
}


- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section {
//    if (kDetailSectionVideo == section) {
//        return 1;
//    }
//    
//    return [self.relatedProducts count];
    return 1;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == kDetailSectionVideo) {
        return 300;
    }
    
    return 130;
}

- (void)setLibraryItem:(BOOL)isLibItem {
	ch_libraryItem = isLibItem;
	if (self.detailCell != nil) {
		self.detailCell.libraryItem = isLibItem;
	}
}

- (CHProductDetailCell *)detailCell {
	// don't allow the cell to be created if the product hasn't been initialized yet.
    if (ch_detailCell != nil || ch_product == nil) {
        return ch_detailCell;
    }
    
    ch_detailCell = [[CHProductDetailCell alloc] init];
	ch_detailCell.libraryItem = self.libraryItem;
    [ch_detailCell setProduct:self.product inCategory:self.category];
    ch_detailCell.delegate = self;
    
    return ch_detailCell;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == kDetailSectionVideo) {
        return [self detailCell];
    }
    
    static NSString   * cellID = @"CHDetailsViewRelated";
    CHProductListCell * cell   = (CHProductListCell *)[tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        cell = [[CHProductListCell alloc] initWithReuseIdentifier:cellID];
    }
    
    Product * related = [self.relatedProducts objectAtIndex:indexPath.row];
    [cell setProduct:related];
    cell.delegate = self;
    
    return cell;
}


- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == kDetailSectionVideo) {
		return nil;
	}
	
	return indexPath;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.section == kDetailSectionVideo || indexPath.row < 0 || indexPath.row >= [self.relatedProducts count]) {
		return;
	}
	
	Product *theProduct = [self.relatedProducts objectAtIndex:indexPath.row];
	
	CHDetailsViewController *nextDetailVC = [[CHDetailsViewController alloc] init];
	nextDetailVC.product = theProduct;
    
	[self.navigationController pushViewController:nextDetailVC animated:YES];
}

#pragma mark CDClientDelegate
#pragma mark -

- (void)retrieveProductSucceededWithLicense:(NSString *)license externalTypeValue:(NSString *)externalTypeValue recommendedProducts:(NSArray *)productArray runtime:(NSString *)runtime product:(Product *)product 
{
	self.product = product;
	
    if (license != nil) {
        self.product.licensingText = license;
    }
    
    // Set the runtime
    if (runtime != nil) {
        self.product.runtime = runtime;
    }
    
	[self.detailCell setProduct:self.product inCategory:self.category];
    if ([productArray count] == 0) {
        // Fill in the recommended products with the featured products.
        self.relatedProducts = [CDLockerAppDelegate sharedAppDelegate].featuredProducts;
        [ch_tableView reloadData];    
    } else {
        self.relatedProducts = productArray;
        [ch_tableView reloadData];    
    }
}

- (void)retrieveProductFailedWithFault:(Fault *)aFault {
    // Fill in the recommended products with the featured products.
    self.relatedProducts = [CDLockerAppDelegate sharedAppDelegate].featuredProducts;
    [ch_tableView reloadData];
    
    /*
     [aFault showWithTitle:@"Colud not retrieve recommended products."];
     */
}


@synthesize progressHUD = ch_progressHUD, product = ch_product, category = ch_category, relatedProducts = ch_relatedProducts, tableView = ch_tableView, detailCell = ch_detailCell;
@end
