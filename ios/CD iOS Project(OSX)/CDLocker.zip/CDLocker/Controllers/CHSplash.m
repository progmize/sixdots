//
// CHSplash.m
// Chicago
//
// Created by Derr on 9/25/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHSplash.h"


@implementation CHSplash

- (id)init {
  if ((self = [super initWithNibName:nil bundle:nil])) {
		self.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
	}
	
  return self;
}


// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	CGRect frame;
	if (UIInterfaceOrientationIsLandscape([UIDevice currentDevice].orientation))
		frame = CGRectMake(0, 0, 480, 320);
	else {
		frame = CGRectMake(0, 0, 320, 480);
	}

  self.view                  = [[UIView alloc] initWithFrame:frame];
  self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  self.view.backgroundColor  = [UIColor blackColor];
  //[self.view release];

  UIImageView * splash = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"Default~iphone.png"]];
  splash.backgroundColor  = [UIColor blackColor];
  splash.contentMode      = UIViewContentModeCenter;
  splash.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
  [self.view addSubview:splash];

	// adjust the splash center for the status bar
	CGPoint center = splash.center;
	center.y -= 10.;
	splash.center = center;
	
}

- (void)viewDidAppear:(BOOL)animated {
    
	[[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
	
	CGPoint location = self.view.center;
	
	UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
	[activity startAnimating];
	activity.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
	
	location.y += 32 + activity.frame.size.height/2.;
	activity.center = location;
	[self.view addSubview:activity];
	
	UILabel *loading = [[UILabel alloc] initWithFrame:CGRectMake(0., 0., self.view.frame.size.width, 44.)];
	loading.font = [UIFont fontWithName:@"Helvetica-Bold" size:17.];
	loading.textAlignment = UITextAlignmentCenter;
	loading.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
	loading.backgroundColor = [UIColor clearColor];
	loading.textColor = [UIColor whiteColor];
	loading.text = NSLocalizedString(@"MEDIA_VIDEO_LOADING", @"Loading...");
	
	location.y += 30 + activity.frame.size.height/2;
	loading.center = location;
	[self.view addSubview:loading];
	
	
	loading.alpha = 0.;
	activity.alpha = 0.;
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.25];
	loading.alpha = 1.;
	activity.alpha = 1.;
	[UIView commitAnimations];
	
}

- (void)viewWillDisappear:(BOOL)animated {
	[[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  // Return YES for supported orientations
  return UIInterfaceOrientationIsLandscape(interfaceOrientation) || interfaceOrientation == UIInterfaceOrientationPortrait;
}


@end
