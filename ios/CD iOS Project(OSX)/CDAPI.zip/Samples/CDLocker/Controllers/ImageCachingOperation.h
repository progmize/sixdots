//
//  ImageCachingOperation.h
//  Chicago
//
//  Created by louie on 8/12/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ImageCachingOperation : NSOperation {
  NSURL *imageURL;
  BOOL ch_shouldScale;
}

@property (nonatomic, copy) NSURL *imageURL;

- (id)initScaled:(BOOL)shouldScale;

@end
