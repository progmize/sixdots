//
//  CHDefaultPaymentMethod.m
//  Chicago
//
//  Created by Derr on 9/23/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHDefaultPaymentMethod.h"
#import "SynthesizeSingleton.h"

@interface CHDefaultPaymentMethod (Private)
- (void)loadId;
- (void)saveId;
@end

#define kDefaultPaymentMethodKey @"CH_DEFAULT_PAYMENT_METHOD_ID"

@implementation CHDefaultPaymentMethod

SYNTHESIZE_SINGLETON_FOR_CLASS(CHDefaultPaymentMethod)

- (NSString *)defaultInstrumentId {
	if (ch_defaultInstrumentId == nil) {
		[self loadId];
	}
	
	return ch_defaultInstrumentId;
}

- (void)setDefaultInstrumentId:(NSString *)newDefault {
	if (ch_defaultInstrumentId == newDefault) {
		return;
	}
	
	ch_defaultInstrumentId = newDefault;
	
	[self saveId];
}


#pragma mark -
#pragma mark Load/Store default id

- (void)loadId {
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	ch_defaultInstrumentId = [defaults objectForKey:kDefaultPaymentMethodKey];
}

- (void)saveId {
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	[defaults setObject:ch_defaultInstrumentId forKey:kDefaultPaymentMethodKey];
}

@end
