//
//  CDAppDelegate.h
//  SampleApp
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CDViewController;

@interface CDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CDViewController *viewController;

//@property (strong, nonatomic) ContentDirectAPI *cdAPI;

@end
