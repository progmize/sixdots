package com.authentec.drm.android.reference.activities;

import java.io.File;
import java.net.URI;
import java.util.concurrent.*;

import android.app.Activity;
import android.content.*;
import android.graphics.PixelFormat;
import android.media.*;
import android.os.*;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.authentec.drm.android.reference.*;
import com.authentec.drmagent.v2.*;

public class PlayMediaNativePlayerActivity extends Activity implements
        MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnCompletionListener,
        MediaPlayer.OnPreparedListener, MediaPlayer.OnVideoSizeChangedListener,
        MediaPlayer.OnErrorListener, MediaPlayer.OnInfoListener, SurfaceHolder.Callback, MediaPlayer.OnSeekCompleteListener
{

    /**
     * Holds the start time of this activity.  Used for printing debugging information (duration of operations since
     * start of the activity.
     */
    private long mStartTime;

    private static final String TAG = "PlayMediaNativePlayerActivity";
    private int mVideoWidth;
    private int mVideoHeight;
    private MediaPlayer mMediaPlayer;
    private SurfaceView mPreview;
    private SurfaceHolder holder;

    private boolean mIsVideoSizeKnown = false;
    private boolean mIsVideoReadyToBePlayed = false;

    private CyclicBarrier cyclicBarrier = new CyclicBarrier(2);
    private DRMContentInfo mDRMContentInfo;
    private URI mUri;
    private URI mOriginalURI;

    private boolean mReadyForPlay = false;

    private LinearLayout mControlPanelLinearLayout;
    private ImageButton mButtonPlayPause;
    private SeekBar mSeekBar;
    private int mDesiredPosition = 0;
    private int mScreenPixelFormat;
    private ImageView mNoAudioImageView;
    private TextView mStatusText;
    private static final Handler mHandler = new Handler();

    private Intent mLastIntent;

    /**
     * Holds the current play time - how much of the stream has been played
     */
    public int mPlayingTime;

    /**
     * Holds the duration of the current stream - e.g. how long the clip is
     */
    public int mContentDuration;

    /**
     * Maintains the wake locks for the screen -this prevents the screen from turning off during play
     */
    private PowerManager.WakeLock mWakeLock = null;
    private PowerManager.WakeLock mDimLock = null;
    private PowerManager mPowerManager;
    public Runnable mSeekBarUpdater;
    private boolean mSeeking;

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle icicle)
    {
        super.onCreate(icicle);
        setContentView(getContentView());
        mPreview = (SurfaceView) findViewById(getSurfaceView());
        holder = mPreview.getHolder();
        holder.addCallback(this);
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);

        // Extract the information about the display in order to setup the pixel format & color depth.
        final Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        final int devicePixelFormat = display.getPixelFormat();

        Log.d(TAG, String.format("PixelFormat: %d", devicePixelFormat));

        switch (devicePixelFormat)
        {
            case PixelFormat.RGBA_8888:
            case PixelFormat.RGBX_8888:
            case PixelFormat.RGB_888:
            case 5:
                mScreenPixelFormat = PixelFormat.RGBA_8888;
                Log.d(TAG, "888 : DevicePixelFormat:" + devicePixelFormat + "  ScreenPixelFormat:" + mScreenPixelFormat);
                break;
            default:
                mScreenPixelFormat = PixelFormat.RGB_565;
                Log.d(TAG, "565 : DevicePixelFormat:" + devicePixelFormat + "  ScreenPixelFormat:" + mScreenPixelFormat);
        }

        if (Build.MODEL.equals("Milestone"))
        {
            Log.d(TAG, "Detected Motorola Droid/Milestone, forcing pixel fromat RGB_565");
            mScreenPixelFormat = PixelFormat.RGB_565;
        }


    }

    private long getElapsedTime()
    {
        return (System.currentTimeMillis() - mStartTime);
    }

    View.OnClickListener mPlayPauseOnClickListener = new View.OnClickListener()
    {
        public void onClick(View v)
        {

            Log.i(TAG, "Play listener entered");
            Log.d(TAG, "Opening URL: " + mUri);

            if (!mMediaPlayer.isPlaying())
            {
                if (!ContentHandler.isClearText(mDRMContentInfo))
                {
                    mDRMContentInfo.mDRMContent.startConsumption();
                }
                mMediaPlayer.start();
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePause()));
            }
            else
            {
                if (!ContentHandler.isClearText(mDRMContentInfo))
                {
                    mDRMContentInfo.mDRMContent.stopConsumption();
                }
                mMediaPlayer.pause();
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));
            }
        }
    };


    @Override
    protected void onResume()
    {
        super.onResume();

        mLastIntent = getIntent();

        Log.d(TAG, "Registering HDMI broadcast receiver");
        DRMAgentDelegate.addHDMIBroadcastReceiver(getBaseContext());

        mStartTime = System.currentTimeMillis();
        final Intent lastIntent = getIntent();

        Bundle extras = lastIntent.getExtras();
        if (getIntent().getStringExtra("CUSTOM_URL") != null)
        {
            final URI uri = URI.create(extras.getString(Constants.CUSTOM_URL));
            mDRMContentInfo = ContentHandler.createDRMContentInfoForUnknownURI(this, uri);
        }
        else
        {
            String selectedContentIdentifier = extras.getString(Constants.DESCRIPTOR_LOCATION);
            mDRMContentInfo = ContentHandler.parseAsXML(this, new File(selectedContentIdentifier), true, true);
        }

        // set the HDMI client control mode
        mDRMContentInfo.mDRMContent.setHDMIControl(HDMIControl.DEFAULT);

        // This checks whether or not the Agent has rights for the content in question.  This check will
        // verify both if the content is clear-text or protected & rights exists
        if (ContentHandler.hasRights(mDRMContentInfo))
        {
            if (ContentHandler.isClearText(mDRMContentInfo))
            {
                Log.d(TAG, "Content is clear-text, initiating initialization: " + getElapsedTime());
            }
            else
            {
                Log.d(TAG, "Rights available, initiating initialization: " + getElapsedTime());

                // Register with the DRM Agent to receive any errors that occur during playback
                // This allows the application to handle the case where the license expires
                // during playback or the clock has been tampered with
                DRMAgentDelegate.addDRMCallbackListener(this, new AbstractDRMCallbackListener()
                {
                    public void errorReceived(final DRMError drmError, final URI uri)
                    {
                        Log.w(TAG, "Received error from the DRM agent: " + drmError);
                        // Examine the actual error

                        int currentPos = 0;
                        if (mMediaPlayer != null && mMediaPlayer.isPlaying())
                        {
                            currentPos = mMediaPlayer.getCurrentPosition();
                            mMediaPlayer.stop();
                        }

                        if (mDRMContentInfo != null && mDRMContentInfo.mDRMContent != null)
                        {
                            mDRMContentInfo.mDRMContent.release();
                        }

                        Log.w(TAG, "Media player finished, will head back to ");
                        Intent intent = new Intent(getBaseContext(), getLicenseAcquisitionActivityClass());
                        intent.putExtra("DESCRIPTOR_LOCATION", mDRMContentInfo.mContentDescriptorLocation);
                        intent.putExtra("DRM_ERROR", drmError.name());
                        intent.putExtra("startFrom", Integer.valueOf(currentPos));
                        startActivity(intent);
                        finish();
                    }
                });
            }

            // If the content is not clear text (i.e. it has been protected) it must first be opened in order
            // to establish the correct internal bindings between the DRM agent and the player
            if (!ContentHandler.isClearText(mDRMContentInfo))
            {
                Log.d(TAG, "Opening DRM protected content: " + getElapsedTime());

                Thread t = new Thread()
                {
                    public void run()
                    {
                        try
                        {
                            Log.d(TAG, "Opening content");

                            // This method will return the URI that should be used by the player
                            mUri = mDRMContentInfo.mDRMContent.open();
                            mOriginalURI = mDRMContentInfo.mContentLocation;
                            mReadyForPlay = true;
                            Log.d(TAG, "Content opened, pre-barrier");
                            cyclicBarrier.await();
                            Log.d(TAG, "Content opened");
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                };
                t.start();

                Log.d(TAG, "DRM Content opened: " + getElapsedTime());
            }
            else
            {
                new Thread()
                {
                    @Override
                    public void run()
                    {
                        Log.d(TAG, "Opening clear text content: " + getElapsedTime());
                        mUri = mDRMContentInfo.mDRMContent.getOriginalContentURI();
                        mOriginalURI = mDRMContentInfo.mContentLocation;
                        mReadyForPlay = true;
                        try
                        {
                            Log.d(TAG, "Content opened, pre-barrier");
                            cyclicBarrier.await();
                            Log.d(TAG, "Clear text content opened: " + getElapsedTime());
                        }
                        catch (Exception e)
                        {
                            e.printStackTrace();
                        }
                    }
                }.start();

            }

            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);


            // Setup video rendering view
            SurfaceView surfaceView = (SurfaceView) findViewById(getSurfaceView());
            surfaceView.setClickable(true);

            mControlPanelLinearLayout = (LinearLayout) findViewById(getControlPanelLinearLayout());
            mControlPanelLinearLayout.setVisibility(View.VISIBLE);

            mControlPanelLinearLayout.setOnTouchListener(new View.OnTouchListener()
            {
                public boolean onTouch(final View view, final MotionEvent motionEvent)
                {
                    return true;
                }
            });

            // Setup a click listener which will allow the user to show/hide the scrubber and play controls
            surfaceView.setOnClickListener(new View.OnClickListener()
            {
                public void onClick(final View view)
                {
                    mControlPanelLinearLayout.setVisibility(mControlPanelLinearLayout.isShown() ? View.INVISIBLE : View.VISIBLE);
                }
            });

            // Setup the PlayPause button - this adds the listener required to handle clicks
            // as well as the graphics for the button (play selector by default)
            // The onClickListener will handle pause/play switching and deal with graphic (button)
            // updates
            mButtonPlayPause = (ImageButton) findViewById(getPlayPauseImageButton());
            mButtonPlayPause.setOnClickListener(mPlayPauseOnClickListener);
            mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));

            // Setup the seek bar - this nullifies the current play position to 0 & adds a listener
            // to control the actual seeking operations
            mSeekBar = (SeekBar) findViewById(getSeekBar());
            mSeekBar.setProgress(0);
            mSeekBar.setSecondaryProgress(0);
            mSeekBar.setMax(0);
            mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
            {
                public void onProgressChanged(final SeekBar seekBar, final int currentPosition, final boolean seekBarTracking)
                {
                    Log.v(TAG, "Progress changed: " + currentPosition + " (" + (seekBarTracking ? "tracking)" : "not tracking)"));
                    if (seekBarTracking)
                    {
                        mDesiredPosition = currentPosition;
                    }
                }

                public void onStartTrackingTouch(final SeekBar seekBar)
                {
                    Log.v(TAG, "SeekBar tracking started");
                }

                public void onStopTrackingTouch(final SeekBar seekBar)
                {
                    Log.v(TAG, "SeekBar tracking stopped");
                    if (mMediaPlayer.isPlaying())
                    {
                        Log.v(TAG, "Seeking to: " + mDesiredPosition);
                        // Means we were tracking & now we are not - seek to the time specified
                        mSeeking = true;
                        mMediaPlayer.seekTo(mDesiredPosition * 1000);
                    }
                }
            });

            // Retrieve the view that displays the status text - this displays things like status
            // (opening, buffering) and the elapsed time within the play
            mStatusText = (TextView) findViewById(getStatusTextView());

            mNoAudioImageView = (ImageView) findViewById(getAudioOnlyImageView());
            // FIXME: This image should really be stretched to the size of the screen
            mNoAudioImageView.setImageDrawable(getResources().getDrawable(getAudioOnlyDrawable()));
            mNoAudioImageView.setVisibility(View.INVISIBLE);


            Log.d(TAG, "Initialization complete");

        }
        else
        {
            Log.d(TAG, "No rights available, going back to licensing activity");
            Intent intent = new Intent(getBaseContext(), LicenseAcquisitionActivity.class);
            intent.putExtra("DESCRIPTOR_LOCATION", mDRMContentInfo.mContentDescriptorLocation);
            startActivity(intent);
            finish();
        }

    }

    private void playVideo()
    {
        doCleanUp();
        try
        {
            try
            {
                cyclicBarrier.await(10, TimeUnit.SECONDS);
                cyclicBarrier.reset();
            }
            catch (TimeoutException e)
            {
                Log.d(TAG, "Timeout while opening content");
                finish();
                return;
            }
            catch (Exception e)
            {
                Log.e(TAG, "Error while opening content: " + e.getMessage());

            }

            if (!mReadyForPlay)
            {
                Log.d(TAG, "Not ready for play, will bail");
                return;
            }

            mWakeLock = mPowerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "AuthenTec");
            mDimLock = mPowerManager.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "AuthenTec");

            Log.d(TAG, "Locks acquired, now locking: " + getElapsedTime());

            mWakeLock.acquire();
            mDimLock.acquire();

            final SharedPreferences authentec = PlayMediaNativePlayerActivity.this.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
            String uriString = mUri.toString();

            if (authentec.getBoolean(Constants.PREFERENCES_USE_REMOTE_URL_FOR_NATIVE_PLAYER, false))
            {
                uriString = mDRMContentInfo.mContentLocation.toString();
            }

            Log.d(TAG, "Initiating play: " + uriString);
            // Create a new media player and set the listeners

            mMediaPlayer = new MediaPlayer();

            mMediaPlayer.setOnBufferingUpdateListener(this);
            mMediaPlayer.setOnCompletionListener(this);
            mMediaPlayer.setOnPreparedListener(this);
            mMediaPlayer.setOnVideoSizeChangedListener(this);
            mMediaPlayer.setOnErrorListener(this);
            mMediaPlayer.setOnBufferingUpdateListener(this);

            mMediaPlayer.setDataSource(uriString);

            mMediaPlayer.setDisplay(holder);
            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

            boolean streaming = (mUri.getScheme() != null && (mUri.getScheme().equals("http") || mUri.getScheme().equals("https")));
            updateUserMessage((streaming ? "Connecting..." : "Opening..."));

            mMediaPlayer.prepareAsync();


        }
        catch (Exception e)
        {
            Log.e(TAG, "error: " + e.getMessage(), e);
        }
    }

    public void onBufferingUpdate(MediaPlayer arg0, int percent)
    {
        Log.d(TAG, "Buffering " + percent + " %");
        updateUserMessage("Buffering " + percent + " %");
    }

    public void onCompletion(MediaPlayer arg0)
    {
        Log.d(TAG, "onCompletion called");
    }

    public void onVideoSizeChanged(MediaPlayer mp, int width, int height)
    {
        Log.v(TAG, "onVideoSizeChanged called");
        if (width == 0 || height == 0)
        {
            Log.e(TAG, "invalid video width(" + width + ") or height(" + height + ")");
            return;
        }
        mIsVideoSizeKnown = true;
        mVideoWidth = width;
        mVideoHeight = height;
        if (mIsVideoReadyToBePlayed && mIsVideoSizeKnown)
        {
            startVideoPlayback();
        }
    }

    public void onPrepared(MediaPlayer mediaplayer)
    {
        Log.d(TAG, "onPrepared called");
        mIsVideoReadyToBePlayed = true;
        startVideoPlayback();
    }

    public void surfaceChanged(SurfaceHolder surfaceholder, int i, int j, int k)
    {
        Log.d(TAG, "surfaceChanged called");
    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        Log.d(TAG, "surfaceDestroyed called");
    }


    public void surfaceCreated(SurfaceHolder holder)
    {
        Log.d(TAG, "surfaceCreated called");
        playVideo();
    }

    @Override
    protected void onStart()
    {
        super.onStart();
        Log.d(TAG, "Starting");

    }

    @Override
    protected void onStop()
    {
        Log.d(TAG, "Stopping");
        super.onStop();
    }

    @Override
    protected void onPause()
    {
        if (mMediaPlayer != null && mMediaPlayer.isPlaying())
        {
            int timestamp = mMediaPlayer.getCurrentPosition();
            Tools.saveStartFrom(this,timestamp,mOriginalURI);
        }

        Log.d(TAG, "Unregistering HDMI Broadcast receiver.");
        DRMAgentDelegate.removeHDMIBroadcastReceiver(getBaseContext());

        if (mWakeLock != null && mWakeLock.isHeld())
        {
            mWakeLock.release();
            mWakeLock = null;
        }
        if (mDimLock != null && mDimLock.isHeld())
        {
            mDimLock.release();
            mDimLock = null;
        }

        releaseResources();

        doCleanUp();

        if (mDRMContentInfo != null)
        {
            mDRMContentInfo.mDRMContent.release();
        }


        super.onPause();
    }

    private void releaseResources()
    {
        Log.d(TAG, "Releasing resources");
        if (mMediaPlayer != null)
        {
            if (mMediaPlayer.isPlaying())
            {
                Log.d(TAG, "Stopping media player");
                mMediaPlayer.stop();
            }
            mMediaPlayer.release();
            mMediaPlayer = null;
        }

    }

    private void doCleanUp()
    {
        mVideoWidth = 0;
        mVideoHeight = 0;
        mIsVideoReadyToBePlayed = false;
        mIsVideoSizeKnown = false;
    }

    private void startVideoPlayback()
    {
        Log.v(TAG, "startVideoPlayback");
        holder.setFixedSize(mVideoWidth, mVideoHeight);
        mSeeking = false;
        mMediaPlayer.start();

        int startFrom = Tools.extractStartFrom(this,mLastIntent,mOriginalURI);
        if (startFrom > 0)
        {
            // Log.d(TAG, "Start from: " + startFrom);
            // mMediaPlayer.seekTo(startFrom);
        }

        mContentDuration = mMediaPlayer.getDuration();

        mSeekBar.setMax(mContentDuration / 1000);

        mSeekBarUpdater = new Runnable()
        {
            public void run()
            {
                if (mIsVideoReadyToBePlayed && !mSeeking)
                {
                    mPlayingTime = mMediaPlayer.getCurrentPosition();
                    mSeekBar.setProgress(mPlayingTime / 1000);
                    mSeekBar.setSecondaryProgress(mPlayingTime / 1000);
                    updateUserMessage(Tools.convertToNiceTime(mPlayingTime));
                    mHandler.postDelayed(mSeekBarUpdater, 1000);
                }
            }
        };
        mHandler.postDelayed(mSeekBarUpdater, 1000);

        mHandler.postAtFrontOfQueue(new Runnable()
        {
            public void run()
            {
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePause()));
            }
        });

    }


    public boolean onError(final MediaPlayer mediaPlayer, final int what, final int extra)
    {
        Log.v(TAG, "onError: what: " + what + " extra: " + extra);
        return false;
    }

    public boolean onInfo(final MediaPlayer mediaPlayer, final int i, final int i1)
    {
        Log.d(TAG, "onInfo what: " + i + " extra: " + i1);
        return true;
    }

    public void updateUserMessage(final String strMsg)
    {
        mHandler.post(new Runnable()
        {
            public void run()
            {
                try
                {
                    mStatusText.setText(strMsg);
                }
                catch (Throwable e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    public void onSeekComplete(final MediaPlayer mediaPlayer)
    {
        Log.v(TAG, "onSeekComplete");
        mSeeking = false;
    }

    protected int getContentView()
    {
        return R.layout.video;
    }

    protected int getSeekBar()
    {
        return R.id.SeekBar;
    }

    public String getInitFailedMessage()
    {
        return getString(R.string.cp_init_failed);
    }

    protected Class getLicenseAcquisitionActivityClass()
    {
        return LicenseAcquisitionActivity.class;
    }

    protected int getStatusTextView()
    {
        return R.id.StatusTextView;
    }

    protected int getAudioOnlyDrawable()
    {
        return R.drawable.audio_only_3color;
    }

    protected int getAudioOnlyImageView()
    {
        return R.id.noAudioImageView;
    }

    protected int getPlayPauseImageButton()
    {
        return R.id.PlayPauseButton;
    }

    protected int getButtonDrawablePlay()
    {
        return R.drawable.play_selector;
    }

    protected int getControlPanelLinearLayout()
    {
        return R.id.ControlPanel;
    }

    protected int getSurfaceView()
    {
        return R.id.surface;
    }

    protected int getButtonDrawablePause()
    {
        return R.drawable.pause_selector;
    }


}
