//
//  Product.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Product : NSObject 
{
    NSString *productID;
	NSString *name;
	NSString *shortDescription;
	int peerRating;
	int peerRatingCount;
	NSString *thumbnailURL;
	NSString *pricingPlanID;
	NSString *purchasedPricingPlanID;
	NSString *orderingType;
	NSString *price;
	BOOL isOnDemand;
	NSDate *expirationDate;
	NSString *licensingText;
    BOOL isSubscription;
	NSString *pricingPlanReferenceID;
	int guidanceRatingCode;
	
	NSString *imageURL;
	BOOL hasPreview;
	NSString *previewID;
	NSString *runtime;
	NSDate *availabilityStartDate;
	NSDate *availabilityEndDate;	
}

@property (copy) NSString *productID;
@property (copy) NSString *name;
@property (copy) NSString *shortDescription;
@property int peerRating;
@property int peerRatingCount;
@property (copy) NSString *thumbnailURL;
@property (copy) NSString *pricingPlanID;
@property (copy) NSString *purchasedPricingPlanID;
@property (copy) NSString *orderingType;
@property (copy) NSString *pricingPlanReferenceID;
@property int guidanceRatingCode;
@property (copy) NSString *price;
@property (copy) NSDate *expirationDate;
@property (copy) NSDate *availabilityStartDate;
@property (copy) NSDate *availabilityEndDate;

@property BOOL isOnDemand;
@property (copy) NSString *licensingText;
@property BOOL isSubscription;

@property (copy) NSString *imageURL;
@property BOOL hasPreview;
@property (copy) NSString *previewID;
@property (copy) NSString *runtime;

- (NSString *)getGuidanceRatingLabel;
- (NSString *)formattedPrice;

- (BOOL)isFree;
- (BOOL)isInstantlyViewableNotOrderable;
- (BOOL)isPurchased;
- (BOOL)isExpired;

+ (NSString *)formatAsCurrency:(NSString *)decimalString;

@end
