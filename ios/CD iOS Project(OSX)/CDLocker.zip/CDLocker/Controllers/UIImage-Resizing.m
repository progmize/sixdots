//
//  UIImage-Resizing.m
//  Chicago
//
//  Created by louie on 8/13/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "UIImage-Resizing.h"


@implementation UIImage (Resizing)
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize {
  UIGraphicsBeginImageContext(newSize);
  [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
  UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();    
  UIGraphicsEndImageContext();
  return newImage;
}
@end
