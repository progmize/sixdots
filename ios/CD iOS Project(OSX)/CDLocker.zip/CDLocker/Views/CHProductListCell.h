//
// CHProductListCell.h
// Chicago
//
// Created by Derr on 8/10/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CHFeaturedProductView;
@class Product;
@protocol PurchasProductDelegate;

@interface CHProductListCell : UITableViewCell {
  CHFeaturedProductView * ch_productView;
}

@property (nonatomic, strong) CHFeaturedProductView * productView;
@property (nonatomic, unsafe_unretained) id<PurchasProductDelegate> delegate;
@property (nonatomic, assign) BOOL libraryItem;

- (id)initWithReuseIdentifier:(NSString *)reuseId;
- (void)setProduct:(Product *)theProduct;

@end
