//
// CHBrowseViewController.m
// Chicago
//
// Created by Brian Cooke on 8/2/10.
// Copyright 2010 Push.IO Inc, LLC. All rights reserved.
//

#import "CHBrowseViewController.h"
#import "MBProgressHUD.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"
#import "ProductCategory.h"
#import "CHBrowseCategoryViewController.h"
#import "CHFeaturedCell.h"
#import "CHConfirmInAppPurchaseViewController.h"
#import "CHConfirmPurchaseViewController.h"
#import "CHDetailsViewController.h"
#import "CHPlainTableViewCell.h"
#import "AppDelegate_iPhone.h"

@interface CHBrowseViewController (Private)
- (void)storeFrontInitialized:(NSNotification *)aNotif;
- (CHFeaturedCell *)featuredCell;
@end


enum {
    kFeaturedSection,
    kBrowseSection,
    kSectionCount
};


@implementation CHBrowseViewController

@synthesize productCategories = ch_productCategories;
@synthesize tableView = ch_tableView;
@synthesize featuredProducts = ch_featuredProducts;
@synthesize splash = ch_splash;

// ------------------------------------------------------------------------------
// cleanup
// ------------------------------------------------------------------------------
- (void)cleanup
{
	ch_splash = nil;
	
    ch_tableView = nil;
    
    ch_featuredCell = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

// ------------------------------------------------------------------------------
// viewDidUnload
// ------------------------------------------------------------------------------
- (void)viewDidUnload
{
    [super viewDidUnload];
    [self cleanup];
}

// ------------------------------------------------------------------------------
// dealloc
// ------------------------------------------------------------------------------
- (void)dealloc
{
    [self cleanup];
    
    
    
}

// ------------------------------------------------------------------------------
// didReceiveMemoryWarning
// ------------------------------------------------------------------------------
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

// ------------------------------------------------------------------------------
// init
// ------------------------------------------------------------------------------
- (id)init
{
    if ((self = [super initWithNibName:@"CHBrowseView" bundle:nil])) {}
    
    return self;
}





// ------------------------------------------------------------------------------
// shouldAutorotateToInterfaceOrientation:
// ------------------------------------------------------------------------------
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    
    // Recalculate the pages
    [[self featuredCell] reloadData];
}




// ------------------------------------------------------------------------------
// viewDidLoad
// ------------------------------------------------------------------------------
- (void)viewDidLoad
{
    [super viewDidLoad];
	self.view.backgroundColor = kCHViewBackgroundColor;
	self.tableView.backgroundColor = kCHTableViewBackgroundColor;
	self.tableView.separatorColor = kCHTableViewBackgroundColor;
    self.title = NSLocalizedString(@"MAIN_MENU_BROWSE_BUTTON_TEXT", @"Browse");
}

- (void)viewDidAppear:(BOOL)animated
{   
    [super viewDidAppear:YES];
    [self.tableView reloadData];
}


// ------------------------------------------------------------------------------
// viewWillAppear:
// ------------------------------------------------------------------------------
- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	[self.navigationController setNavigationBarHidden:NO animated:animated];
    [self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:animated];
	
	[self showFeaturedItems];
	
	// Are we logged in or authenticated? Let's get the full conent if we have any
	if([[AppDelegate sharedCDClient] loggedIn] || [[AppDelegate sharedCDClient] authenticated]) // but only if we have a subscriber & session id
	{	
		CHAPIOperation *op = [CHAPIOperation operationToRetrieveFeaturedProducts];
		op.delegate = self;
		[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
	}
}


// ------------------------------------------------------------------------------
// viewWillDisappear:
// ------------------------------------------------------------------------------
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}


- (void) showFeaturedItems
{
	if ([AppDelegate sharedCDClient].sessionID == nil) {
		self.splash = [[CHSplash alloc] init];
		//[self.splash release];
		[self presentModalViewController:self.splash animated:NO];
		
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(storeFrontInitialized:) name:kCHCDClientStoreFrontInitialized object:nil];
    }
	
	[self setBackgroundImage:[[AppDelegate_iPhone sharedAppDelegate] backgroundImage]];
	
    // Make sure featured items are always shown.
    // Fix for Ticket #73: Featured items disappear when return to tab after watching video clip.
    [ch_featuredCell reloadData];
}



#pragma mark -
#pragma mark Notifications
// ------------------------------------------------------------------------------
// storeFrontInitialized:
// ------------------------------------------------------------------------------
- (void)storeFrontInitialized:(NSNotification *)aNotif
{
    [AppDelegate sharedAppDelegate].featuredProducts = [aNotif object];
    self.featuredProducts = [AppDelegate sharedAppDelegate].featuredProducts;
    
    if (ch_featuredCell != nil) {
        [ch_featuredCell reloadData];
    }
	
    // get categories
    CHAPIOperation * op = [CHAPIOperation operationToRetrieveCategoriesByParentCategoryID:nil];
    op.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}

- (void) userLoggedOut
{
	// Refresh the featured content
}





#pragma mark -
#pragma mark Tableview delegate and datasource
// ------------------------------------------------------------------------------
// numberOfSectionsInTableView:
// ------------------------------------------------------------------------------
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return kSectionCount;
}





// ------------------------------------------------------------------------------
// -tableView:heightForRowAtIndexPath:
// ------------------------------------------------------------------------------
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == kFeaturedSection) {
        return 140.;
    }
    
    return 44.;
}





- (CHFeaturedCell *)featuredCell {
    if (ch_featuredCell != nil) {
        return ch_featuredCell;
    }
    
    ch_featuredCell            = [[CHFeaturedCell alloc] init];
    ch_featuredCell.dataSource = self;
    ch_featuredCell.delegate   = self;
	[ch_featuredCell reloadData];
    return ch_featuredCell;
}





// ------------------------------------------------------------------------------
// tableView:cellForRowAtIndexPath:
// ------------------------------------------------------------------------------
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == kFeaturedSection) {
        return [self featuredCell];
    }
	UITableViewCell * cell;
	
	if (indexPath.row == 0) {
		static NSString * cellID = @"1stCHBrowseCategoryCell";
		cell = [tableView dequeueReusableCellWithIdentifier:cellID];
		
		if (cell == nil) {
			cell = [[CHPlainTableViewCell alloc] initWithReuseIdentifier:cellID isFirst:YES];
		}
	} else {
		static NSString * cellID = @"CHBrowseCategoryCell";
		cell   = [tableView dequeueReusableCellWithIdentifier:cellID];
        
		if (cell == nil) {
			cell = [[CHPlainTableViewCell alloc] initWithReuseIdentifier:cellID];
		}
	}
    
    ProductCategory * category = [self.productCategories objectAtIndex:indexPath.row];
    cell.textLabel.text = category.name;
    cell.accessoryType  = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}





// ------------------------------------------------------------------------------
// tableView:numberOfRowsInSection:
// ------------------------------------------------------------------------------
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == kFeaturedSection) {
        return 1;
    }
    
    if (self.productCategories == nil) {
        return 0;
    }
    
    return [self.productCategories count];
}





// ------------------------------------------------------------------------------
// tableView:willSelectRowAtIndexPath
// ------------------------------------------------------------------------------
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == kFeaturedSection) {
        return nil;
    }
    
    return indexPath;
}





// ------------------------------------------------------------------------------
// tableView:didSelectRowAtIndexPath:(NSIndexPath *)indexPath
// ------------------------------------------------------------------------------
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.productCategories == nil) {
        return;
    }
    
    CHBrowseCategoryViewController * categoryVC = [[CHBrowseCategoryViewController alloc] init];
    categoryVC.category = [self.productCategories objectAtIndex:indexPath.row];
    
    [self.navigationController pushViewController:categoryVC animated:YES];
}





#pragma mark -
#pragma mark CHFeatureCellDataSource

- (NSInteger)featuredCellFeaturedProductCount:(CHFeaturedCell *)cell {
    return [self.featuredProducts count];
}





- (Product *)featuredCell:(CHFeaturedCell *)cell featuredProductAtIndex:(NSInteger)index {
    if ((self.featuredProducts == nil) || (index < 0) || (index >= [self.featuredProducts count])) {
        return nil;
    }
    
    return [self.featuredProducts objectAtIndex:index];
}





#pragma mark -
#pragma mark CDClientDelegate

- (void)retrieveFeaturedItemsSucceeded:(NSArray *)productArray
{	
	NSLog(@"Update featured products in browse view");
	[AppDelegate sharedAppDelegate].featuredProducts = productArray;
	[self setFeaturedProducts:[AppDelegate sharedAppDelegate].featuredProducts];
    [self showFeaturedItems];
}

- (void)retrieveFeaturedItemsWithFault:(Fault *)fault
{
	NSLog(@"There was a problem retrieving featured items:\n%@", fault);
}

- (void)productCategoriesRetrieved:(NSArray *)productCategoryArray {
	[self.splash dismissModalViewControllerAnimated:YES];
	self.splash = nil;
    self.productCategories = productCategoryArray;
}





- (void)productCategoryRetrievalFailedWithFault:(Fault *)fault {
	[self.splash dismissModalViewControllerAnimated:YES];
	self.splash = nil;
    [fault showWithTitle:@"Network error"];
}





#pragma mark -
#pragma mark CHFeaturedCell Delegate

- (void)purchaseProduct:(Product *)product {
    [super purchaseProduct:product];
}

- (void)showDetailsForProduct:(Product *)product {
    CHDetailsViewController * details = [[CHDetailsViewController alloc] init];
    details.product  = product;
    [self.navigationController pushViewController:details animated:YES];
}

@end
