//
//  CHSettings.h
//  Chicago
//
//  Created by Brian Cooke on 9/7/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CHSettings : NSObject {

}

@property (nonatomic, weak) NSString *deviceAuthenticationKey;
@property (nonatomic, weak) NSString *subscriberID;
@property (nonatomic, strong) NSString *loginName;

+ (CHSettings *) sharedCHSettings;
- (void) removeSubscriberInfo;
- (NSString *)deviceIDForLogin:(NSString *)aLogin;
- (void)setDeviceID:(NSString *)aDeviceID forLogin:(NSString *)aLogin;

@end
