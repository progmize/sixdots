//
// CHProductDetailView.h
// Chicago
//
// Created by Derr on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PurchasProductDelegate.h"
#import "CHFlippableView.h"


@class Product;
@class ProductCategory;
@class CHStarsView;

@interface CHProductDetailCell : UITableViewCell<CHFlippableViewDelegate> {
  UIImageView               *ch_image1;
  CHStarsView               *ch_rating;
  UILabel                   *ch_title;
  UILabel                   *ch_time;
  UILabel                   *ch_guidence;
  UILabel                   *ch_licensing;
  UIImageView               *ch_licensingBackground;
  UILabel                   *ch_details;
  UIButton                  *ch_priceButton;
  UIButton                  *ch_showLicenseButton;
  id<PurchasProductDelegate> __unsafe_unretained delegate;
  NSURL                     *thumbnailURL;
  BOOL                       ch_libraryItem;
  CHFlippableView           *ch_flippingParent;
  UIView                    *ch_licenseView;
  UIButton                  *ch_hideLicensingButton;

  Product *ch_product;
}

@property (nonatomic, unsafe_unretained) id<PurchasProductDelegate> delegate;
@property (strong) NSURL                                *thumbnailURL;
@property (nonatomic, assign) BOOL                       libraryItem;

// TODO remove theCategory since we won't be needing it anymore.
- (void)setProduct:(Product *)theProduct inCategory:(ProductCategory *)theCategory;

@end
