//
//  ImageCache.m
//  Chicago
//
//  Created by louie on 8/12/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "ImageCache.h"
#import "SynthesizeSingleton.h"
#import "ImageCachingOperation.h"

@implementation ImageCache

SYNTHESIZE_SINGLETON_FOR_CLASS(ImageCache);

- (id)init {
  if ((self = [super init])) {
    operationQueue = [[NSOperationQueue alloc] init];
    operationQueue.maxConcurrentOperationCount = 1;
    
    urlsToImages = [[NSMutableDictionary alloc] init];
  }
  return self;
}


- (UIImage *)imageForURL:(NSURL *)url scaled:(BOOL)shouldScale {
  // Don't allow nil URLs.
  if (url == nil) { return nil; }
  
  UIImage *cachedImage = [urlsToImages objectForKey:url];
  if (cachedImage == nil) {
    ////NSLog(@"Fetching image for URL:%@", url);
    // Fetch the image and store in cache.
    ImageCachingOperation *operation = [[ImageCachingOperation alloc] initScaled:shouldScale];
    operation.imageURL = url;
    [operationQueue addOperation:operation];
  } else {
    ////NSLog(@"Image found in cache for URL:%@", url);
  }
  return cachedImage;
}

- (UIImage *)imageForURL:(NSURL *)url {
  return [self imageForURL:url scaled:NO];
}

- (void)storeImage:(UIImage *)image forURL:(NSURL *)url {
  if (image == nil) {
    // seeing this a bunch while testing session timeout stuffs
    // try again
    image = [self imageForURL:url];
    if (image == nil)
      return; // we'll be back.
  }
  
  ////NSLog(@"Image downloaded and store for URL:%@", url);
  
  [urlsToImages setObject:image forKey:url];
  
  // Send notification
  // TODO send the URL as the notification
  [[NSNotificationCenter defaultCenter] postNotificationName:@"ImageDownloaded" object:url];
}

@end
