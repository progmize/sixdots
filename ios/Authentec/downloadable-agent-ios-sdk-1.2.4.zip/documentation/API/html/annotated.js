var annotated =
[
    [ "DACachedContent", "interface_d_a_cached_content.html", "interface_d_a_cached_content" ],
    [ "DAContentInfo", "interface_d_a_content_info.html", "interface_d_a_content_info" ],
    [ "DownloadableAgent", "interface_downloadable_agent.html", "interface_downloadable_agent" ],
    [ "<LicenseAcquisitionDelegate>", "protocol_license_acquisition_delegate-p.html", "protocol_license_acquisition_delegate-p" ]
];