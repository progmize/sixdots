//
//  CDExceptionDelegate.h
//  ContentDirectAPI
//
//  Created by Brandon on 2/23/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CDExceptionDelegate <NSObject>

@optional
- (void)exceptionOccured:(Fault *)exception;

@end