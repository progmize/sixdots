package com.authentec.drm.android.reference.activities;

import android.app.*;
import android.content.*;
import android.os.*;
import android.text.*;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.authentec.drm.android.reference.*;

/**
 * @author AuthenTec Inc.
 */
public class SettingsActivity extends Activity
{
    private static final String TAG = "SettingsActivity";
    private static Dialog sLastDisplayedDialog;
    private SharedPreferences mPreferences;
    private SharedPreferences.Editor mEditor;

    @Override
    protected void onSaveInstanceState(final Bundle outState)
    {
        super.onSaveInstanceState(outState);
        if (sLastDisplayedDialog != null)
        {
            sLastDisplayedDialog.dismiss();
        }
    }

    @Override
    protected void onRestoreInstanceState(final Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        if (sLastDisplayedDialog != null)
        {
            sLastDisplayedDialog.show();
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings);

        mPreferences = getSharedPreferences(Constants.PREFERENCES_FILENAME,Context.MODE_PRIVATE);
        mEditor = mPreferences.edit();

        Button button = (Button) findViewById(R.id.button_delete_all_content);
        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(final View view)
            {
                AlertDialog customAlertDialog = createCustomAlertDialog(getText(R.string.delete_content_warning), new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dlg, int sumthin)
                    {
                        Log.d(TAG, "Initiating deletion of all registered content");
                        ContentHandler.deleteAllContent();
                        sLastDisplayedDialog = null;
                    }
                });
                sLastDisplayedDialog = customAlertDialog;
                customAlertDialog.show();
            }
        });

        button = (Button) findViewById(R.id.button_reset_drm_store);
        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(final View view)
            {

                AlertDialog customAlertDialog = createCustomAlertDialog(getText(R.string.reset_warning), new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dlg, int sumthin)
                    {
                        Log.d(TAG, "Initiating purge of all installed licenses");
                        DRMAgentDelegate.purgeLicenses(SettingsActivity.this);
                        sLastDisplayedDialog = null;
                    }
                });

                sLastDisplayedDialog = customAlertDialog;
                customAlertDialog.show();
            }
        });

        button = (Button) findViewById(R.id.button_clear_cached_files);
        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(final View view)
            {

                AlertDialog customAlertDialog = createCustomAlertDialog(getText(R.string.clear_cache_warning), new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dlg, int sumthin)
                    {
                        Log.d(TAG, "Initiating delete of all cached content");
                        DRMAgentDelegate.purgeCachedFiles(SettingsActivity.this);
                        sLastDisplayedDialog = null;
                    }
                });

                sLastDisplayedDialog = customAlertDialog;
                customAlertDialog.show();
            }
        });

        button = (Button) findViewById(R.id.button_restore_content);
        button.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(final View view)
            {

                AlertDialog customAlertDialog = createCustomAlertDialog(getText(R.string.restore_content), new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dlg, int sumthin)
                    {
                        Log.d(TAG, "Restoring all content");
                        ContentHandler.addDefaultContent(SettingsActivity.this);
                        sLastDisplayedDialog = null;
                    }
                });

                sLastDisplayedDialog = customAlertDialog;
                customAlertDialog.show();
            }
        });


        Spinner nexTreamingLogLevelSpinner = (Spinner) findViewById(R.id.nexplayer_log_level);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.nexplayer_log_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nexTreamingLogLevelSpinner.setAdapter(adapter);
        final int nexPlayerLogLevel = mPreferences.getInt(Constants.PREFERENCES_NEXTREAMING_LOG_LEVEL, -1);
        nexTreamingLogLevelSpinner.setSelection(nexPlayerLogLevel+1);
        nexTreamingLogLevelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(final AdapterView<?> parent, final View view, final int position, final long id)
            {
                mEditor.putInt(Constants.PREFERENCES_NEXTREAMING_LOG_LEVEL, position - 1);
            }

            public void onNothingSelected(final AdapterView<?> parent)
            {
            }
        });

        Spinner nexTreamingRendererSpinner = (Spinner) findViewById(R.id.nexplayer_renderer);
        adapter = ArrayAdapter.createFromResource(this, R.array.nexplayer_renderers, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nexTreamingRendererSpinner.setAdapter(adapter);
        final int nexPlayerRenderer = mPreferences.getInt(Constants.PREFERENCES_NEXTREAMING_RENDERER, 0);
        nexTreamingRendererSpinner.setSelection(nexPlayerRenderer);
        nexTreamingRendererSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(final AdapterView<?> parent, final View view, final int position, final long id)
            {
                mEditor.putInt(Constants.PREFERENCES_NEXTREAMING_RENDERER, position);
            }

            public void onNothingSelected(final AdapterView<?> parent)
            {
            }
        });


        Spinner agentLogLevelSpinner = (Spinner) findViewById(R.id.agent_log_level);
        adapter = ArrayAdapter.createFromResource(
                this, R.array.agent_log_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        agentLogLevelSpinner.setAdapter(adapter);
        final int agentPlayerLogLevel = mPreferences.getInt(Constants.PREFERENCES_AGENT_LOG_LEVEL, 0);
        agentLogLevelSpinner.setSelection(agentPlayerLogLevel);
        agentLogLevelSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            public void onItemSelected(final AdapterView<?> parent, final View view, final int position, final long id)
            {
                mEditor.putInt(Constants.PREFERENCES_AGENT_LOG_LEVEL, position);
            }

            public void onNothingSelected(final AdapterView<?> parent)
            {
            }
        });


        CheckBox forceTimebasedLicenseForContent = (CheckBox)findViewById(R.id.force_timebased_license_for_content);
        forceTimebasedLicenseForContent .setChecked(mPreferences.getBoolean(Constants.PREFERENCES_FORCE_TIMEBASED_LICENSE_FOR_CONTENT, false));
        forceTimebasedLicenseForContent .setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_FORCE_TIMEBASED_LICENSE_FOR_CONTENT, isChecked);
                mEditor.commit();
            }
        });

        final EditText timeBasedLicenseValue = (EditText)findViewById(R.id.timebased_license_value);
        timeBasedLicenseValue.setText("" + mPreferences.getInt(Constants.PREFERENCES_TIMEBASED_LICENSE_NUM_MINUTES, 2), TextView.BufferType.NORMAL);
        timeBasedLicenseValue.addTextChangedListener(new TextWatcher()
        {
            public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after)
            {
            }

            public void onTextChanged(final CharSequence s, final int start, final int before, final int count)
            {
            }

            public void afterTextChanged(final Editable editable)
            {
                final String s = editable.toString();
                try
                {
                    final int value = Integer.parseInt(s);
                    mEditor.putInt(Constants.PREFERENCES_TIMEBASED_LICENSE_NUM_MINUTES, value);
                    mEditor.commit();
                }
                catch (NumberFormatException e)
                {
                    // Error parsing the integer - signal that error
                    timeBasedLicenseValue.setError("Input must be a valid, +ve integer");
                }
            }
        });

         CheckBox forceOPLLicenseForContent = (CheckBox)findViewById(R.id.force_opl_license_for_content);
        forceOPLLicenseForContent .setChecked(mPreferences.getBoolean(Constants.PREFERENCES_FORCE_OPL_LICENSE_FOR_CONTENT, false));
        forceOPLLicenseForContent .setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_FORCE_OPL_LICENSE_FOR_CONTENT, isChecked);
                mEditor.commit();
            }
        });

        final EditText oplLicenseValue = (EditText)findViewById(R.id.opl_license_value);
        oplLicenseValue.setText("" + mPreferences.getInt(Constants.PREFERENCES_OPL_LICENSE_LEVEL, 100), TextView.BufferType.NORMAL);
        oplLicenseValue.addTextChangedListener(new TextWatcher()
        {
            public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after)
            {
            }

            public void onTextChanged(final CharSequence s, final int start, final int before, final int count)
            {
            }

            public void afterTextChanged(final Editable editable)
            {
                final String s = editable.toString();
                try
                {
                    final int value = Integer.parseInt(s);
                    mEditor.putInt(Constants.PREFERENCES_OPL_LICENSE_LEVEL, value);
                    mEditor.commit();
                }
                catch (NumberFormatException e)
                {
                    // Error parsing the integer - signal that error
                    oplLicenseValue.setError("Input must be a valid, +ve integer");
                }
            }
        });

        CheckBox ignoreMimetypeValidationErrors = (CheckBox)findViewById(R.id.ignore_mimetype_validation_errors);
        ignoreMimetypeValidationErrors .setChecked(mPreferences.getBoolean(Constants.PREFERENCES_IGNORE_MIMETYPE_VALIDATION_ERRORS, true));
        ignoreMimetypeValidationErrors .setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_IGNORE_MIMETYPE_VALIDATION_ERRORS, isChecked);
                mEditor.commit();
            }
        });

        TextView useNativePlayerLabel = (TextView)findViewById(R.id.use_native_player_label);
        CheckBox useNativePlayer = (CheckBox)findViewById(R.id.use_native_player);
        CheckBox useRemoteURL = (CheckBox) findViewById(R.id.use_remote_url);
        TextView useRemoteURLLabel = (TextView) findViewById(R.id.use_remote_url_label);

        //subtitles
        CheckBox showSubtitles = (CheckBox) findViewById(R.id.show_subtitles);

        showSubtitles.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_SHOW_SUBTITLES, true));
        showSubtitles.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_SHOW_SUBTITLES, isChecked);
                mEditor.commit();
            }
        });

        //resume play from last known time
        CheckBox resumePlayFromLastKnownTime = (CheckBox)findViewById(R.id.resume_play_from_last_known_time);
        resumePlayFromLastKnownTime .setChecked(mPreferences.getBoolean(Constants.PREFERENCES_RESUME_PLAY_FROM_LAST_KNOWN_TIME, true));
        resumePlayFromLastKnownTime .setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_RESUME_PLAY_FROM_LAST_KNOWN_TIME, isChecked);
            }
        });

        //ask for lic. acknowledgment
        CheckBox askForLicenseAck = (CheckBox)findViewById(R.id.ask_for_license_acknowledgement_for_licenses);
        askForLicenseAck.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_FORCE_ACKNOWLEDGEMENT_LICENSE_FOR_CONTENT, false));
        askForLicenseAck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_FORCE_ACKNOWLEDGEMENT_LICENSE_FOR_CONTENT, isChecked);
            }
        });

        //ask for lic. acknowledgment
        CheckBox asyncLicenseAck = (CheckBox)findViewById(R.id.async_license_acknowledgement);
        asyncLicenseAck.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_ACKNOWLEDGE_LICENSES_ASYNCHRONOUSLY, false));
        asyncLicenseAck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_ACKNOWLEDGE_LICENSES_ASYNCHRONOUSLY, isChecked);
            }
        });


        //lock screen to landscape mode (only for Nexplayer)
        CheckBox lockScreenToLandscape = (CheckBox)findViewById(R.id.lock_screen_landscape_for_Nexplayer);
        lockScreenToLandscape.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_LOCK_SCREEN_TO_LANDSCAPE_MODE_FOR_NEXPLAYER, true));
        lockScreenToLandscape.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
        {
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
            {
                mEditor.putBoolean(Constants.PREFERENCES_LOCK_SCREEN_TO_LANDSCAPE_MODE_FOR_NEXPLAYER, isChecked);
            }
        });

        TextView bufferSizeLabel = (TextView) findViewById(R.id.buffer_size_label);
        final EditText bufferSize = (EditText) findViewById(R.id.buffer_size);

        if (Build.VERSION.SDK_INT >= 11)
        {
            useNativePlayer.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_USE_NATIVE_PLAYER, false));
            useNativePlayer.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
            {
                public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
                {
                    mEditor.putBoolean(Constants.PREFERENCES_USE_NATIVE_PLAYER, isChecked);
                    mEditor.commit();
                }
            });

            useRemoteURL = (CheckBox) findViewById(R.id.use_remote_url);
            useRemoteURL.setChecked(mPreferences.getBoolean(Constants.PREFERENCES_USE_REMOTE_URL_FOR_NATIVE_PLAYER, false));
            useRemoteURL.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener()
            {
                public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked)
                {
                    mEditor.putBoolean(Constants.PREFERENCES_USE_REMOTE_URL_FOR_NATIVE_PLAYER, isChecked);
                    mEditor.commit();
                }
            });

            int currentBufferSize = mPreferences.getInt(Constants.PREFERENCES_NATIVE_PLAYER_BUFFER_SIZE, 10000);
            bufferSize.setText(""  + currentBufferSize, TextView.BufferType.EDITABLE);

            bufferSize.addTextChangedListener(new TextWatcher()
            {
                public void beforeTextChanged(final CharSequence charSequence, final int i, final int i1, final int i2)
                {
                }

                public void onTextChanged(final CharSequence charSequence, final int i, final int i1, final int i2)
                {
                }

                public void afterTextChanged(final Editable editable)
                {
                    final String s = editable.toString();
                    try
                    {
                        final int value = Integer.parseInt(s);
                        mEditor.putInt(Constants.PREFERENCES_NATIVE_PLAYER_BUFFER_SIZE, value);
                        mEditor.commit();
                    }
                    catch (NumberFormatException e)
                    {
                         // Error parsing the integer - signal that error
                         bufferSize.setError("Input must be a valid, +ve integer");
                    }
                }
            });


        }
        else
        {
            useNativePlayer.setVisibility(View.GONE);
            useNativePlayerLabel.setVisibility(View.GONE);
            useRemoteURL.setVisibility(View.GONE);
            useRemoteURLLabel.setVisibility(View.GONE);
            bufferSize.setVisibility(View.GONE);
            bufferSizeLabel.setVisibility(View.GONE);
        }



    }

    @Override
    protected void onStop()
    {
        super.onStop();
        mEditor.commit();
    }

    private AlertDialog createCustomAlertDialog(CharSequence message, DialogInterface.OnClickListener onClickListener)
    {
        final AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle(R.string.warning);
        alertDialogBuilder.setMessage(message);
        alertDialogBuilder.setInverseBackgroundForced(true);
        alertDialogBuilder.setPositiveButton(getText(R.string.Yes), onClickListener);
        alertDialogBuilder.setNegativeButton(getText(R.string.No), new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dlg, int sumthin)
            {
                // Do nothing?
                sLastDisplayedDialog = null;
            }
        });


        return alertDialogBuilder.create();
    }

}
