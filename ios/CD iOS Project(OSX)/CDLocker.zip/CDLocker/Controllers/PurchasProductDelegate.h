//
//  PurchasProductDelegate.h
//  Chicago
//
//  Created by Derr on 8/9/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol PurchasProductDelegate

// this will of course need to be updated to include details about the item.
// either the item itself or at the very least a product id.
- (void)purchaseProduct:(Product *)product;

- (void)showDetailsForProduct:(Product *)product;

@end
