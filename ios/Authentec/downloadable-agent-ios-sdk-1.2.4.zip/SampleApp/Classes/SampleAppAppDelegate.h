//
//  SampleAppAppDelegate.h
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SampleViewController.h"

@interface SampleAppAppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow *window;
	SampleViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SampleViewController *viewController;

@end
