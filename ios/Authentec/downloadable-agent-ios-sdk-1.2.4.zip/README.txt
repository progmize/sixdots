
 Downloadable Agent for iOS	

 Copyright (c) 2012 AuthenTec Inc. All rights reserved.
___________________________________________________________________________________________________________________________


PACKAGE CONTENTS:
----------------

The release package contains the following elements:

+ root folder 
|
+-- documentation: User manual, PlayReady certificates provisioning, API documentation in PDF and HTML format, and a document detailing the security of the solution.
|
+--+ libDownloadableAgent
|  |
|  - libDownloadableAgent.a: The universal (multi-architecture) static library compiled for armv7 and i386.
|  |
|  +-- include: The public headers for the library.
|  |
|  +-- protected-lib: Contains the protected version of the library compiled for armv7, the finalization files and the finalization script.
|
+-- finalization-tools: the finalizer utility and the dynamic library it depends on, required to finalize any application that links against the protected library.
|
+-- provisioning-tools: contains the necessary tools and batch scripts for the PlayReady device model certificate provisioning process.
|
+-- SampleApp: Xcode project for AuthenTec's reference implementation app.


KNOWN ISSUES:
------------

- HDMI control API might not display the alternative image when DAHdmiUseAlternative mode is selected;
- EXC_BAD_ACCESS when releasing autorelease pool after double database reset;


RELEASE NOTES:
-------------

*** 1.2.4 [February 21st, 2012]

- Smooth Streaming: Implemented support for multiple audio tracks. The new API allows to switch to a particular audio track before and during playback.
- PIFF files: Implemented caching of progressively downloaded files to disk for offline playback.
- Fixed issues with handling of PIFF files which have large SMIL headers in the UUID atom.
- Fixed bug whereby licenses with rights valid on a future date could not be manually removed.
- Fixed small memory leak when playing PIFF files.
- Fixed DAHdmiUseAlternative OPL mode not restoring the player view after playback is finished.
- Fixed crash when parsing an HLS playlist with one or more quoted attribute values that contain a comma.
- Reference app: Refactored the example code that shows how to play video using the AVFoundation framework. The AVPlayer is now handled by a separate view controller and the UI now includes a pause button.
- Reference app: Added a switch to the UI to use AVPlayer instead of the default MPMoviePlayerViewController.
- The user manual has been updated to reflect the new features. The integration guide now contains instructions for configuring Xcode 4.2 instead of Xcode 3.2.
- The auto-generated PDF document that describes the Agent API has had some cosmetic updates.
! API CHANGES: The DAContentType types 'FullyDownloadedPIFFType' and 'ProgressivelyDownloadedPIFFType' are now deprecated. Use the new type 'PIFFType' instead for all PIFF files, regardless of whether they are local or remote.


*** 1.2.3 [January 24th, 2012]

- Smooth Streaming: Fixed all remaining audio synchronization issues.
- Smooth Streaming: Further tweaking for playback stability and performance in general.
- Smooth Streaming: Fixed a small bug whereby stream discontinuities were being incorrectly signaled to the player, resulting in a choppy playback experience.
- Interval rights (i.e. rights that expire only after first use) are now consumed properly for Smooth Streaming content and PIFF files. This condition is now also indicated in the ContentInfo class by means of a new property 'rightsExpireOnlyAfterFirstUse'.
- Renamed dummy method name 'ignore:' that could erroneously trigger private API usage when submitting to the AppStore.
- Fixed all the 'ARM function not 4-byte aligned' compiler warnings.
- Fixed NSNotifications sender not being the Agent instance on some cases.
- Added new method to the API to retrieve the PlayReady device ID.
- Implemented KVO observers for debugging the player status when using AVFoundation.
- Updated the finalization script and the documentation to reflect the fact that the Apple LLVM 3.0 compiler is fully supported.
- The product does no longer use FFmpeg as dependency.


*** 1.2.3a [December 22nd, 2011]

- Smooth Streaming: Fixed all audio synchronization issues.
- Smooth Streaming: Improved playback stability and performance in general.
- Interval rights (i.e. rights that expire only after first use) are now consumed properly for Smooth Streaming content and PIFF files. This condition is now also indicated in the ContentInfo class by means of a new property 'rightsExpireOnlyAfterFirstUse'.
- Added new method to the API to retrieve the PlayReady device ID.
- Renamed dummy method name 'ignore:' that could erroneously trigger private API usage when submitting to the AppStore.
- The product does no longer use FFmpeg as dependency.


*** 1.2.2 [December 14th, 2011]

- Smooth Streaming: Fixed performance issue introduced in the previous version that artificially increased the MPEG2 transport stream muxing time.
- Smooth Streaming: Improved the playback of streams with small fragment lengths, such as the default of 2 seconds, specially on devices with dual-core CPUs. Also the playback should now resume faster after seeking.
- Smooth Streaming: Fixed all remaining issues concerning streams encoded with B-frames.
- Smooth Streaming: Fixed some potential playback issues when playing content under iOS 5.
- Smooth Streaming: Added support for the '{chunk id}' attribute in the fragment URLs, used by Wowza media server.
- Fixed issue with the HDMI output control API whereby the external screen would not switch back to the original state after the playback finished on devices with iOS 5.
- Fixed compatibility issues with the iOS 5 Simulator.
- Fixed license acquisition failing for local PIFF files when 'contentInfo' had not been invoked before.
- All NSNotifications are now delivered in the main thread and the sender object is the actual instance of the Agent that created them.
- Implemented full support for Cisco's custom HLS extensions.
- Updated ASIHTTPRequest component to version 1.8.1-61.


*** 1.2.1 [October 4th, 2011]

- Fixed a bug occurring only on iOS 5 whereby if the player requested segments from the same bit-rate multiple times, with intervening requests from other bitrates in between, the movie would skip playing back certain segments due to internal "404" (not found) errors.
- Fixed "Video playback of SS content flickers if using H.264 Main Profile with B-frames (DAIOS-67)". Now Main Profile with B-frames is supported as long as there is no more than 1 B-frame between other I- and P-frames.
- Fixed "Playback of some B-frame content ended prematurely on iOS5" (DAIOS-123)


*** 1.2.0 [September 15th, 2011]

- Added support for playback of local and remotely hosted fragmented MP4 (PIFF) files, with and without PlayReady encryption.
- Added support for Output Protection Levels (OPL) on issued licenses and also via custom API.
- Added example code to show how to use AVFoundation framework to the reference implementation app.
- The finalization of protected apps is now performed locally rather than through the remote service (see the user manual for instructions).
- iOS versions previous to 4.0 are no longer officially supported.
- The user manual has been updated, including new information about each content format supported on this version.


*** 1.1.13 [September 12th, 2011]

- Implemented SSL client authentication. The iOS media player is now authenticated when connecting to the embedded server by its built-in Apple signed client identity. Note: this feature is only supported on iOS 4.0 and later. Client authentication will not be enforced when running the Agent on older iOS versions.
- Implemented initial support for using the AVFoundation framework to play protected content.
- Fixed issues opening certain PlayReady Envelope encrypted files with a header larger than 10 Kbytes.
- Fixed regression bug introduced in the previous version related to using query parameters in HLS content URLs.
- Several performance enhancements in the protected library.
- Reduced the static library size by removing some unnecessary dependencies.
- Updated documentation to reflect the usage of the AVFoundation framework and the need to configure the C/C++ compiler correctly for protected build targets.


*** 1.1.12 [August 23rd, 2011]

- Smooth Streaming: Fixed an issue where the audio and video would lose sync after several minutes of playback for VOD content.
- Smooth Streaming: Memory usage has been slightly improved.
- Added new playlist obfuscation method for both HLS and SS content.
- Fixed playback issues with encrypted Live HLS streams.


*** 1.1.11 [August 12th, 2011]

- Updated internal SSL certificate, now expiring on August 3rd, 2013.
- The protected library is now also compatible with the latest iOS 5 beta.
- NOTE: If you are updating from any previous version please make sure you update your finalization script to the one included in this release.


*** 1.1.10 [July 27th, 2011]

- Fixed: long buffering and/or audio-only issues when playing Smooth Streaming streams encoded with AUD NAL units in the H264 payload.
- Fixed: rare crash when quitting the player after a Smooth Streaming playback session.
- Initial fixes for compatibility with iOS 5 beta (the protected library is still not compatible).

*** 1.1.9 [July 14th, 2011]

- Added support for joining a domain during license acquisition if the server requires it.
- Updated documentation to reflect the above changes.
- Fixed: occasional crash if a license expired during playback (Smooth Streaming only).


*** 1.1.8 [June 29th, 2011]

- Added new win32 tool to manually test the PlayReady model certificates before provisioning the Agent.
- Fixed: issue where the playback of an encrypted HLS feed would fail if the server responded with a redirect response (301, 302, etc).
- Fixed: some file handles were not being closed properly.
- Fixed: silent license acquisition mode was reporting success when the license server responded with certain HTTP error status.
- The API should now be more robust to invalid inputs.


*** 1.1.7 [June 17th, 2011]

- Added jailbreak detection API.
- Re-enabled developer logs via NSNotifications (had been disabled by mistake).
- Improved obfuscation of strings that contain sensitive data.
- Fixed installation issues with the distributable package of the new demo app.
- Fixed a few harmless compiler warnings in the reference app project.
- Added "Appendix C: Message flow diagram" to the documentation.


*** 1.1.6 [June 8th, 2011]

- Smooth Streaming: Improved the calculation of presentation timestamps (PTS) for the audio and video frames.
- Smooth Streaming: Fixed rights removal for protected Smooth Streaming content.
- Distributable build of the SampleApp is no longer included in the release package (the new demo app is released separately instead).
- Updated build of the core DRM Agent to 1.23.3.


*** 1.1.5 [May 31st, 2011]

- Updated user manual to reflect all changes in version 1.1, including upgrade notes for customers with version 1.0 (see Appendix B).
- The unprotected device and simulator libraries have been merged into a single universal (multi-architecture) library.


*** 1.1.4 [May 27th, 2011]

- Smooth Streaming: fixed content playback issue on iOS 4.0.x to and 4.1.x.
- Smooth Streaming: the player should play higher quality streams than previous versions under slow data connections.
- Smooth Streaming: bit-rate switching should be faster now.
- Smooth Streaming: much faster parsing of the XML manifest, specially when reloading it during live streams.
- Smooth Streaming: implemented caching of last audio chunk for faster responses.
- Protected (obfuscated) version of the library is now available.


*** 1.1.3 [May 18th, 2011]

- Smooth Streaming: Improved playback on slow data connections.
- Smooth Streaming: Fixed bug upon decrypting certain Harmonic's encrypted video streams.
- Smooth Streaming: The player should now report the total movie duration more accurately on iOS 4.2 and later.
- Renamed Apple's Reachability sample classes to avoid potential duplicated symbol issues.
- Better security self-checks.


*** 1.1.2 [May 11th, 2011]

- Smooth Streaming: Improved manifest parser with support for <CustomAttributes> element, fixed chunk duration parsing bug.
- Smooth Streaming: Fixed some audio/video sync issues.
- Improved performance and speed when serving HTTP requests.
- Improved memory footprint.


*** 1.1.1 [May 6th, 2011]

- Implemented support for VOD and live Smooth Streaming feeds.
- Added new method to generate a PlayReady challenge for a given DRM header.
- Added new method to insert custom data in the license acquisition challenge.
- Some API changes to accommodate Smooth Streaming content and other future types of content.
- Updated the reference implementation app with logic to handle protected and unprotected Smooth Streaming samples.


*** 1.0.4  [April 8th, 2011]

- Added new notification to report the HTTP error codes upon requesting files to the content server(s).
- Improved the notification throttling logic.
- Fixed a potential (although very rare) crash.


*** 1.0.3  [April 5th, 2011]

- Fixed security issue which could lead to a potential man-in-the-middle type of attack.
- Added new notification to signal that the Agent will proactively stop the playback when a security breach has been detected.
- Added HTTP proxy detection code to help dealing with the bug introduced by Apple in 4.2.1 (see Known Issues section of the documentation).
- Updated PlayReady device model certificate provisioning tools and documentation.
- Updated user manual.


*** 1.0.2  [March 25th, 2011]

- Fixed crash on those methods of the API with an optional NSError parameter not being passed.
- Improved player stability on bad network conditions, forcing it to retry requests that failed due to a time out or network unavailable.
- The Agent is now more flexible with the MIME types of the files downloaded, issuing warnings rather than failing when a bad Content-Type is detected.
- Added new notification to signal the scenario when the Agent has downloaded an invalid piece of content, possibly due to the HTTP request being redirected to an authentication page or similar. 
- Added new notification to signal when the Agent has detected a critical issue that may prevent playback.
- Fixed notifications being sent multiple times for the same issue.
- Fixed license re-acquisition during playback failing under certain conditions.
- Fixed Agent not signaling decryption errors under certain conditions.
- Verified working with iOS 4.3 and added example code to print the new HLS statistics after playback ends.


*** 1.0.1  [February 21th, 2011]

- Improved system clock rollback detection. The Agent should now return untrusted time in the rights status for a content as soon as a rollback is detected.
- Fixed the DownloadableAgentLicenseHasExpiredNotification notification being sent instead of the DownloadableAgentPlaybackRightsNotAvailableNotification notification.
- Improved error reporting API.
- Improved the Doxygen configuration for better auto-generated API documentation.
- Introduced the remote executable finalization service to build protected targets.
- General bug fixing and code improvements.


*** 1.0  [February 11th, 2011]

- First official release of the Downloadable Agent for iOS with native player.
- Implemented support for encrypted HTTP Live Streaming feeds.
- Implemented anti-tampering and anti-debugging protection features.
- Included full source code for the reference implementation app.


LICENSE FOR 3rd PARTY COMPONENTS:
--------------------------------

The following is a list of 3rd party open source frameworks and their respective licenses that have been used in the development of the Downloadable Agent for iOS.

-----------------------------------------------------------------------------
- ASIHTTPRequest version 1.8.1-61 [http://allseeing-i.com/ASIHTTPRequest]

* Copyright (c) 2007-2011, All-Seeing Interactive
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
* * Redistributions of source code must retain the above copyright
* notice, this list of conditions and the following disclaimer.
* * Redistributions in binary form must reproduce the above copyright
* notice, this list of conditions and the following disclaimer in the
* documentation and/or other materials provided with the distribution.
* * Neither the name of the All-Seeing Interactive nor the
* names of its contributors may be used to endorse or promote products
* derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY All-Seeing Interactive ''AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL All-Seeing Interactive BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


-----------------------------------------------------------------------------
- CocoaHTTPServer revision ed4424ab157b [http://code.google.com/p/cocoahttpserver/]
- CocoaLumberJack revision revision 64e7380d6f2d [http://code.google.com/cocoalumberjack/]

Copyright (c) 2006, Deusty Designs, LLC
All rights reserved.

Redistribution and use of this software in source and binary forms,
with or without modification, are permitted provided that the following conditions are met:

* Redistributions of source code must retain the above
copyright notice, this list of conditions and the
following disclaimer.

* Neither the name of Desuty Designs nor the names of its
contributors may be used to endorse or promote products
derived from this software without specific prior
written permission of Deusty Designs, LLC.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


-----------------------------------------------------------------------------
- libcurl version 7.21.7 [http://curl.haxx.se/libcurl/]

COPYRIGHT AND PERMISSION NOTICE

Copyright (c) 1996 - 2011, Daniel Stenberg, <daniel@haxx.se>.

All rights reserved.

Permission to use, copy, modify, and distribute this software for any purpose
with or without fee is hereby granted, provided that the above copyright
notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS. IN
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of a copyright holder shall not
be used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization of the copyright holder.


-----------------------------------------------------------------------------
- libpcre version 8.0.2 [http://www.pcre.org/]

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice,
      this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in the
      documentation and/or other materials provided with the distribution.

    * Neither the name of the University of Cambridge nor the name of Google
      Inc. nor the names of their contributors may be used to endorse or
      promote products derived from this software without specific prior
      written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.

-----------------------------------------------------------------------------
<EOD>