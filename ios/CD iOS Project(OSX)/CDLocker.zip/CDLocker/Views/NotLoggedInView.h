//
//  NotLoggedInView.h
//  Chicago
//
//  Created by Derr on 9/22/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NotLoggedInViewDelegate;

@interface NotLoggedInView : UIView {
  id<NotLoggedInViewDelegate> __unsafe_unretained delegate;
}

@property (nonatomic, unsafe_unretained)id<NotLoggedInViewDelegate> delegate;

@end


@protocol NotLoggedInViewDelegate

- (void)promptLogin;

@end
    