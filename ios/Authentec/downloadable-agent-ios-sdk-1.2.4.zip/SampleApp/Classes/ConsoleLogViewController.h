//
//  ConsoleLogViewController.h
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ConsoleLogViewController : UIViewController 
{
	NSMutableArray *loggedMessages;
	IBOutlet UITextView *textview;
}

@property (nonatomic, retain) NSMutableArray *loggedMessages;

- (IBAction)done:(id)sender;
- (IBAction)clear:(id)sender; 

@end


