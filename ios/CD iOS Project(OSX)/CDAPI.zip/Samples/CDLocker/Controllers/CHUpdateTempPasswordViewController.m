//
// CHUpdateTempPasswordViewController.m
// Chicago
//
// Created by Brian Cooke on 8/24/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHUpdateTempPasswordViewController.h"
#import "TKLabelTextFieldCell.h"
#import "MBProgressHUD.h"
#import "CHAPIOperation.h"

@implementation CHUpdateTempPasswordViewController




- (id)initWithCurrentPassword:(NSString *)theCurrentPassword {
  if ((self = [super initWithStyle:UITableViewStyleGrouped])) {
    self.currentPassword = theCurrentPassword;
  }

  return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation) || toInterfaceOrientation == UIInterfaceOrientationPortrait;
}


- (void)viewDidLoad {
  [super viewDidLoad];
	
  self.title = NSLocalizedString(@"UPDATE_TEMP_PASSWORD_TITLE", @"Update Password");
  
	self.view.backgroundColor = kCHViewBackgroundColor;
  self.tableView.backgroundColor = kCHTableViewBackgroundColor;

  self.passwordCell = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"pword"];
  self.againCell    = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"again"];

  self.passwordCell.field.secureTextEntry = YES;
  self.againCell.field.secureTextEntry    = YES;
  self.passwordCell.label.text            = NSLocalizedString(@"CONTROL_LOGIN_FORM_PASSWORD", @"password");
  self.againCell.label.text               = NSLocalizedString(@"CONTROL_CREDENTIAL_CONFIRM_PASSWORD", @"again");

  self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
  [self.view addSubview:self.progressHUD];

  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save:)];
}


#pragma mark -
#pragma mark actions
- (IBAction)save:(id)sender {
  [self.passwordCell.field resignFirstResponder];
  [self.againCell.field resignFirstResponder];

  if ([self.passwordCell.field.text isEqualToString:self.againCell.field.text] == NO) {
    [Fault showWithTitle:NSLocalizedString(@"CONTROL_GENERAL_PASSWORD_NOT_MATCH", @"Passwords do not match") andMessage:NSLocalizedString(@"UPDATE_TEMP_PASSWORD_DO_NOT_MATCH", @"The password and password confirmation must match")];
    return;
  } else if (self.passwordCell.field.text == nil) {
    [Fault showWithTitle:NSLocalizedString(@"CONTROL_LOGIN_FORM_PASSWORD_REQUIRED", @"Password required") andMessage:NSLocalizedString(@"ERROR_MESSAGE_PASSWORD_LENGTH ", @"You must enter a password of at least 4 characters")];
    return;
  }

  CHAPIOperation * op = [CHAPIOperation operationToUpdateSubscriberWithCurrentPassword:self.currentPassword newLogin:nil newPassword:self.passwordCell.field.text newChallengeQuestion:nil newChallengeResponse:nil];
  op.delegate = self;
  [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];

  self.progressHUD.labelText = NSLocalizedString(@"PROCESSING_DATA_SAVING_TEXT", @"Saving...");
  [self.progressHUD show:YES];
}


#pragma mark -
#pragma mark Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 42;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
  UILabel * label = [[UILabel alloc] initWithFrame:CGRectZero];

  label.textAlignment   = UITextAlignmentCenter;
  label.textColor       = [UIColor whiteColor];
  label.shadowColor     = [UIColor colorWithWhite:0.33 alpha:1.];
  label.shadowOffset    = CGSizeMake(0.0, 1.0);
  label.text            = NSLocalizedString(@"UPDATE_TEMP_PASSWORD_ENTER_PERMANENT_PASSWORD_TITLE", @"Enter a permanent password");
  label.backgroundColor = [UIColor clearColor];
  return label;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.row == 0) {
    return self.passwordCell;
  } else {
    return self.againCell;
  }
}


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {}



#pragma mark -
#pragma mark CDClientDelegate
- (void)updateCredentialsSucceeded {
  [self.progressHUD hide:YES];

  [self dismissModalViewControllerAnimated:YES];
}


- (void)updateCredentialsFailedWithFault:(Fault *)fault {
  [self.progressHUD hide:YES];

  if ([[fault typeName] isEqualToString:@"ContentDirect.AuthorizationManagement.Contract.Fault.PasswordStrengthViolation"]) {
    [Fault showWithTitle:NSLocalizedString(@"LOGIN_FORM_ENTER_VALID_PASSWORD", @"Password invalid") andMessage:NSLocalizedString(@"ERROR_MESSAGE_PASSWORD_LENGTH", @"Your new password must be at least 4 characters long. Please try again.")];
  } else {
    [fault showWithTitle:NSLocalizedString(@"ERROR_MESSAGE_GENERAL_ERROR", @"Unknown error")];
  }
}


@synthesize currentPassword = ch_currentPassword, passwordCell = ch_passwordCell, againCell = ch_againCell, progressHUD = ch_progressHUD;
@end

