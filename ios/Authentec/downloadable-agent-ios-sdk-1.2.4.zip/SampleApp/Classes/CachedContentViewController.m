//
//  CachedContentViewController.m
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "CachedContentViewController.h"


@interface CachedContentViewController(PrivateAPI)

- (void)updateStatus;
- (void)updateProgress;

@end


@implementation CachedContentViewController

- (void)dealloc
{
    NSLog(@"deallocating CachedContentViewController");
    
    // clean up KVO observers
    [cachedContent removeObserver:self forKeyPath:@"cachedDuration"];
    [cachedContent removeObserver:self forKeyPath:@"status"];
    [cachedContent removeObserver:self forKeyPath:@"isReadyToPlay"];
    
    [cachedContent release];
    [contentURL release]; 
    
    [contentURLLabel release];
    [statusLabel release];
    [cachedDurationLabel release];
    [progressview release];
	[startCachingButton release];
	[stopCachingButton release];
    [purgeCacheButton release];
    
    [super dealloc];
}

- (IBAction)startCaching:(id)sender
{
    [cachedContent startCaching];
}

- (IBAction)stopCaching:(id)sender
{
    [cachedContent pauseCaching];
}

- (IBAction)purgeCache:(id)sender
{
    [cachedContent purgeCache];
}

- (id)initWithContentURL:(NSURL *)theContentURL ofType:(DAContentType)theContentType
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) 
    {
        self = [super initWithNibName:@"CachedContentView" bundle:nil];
    } 
    else
    {
        self = [super initWithNibName:@"CachedContentView-iPad" bundle:nil];
    }
    
    if (self)
    {
        contentURL = [theContentURL retain];
        contentType = theContentType;
        
        NSLog(@"CachedContentViewController initialized with content URL %@ of type %i", contentURL, contentType);

        // obtain an instance of the DACachedContent class for this URL and type
        cachedContent = [[DACachedContent cachedContentWithURL:contentURL ofType:contentType] retain];
        
        // set ourselves as observes to track the status of the cache
        [cachedContent addObserver:self forKeyPath:@"cachedDuration" options:(NSKeyValueObservingOptionNew) context:nil];        
        [cachedContent addObserver:self forKeyPath:@"status" options:(NSKeyValueObservingOptionNew) context:nil];
        [cachedContent addObserver:self forKeyPath:@"isReadyToPlay" options:(NSKeyValueObservingOptionNew) context:nil];
    }
    
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

/*
 KVO observer that monitors the status of the cached content
 */
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString:@"cachedDuration"])
    {
        [self performSelectorOnMainThread:@selector(updateProgress) withObject:nil waitUntilDone:NO];
    }
    else if ([keyPath isEqualToString:@"status"])
    {
        [self performSelectorOnMainThread:@selector(updateStatus) withObject:nil waitUntilDone:NO];
    }
    else if ([keyPath isEqualToString:@"isReadyToPlay"])
    {
        if (cachedContent.isReadyToPlay)
        {
            NSLog(@"The content is now ready to play");
            [self performSelectorOnMainThread:@selector(updateStatus) withObject:nil waitUntilDone:NO];
        }
    }
    else
    {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
}

/*
 Updates the UIProgressView to reflect the current percentage of the file thas has been cached to disk
 */
- (void)updateProgress
{
    // calculate the current caching progress as a float value between 0.0 and 1.0
    float progress = cachedContent.cachedDuration / cachedContent.totalDuration;
    
    if ([progressview respondsToSelector:@selector(setProgress:animated:)])
    {
        // iOS 5.0 and later only
        [progressview setProgress:progress animated:YES];        
    }
    else
    {
        progressview.progress = progress;
    }
    
    // update the cached duration label
    if (cachedContent.isReadyToPlay)
    {
        cachedDurationLabel.text = [NSString stringWithFormat:@"[%i secs can be played offline]", (int)cachedContent.cachedDuration];
    }
    else
    {
        cachedDurationLabel.text = @"[Not available for offline playback]";
    }
}

- (void)updateStatus
{
    // update the status label
    switch (cachedContent.status)
    {
        case DACachingStatusInProgress:
            statusLabel.text = @"Status: caching in progress...";
            break;
            
        case DACachingStatusPaused:
            statusLabel.text = @"Status: paused";
            break;
            
        case DACachingStatusFailed:
            statusLabel.text = @"Status: failed!";
            break;
            
        case DACachingStatusCompleted:
            statusLabel.text = @"Status: completed";
            break;        
        
        case DACachingStatusNotCached:
            statusLabel.text = @"Status: not cached";
            break; 
    }
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // show the URL
    contentURLLabel.text = [contentURL absoluteString];
    
    // initial update of the status and the progress
    [self performSelectorOnMainThread:@selector(updateStatus) withObject:nil waitUntilDone:NO];
    [self performSelectorOnMainThread:@selector(updateProgress) withObject:nil waitUntilDone:NO];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // support only portrait orientation
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
