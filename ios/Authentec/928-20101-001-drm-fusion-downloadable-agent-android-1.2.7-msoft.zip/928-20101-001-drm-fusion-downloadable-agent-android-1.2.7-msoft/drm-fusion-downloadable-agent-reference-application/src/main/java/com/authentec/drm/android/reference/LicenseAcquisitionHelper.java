package com.authentec.drm.android.reference;

import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

import android.content.*;
import android.util.Log;
import com.authentec.drmagent.v2.*;
import com.authentec.drmagent.v2.utils.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

/** This class performs some simple rewrites of license acquisition URLs specifically targeting the AuthenTec
 * license server. It also provides helper methods for retrieving web initiators.
 *
 * @author AuthenTec Inc
 */
public class LicenseAcquisitionHelper
{
    public static final String TAG = "LicenseAcquisitionHelper";
    public static String LA_URL_TEMPLATE = "http://drmproducts-eu.authentec.com/test-portal/device/triggerGenerator.form?contentDistributorID=eval&rightsIssuerID=PR&dotwopass=true&technologyType=MS-DRM-PLAYREADY&cid=%s&device=anonymous&acknowledgeLicenseInstall=%b";

    public static boolean canDoWebInitiator(final Context context, final DRMContentInfo drmContentInfo)
    {
        final String laURL = drmContentInfo.mDRMContent.getMetaData(DRMMetaData.RI_URL_SILENT);
        Log.d(TAG, "Validating URL: " + laURL);
        final boolean b = laURL.startsWith("http://drmproducts-eu.authentec.com/test-portal/") || laURL.startsWith("http://drmproducts.authentec.com/safenet-test-portal/");
        Log.d(TAG, "Web Initiator: " + (b ? "supported" : "not supported"));
        return b;
    }

    public static boolean retrieveAndInstallWebInitiator(final Context context, final DRMContentInfo drmContentInfo)
    {
        final DRMAgent drmAgentInstance = DRMAgentDelegate.getDRMAgentInstance(context);


        try
        {
            final String keyID = Tools.toGUID(Base64.decode(drmContentInfo.mDRMContent.getMetaData(DRMMetaData.CONTENT_ID)));

            if (!LicenseAcquisitionHelper.canDoWebInitiator(context, drmContentInfo))
            {
                throw new RuntimeException("LA URL points to server other than http://drmproducts-eu.authentec.com/test-portal/... - this is currently not supported");
            }

            final SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
            final boolean forceLicenseAcknowledgement = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_ACKNOWLEDGEMENT_LICENSE_FOR_CONTENT, false);

            Log.d(TAG, "Retrieving web initiator");
            Log.d(TAG, "Force Acknowledgement: " + (forceLicenseAcknowledgement ? "Yes" : "No"));

            final String s = createRights(context);

            String rights = "&rights=" + s;

            URL url = new URL(String.format(LA_URL_TEMPLATE,keyID,forceLicenseAcknowledgement) + rights);

            final HttpClient client = new DefaultHttpClient();
            final HttpGet postMethod = new HttpGet(url.toString());

            Log.d(TAG, "Making request for web initiator: " + url);

            final HttpResponse execute = client.execute(postMethod);
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            Tools.copyStream(execute.getEntity().getContent(), outputStream);
            Log.d(TAG, "Data received: " + new String(outputStream.toByteArray()));

            drmAgentInstance.installEntitlement(DRMContentType.DRM_MIMETYPE_PR_INITIATOR_XML_STRING, new ByteArrayInputStream(outputStream.toByteArray()));
            Log.d(TAG, "Web initiator successfully installed");
            return true;
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return false;
        }


    }

    private static String createRights(final Context context)
    {
        final SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        final boolean forceTimeBasedLicense = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_TIMEBASED_LICENSE_FOR_CONTENT, false);
        final boolean forceOPLBasedLicense = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_OPL_LICENSE_FOR_CONTENT, false);
        int numMinutes = sharedPreferences.getInt(Constants.PREFERENCES_TIMEBASED_LICENSE_NUM_MINUTES,5);
        int oplLevel = sharedPreferences.getInt(Constants.PREFERENCES_OPL_LICENSE_LEVEL,100);

        Log.d(TAG, "Force time-based license: " + (forceTimeBasedLicense ? "Yes" : "No"));
        Log.d(TAG, "Force OPL license: " + (forceOPLBasedLicense ? "Yes" : "No"));
        Log.d(TAG, "Number of Minutes: " + numMinutes);
        Log.d(TAG, "OPL Level: " + oplLevel);


        String rawRights = "";
        if (forceTimeBasedLicense)
        {
            // This defines rights valid for numMinutes minutes - starting numMinutes minute in the past
            rawRights += "s=now+-" + (numMinutes * 60) + "|e=now+" + (numMinutes * 60);
        }

        if (forceOPLBasedLicense)
        {
            rawRights += (forceTimeBasedLicense ? "|" : "") + "opl=" + oplLevel;
        }

        return rawRights.equals("") ? "all" : Tools.toHex(rawRights);
    }

    public static URL performURLRewrite(final Context context, final URL la1URL, final DRMContentInfo drmContentInfo)
    {

        final SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        final boolean forceLicenseAcknowledgement = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_ACKNOWLEDGEMENT_LICENSE_FOR_CONTENT, false);

        Log.d(TAG, "License Acquisition URL: " + la1URL);
        Log.d(TAG, "Force Acknowledgement: " + (forceLicenseAcknowledgement ? "Yes" : "No"));

        URL actualLicenseAcquisitionURL = la1URL;
        final String laURLOverride = drmContentInfo.mLaURLOverride;
        if (laURLOverride != null)
        {
            try
            {

                actualLicenseAcquisitionURL = new URL(laURLOverride);
            }
            catch (MalformedURLException e)
            {
                Log.e(TAG, "Error while parsing url: " + laURLOverride);
                throw new RuntimeException("Error while attempting to use LA URL override: " + laURLOverride);
            }
        }

        // Extract the CID from the URL
        // NOTE: This is present in the code to handle license acquisition based on the
        // NOTE: AuthenTec's TTS license server.
        // NOTE: The logic here would not apply to other, custom, license servers
        if (actualLicenseAcquisitionURL.toString().contains("?b="))
        {
            Log.d(TAG, "Detected the TTS license server, will reconstruct the LA_URL accordingly");
            try
            {
                String cid = null;

                String encodedString = actualLicenseAcquisitionURL.toString().split("=")[1];
                String hexString = new String(Tools.toByte(encodedString));
                final String[] segments = hexString.split("\\|\\|");
                for (String segment : segments)
                {
                    Log.d(TAG, "Segment: " + segment);
                    if (segment.startsWith("cid"))
                    {
                        cid = segment.split("=")[1];
                        break;
                    }
                }
                if (cid != null)
                {

                    String rights = createRights(context);

                    String parameters = "m=PRDynamicSilentLicenseDelivery||";
                    if (forceLicenseAcknowledgement)
                    {
                        parameters = parameters + "acknowledgeLicenseInstall=true||";
                    }
                    parameters = parameters + "acid=eval||rights=" + rights + "||cid=" + cid;

                    hexString = Tools.toHex(parameters);
                    final URL newLaURL = new URL("http://drmproducts-eu.authentec.com/test-portal/device/portal?b=" + hexString);
                    Log.d(TAG, "New URL: " + newLaURL);
                    return newLaURL;
                }

            }
            catch (Exception e)
            {
                Log.e(TAG, "Error while constructing URL based on: " + actualLicenseAcquisitionURL);
                throw new RuntimeException("Error while constructing URL from: " + actualLicenseAcquisitionURL);
            }
        }
        Log.d(TAG,"Returning unmodified LA URL: " + actualLicenseAcquisitionURL);
        return actualLicenseAcquisitionURL;
    }

}
