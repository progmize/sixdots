//
// CHUpdateTempPasswordViewController.h
// Chicago
//
// Created by Brian Cooke on 8/24/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"

@class TKLabelTextFieldCell;
@class MBProgressHUD;

@interface CHUpdateTempPasswordViewController : UITableViewController<CDClientDelegate> {
	NSString             *ch_currentPassword;
	TKLabelTextFieldCell *ch_passwordCell;
	TKLabelTextFieldCell *ch_againCell;
	MBProgressHUD        *ch_progressHUD;
}

@property (nonatomic, strong) NSString             *currentPassword;
@property (nonatomic, strong) TKLabelTextFieldCell *passwordCell;
@property (nonatomic, strong) TKLabelTextFieldCell *againCell;
@property (nonatomic, strong) MBProgressHUD        *progressHUD;

- (id)initWithCurrentPassword:(NSString *)theCurrentPassword;
- (IBAction)save:(id)sender;

@end
