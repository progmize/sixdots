//
//  URLFactory.h
//  Chicago
//
//  Created by louie on 12/6/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//



@interface URLFactory : NSObject {

}

// This ensures that any characters like spaces are properly escaped.
+ (NSURL *)escapedURLWithString:(NSString *)urlString;

@end
