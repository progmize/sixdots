#
# Version: 1.0.5
# 
# This script completes the protection step for your application. The finalizer 
# utility is executed on the binary file output by the linker, i.e. the executable of 
# the application.
#
# Please consult the documentation for more details about this process.
#
# Copyright (c) 2012 AuthenTec Inc. All rights reserved.
#

### PROPERTIES THAT REQUIRE CUSTOMIZATION ##########################################

# Note: you may use the Xcode environment variable '$PROJECT_DIR' to refer to your
# project's root folder.

# The absolute path to the folder containing the finalizer utility ('finalizer') and 
# the dynamic library it depends on (libelf.dylib)
FINALIZER_PATH=$PROJECT_DIR/DownloadableAgentLib/finalization-tools

# The absolute path to the finalization files (.fin) included with the library
FINALIZATION_FILE_1=$PROJECT_DIR/DownloadableAgentLib/finalize1.fin
FINALIZATION_FILE_2=$PROJECT_DIR/DownloadableAgentLib/finalize2.fin

####################################################################################

### No need to edit anything from here on ###

# Set up target files names
ORIGINAL_EXECUTABLE=$BUILT_PRODUCTS_DIR/$EXECUTABLE_PATH
LINK_MAP=$LD_MAP_FILE_PATH

echo "--- Parameters ----------------------------------------------------"
echo "Target name: $TARGET_NAME"
echo "Configuration mode: $CONFIGURATION"
echo "Finalizer path: FINALIZER_PATH"
echo "Finalization file 1: $FINALIZATION_FILE_1"
echo "Finalization file 2: $FINALIZATION_FILE_2"
echo "Original executable: $ORIGINAL_EXECUTABLE"
echo "Link Map file: $LINK_MAP"
echo "-------------------------------------------------------------------"

# export the necessary environment vars
export PATH=$FINALIZER_PATH:$PATH
export DYLD_LIBRARY_PATH=$FINALIZER_PATH:$DYLD_LIBRARY_PATH

### Run some checks before proceeding

if [ "$PLATFORM_NAME" == "iphonesimulator" ]; then
	echo "[ERROR] The simulator platform does is not supported by the protected library"
	exit 1
fi

if [ ! "$ARCHS" == "armv7" ]; then
	echo "[ERROR] Universal binary mode is not supported - Please change the build settings for this target from 'Standard (armv6 armv7)' to 'Optimized (armv7)'"
	exit 1
fi


# check that all required files exist

if [ ! -f "$FINALIZER_PATH/finalizer" ]; then
    echo "[ERROR] Did not find '$FINALIZER_PATH/finalizer'"
    echo " *** Make sure you have set the correct path to folder containing the finalizer tool and the .dylib at the top of the script"
    exit 1
fi

if [ ! -f "$FINALIZER_PATH/libelf.dylib" ]; then
    echo "[ERROR] Did not find '$FINALIZER_PATH/libelf.dylib'"
    echo " *** Make sure you have set the correct path to folder containing the finalizer tool and the .dylib at the top of the script"
    exit 1
fi

if [ ! -f "$FINALIZATION_FILE_1" ]; then
    echo "[ERROR] Did not find '$FINALIZATION_FILE_1'"
    echo " *** Make sure you have set the correct path to the file 'finalize1.fin' at the top of the script"
    exit 1
fi

if [ ! -f "$FINALIZATION_FILE_2" ]; then
    echo "[ERROR] Did not find '$FINALIZATION_FILE_2'"
    echo " *** Make sure you have set the correct path to the file 'finalize2.fin' at the top of the script"
    exit 1
fi

if [ ! -f "$LINK_MAP" ]; then
    echo "[ERROR] Did not find '$LINK_MAP'"
    echo " *** Make sure the 'Write Link Map File' option is enabled in the build settings of the target $TARGET_NAME"
    exit 1
fi

if [ ! -f "$ORIGINAL_EXECUTABLE" ]; then
    echo "[ERROR] Did not find '$ORIGINAL_EXECUTABLE'"
    exit 1
fi

### Prepare to execute the finalization tool

chmod +x $FINALIZER_PATH/finalizer

echo "[*] Running the finalizer..."

finalizer -quiet "$ORIGINAL_EXECUTABLE" "$LINK_MAP" "$FINALIZATION_FILE_1" "$FINALIZATION_FILE_2"

if [ ! $? -eq 0 ]
then
	echo "[ERROR] The finalizer tool failed - Please clean the target and try building again"
	exit 1
fi

echo "[*] The executable has been successfully finalized"

### replace the original binary with the finalized one

# Replace it with the finalized executable
if ! mv "${ORIGINAL_EXECUTABLE}.finalized" "$ORIGINAL_EXECUTABLE" 
then
  echo "[ERROR] Failed to copy finalized executable over the original one"
  exit 1    
fi

# make sure the executable has the right permissions
chmod +x "$ORIGINAL_EXECUTABLE"

echo "[*] Finalization completed!"

