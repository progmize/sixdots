//
//  ContentDirectAPI_ipadsimulator.m
//  ContentDirectAPI-ipadsimulator
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContentDirectAPI_ipadsimulator.h"

@implementation ContentDirectAPI_ipadsimulator

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
