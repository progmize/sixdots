var interface_downloadable_agent =
[
    [ "initWithContentURL:type:", "interface_downloadable_agent.html#acc0bea7855cb74bf3986e8b242a6fb6a", null ],
    [ "moviePlayerViewController", "interface_downloadable_agent.html#abd34075f0ed489469a0f1033b6a99ab8", null ],
    [ "moviePlayerController", "interface_downloadable_agent.html#af97ac2958999196031312b46f89c30e8", null ],
    [ "avPlayerItem", "interface_downloadable_agent.html#a9be5f21f5b9affe6c7fdb747e7de0c10", null ],
    [ "contentInfo:error:", "interface_downloadable_agent.html#a255e7a9d35dda976d6ce295c7d72954c", null ],
    [ "acquireLicenseWithDelegate:error:", "interface_downloadable_agent.html#aeb26dae002b53bf9d25afb0b4fe575c0", null ],
    [ "installLicense:", "interface_downloadable_agent.html#ad3673fc82b39ef2d6f21b7e1d95b4c55", null ],
    [ "removeLicense", "interface_downloadable_agent.html#a6031434101ba2fe4e960da31e44d51b3", null ],
    [ "importDeviceModelCertificate:forModelCertificate:", "interface_downloadable_agent.html#a2e45d814df45f0905b403503b79386c9", null ],
    [ "importDeviceModelPrivateKey:forModelCertificate:", "interface_downloadable_agent.html#a4d55f1af4f973a8371cb841933e7a5ea", null ],
    [ "generatePlayReadyChallengeForDRMHeader:", "interface_downloadable_agent.html#a5c6423acd3e4e51531f053b9ddc25c4e", null ],
    [ "resetDRMDatabase", "interface_downloadable_agent.html#a51c16c19cc04cf31f730d6d88b4280af", null ],
    [ "isSecureDevice", "interface_downloadable_agent.html#aa39bf119d137da37379efafad8588902", null ],
    [ "getPlayReadyDeviceID", "interface_downloadable_agent.html#ae6bfc79e75685ce8e4816c3677850b7b", null ],
    [ "contentURL", "interface_downloadable_agent.html#abb88f272fdb4199985c436eb3d66827d", null ],
    [ "contentType", "interface_downloadable_agent.html#afd0b53c8c5fc1ba69a050509943bab87", null ],
    [ "lastError", "interface_downloadable_agent.html#aacfd272218bf6795a02452d9612d17d8", null ],
    [ "customLicenseChallengeData", "interface_downloadable_agent.html#af68132d7984e881e8804830fbfe6d2a9", null ],
    [ "hdmiMode", "interface_downloadable_agent.html#a34d8fa528489a2ba5da638c6437d331b", null ],
    [ "hdmiAlternativeImage", "interface_downloadable_agent.html#a54c5be10514c5235e76e3716d521b148", null ],
    [ "selectedAudioTrackName", "interface_downloadable_agent.html#ac5301d7283a45a15ec825d39ee195acf", null ]
];