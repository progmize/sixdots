//
//  main.m
//  CDLocker
//
//  Created by Kelly Lein on 2/6/12.
//  Copyright (c) 2012 Content Direct. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CDLockerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CDLockerAppDelegate class]));
        //return UIApplicationMain(argc, argv, nil, nil);
    }
}
