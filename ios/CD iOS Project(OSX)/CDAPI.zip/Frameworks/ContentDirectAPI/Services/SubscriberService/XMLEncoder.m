//
//  XMLEncoder.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/28/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "XMLEncoder.h"


@implementation XMLEncoder

@synthesize prettyPrint;

- (void)indentXML:(NSMutableString *)xml toLevel:(int)level {
  if (prettyPrint) {
    for (int i = 0; i < level; i++) {
      [xml appendString:@"  "];      
    }
  }
}

- (void)addNewline:(NSMutableString *)xml {
  if (prettyPrint) {
    [xml appendString:@"\n"];
  }
}

- (BOOL)isKeyInProductNamespace:(NSString *)key {
  return [key isEqual:@"CategoryId"];
}

- (BOOL)keyHasEmbeddedNamespace:(NSString *)key {
  return [key rangeOfString:@"|"].location != NSNotFound;
}

- (NSString *)embeddedNamespaceForKey:(NSString *)key {
  NSArray *namespaceAndKeyArray = [key componentsSeparatedByString:@"|"];
  return [namespaceAndKeyArray objectAtIndex:0];
  
}

- (NSString *)embeddedKeyForKey:(NSString *)key {
  NSArray *namespaceAndKeyArray = [key componentsSeparatedByString:@"|"];
  return [namespaceAndKeyArray objectAtIndex:1];
}
  

- (BOOL)isKeyInOrderNamespace:(NSString *)key {
  return [key isEqual:@"ProductId"] ||
         [key isEqual:@"Items"] ||
         [key isEqual:@"IncludeProductSummaries"] ||
         [key isEqual:@"IncludeSubscriptionProducts"];
}

- (NSString *)xmlFromDictionary:(NSDictionary *)dictionary level:(int)level {
  NSMutableString *xml = [[NSMutableString alloc] init];
  
  for (NSString *key in [dictionary allKeys]) {
    id value = [dictionary objectForKey:key];
    if ([value isKindOfClass:[NSDictionary class]]) {
      // Need to get xml from this nested dictionary
      NSString *nestedXML = [self xmlFromDictionary:value level:(level + 1)];
      [self indentXML:xml toLevel:level];
      
      // Special case for top level: add namespace attributes.
      if (level == 0) {
        NSString *namespaceAttributes = @"xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://ContentDirect.SubscriberManagement\"";
        [xml appendFormat:@"<%@ %@>", key, namespaceAttributes];
      } else {
        if ([self keyHasEmbeddedNamespace:key]) {
          NSString *embeddedNamespace = [self embeddedNamespaceForKey:key];
          NSString *embeddedKey = [self embeddedKeyForKey:key];
          NSString *namespace = [NSString stringWithFormat:@"xmlns=\"%@\"", embeddedNamespace];
          [xml appendFormat:@"<%@ %@>", embeddedKey, namespace];                                  
        } else {
          if ([self isKeyInProductNamespace:key]) {
            NSString *namespace = @"xmlns=\"http://ContentDirect.ProductManagement\"";
            [xml appendFormat:@"<%@ %@>", key, namespace];                        
          } else if ([self isKeyInOrderNamespace:key]) {
            NSString *namespace = @"xmlns=\"http://ContentDirect.OrderManagement\"";
            [xml appendFormat:@"<%@ %@>", key, namespace];  
          } else if ([key isEqual:@"SearchParameters"]) {
            NSString *xsitype = @"xmlns=\"http://ContentDirect.ProductManagement\" xsi:type=\"StandardProductSearchParameters\"";
            [xml appendFormat:@"<%@ %@>", key, xsitype];
          } else {
            [xml appendFormat:@"<%@>", key];                        
          }          
        }
      }
      [self addNewline:xml];

      [xml appendFormat:@"%@", nestedXML];      

      [self indentXML:xml toLevel:level];

      if ([self keyHasEmbeddedNamespace:key]) {
        NSString *embeddedKey = [self embeddedKeyForKey:key];
        [xml appendFormat:@"</%@>", embeddedKey];                                  
      } else {
        [xml appendFormat:@"</%@>", key];        
      }
    } else if ([value isKindOfClass:[NSArray class]]) {
      // TODO improve the indentation
      
      if ([self keyHasEmbeddedNamespace:key]) {
        NSString *embeddedNamespace = [self embeddedNamespaceForKey:key];
        NSString *embeddedKey = [self embeddedKeyForKey:key];
        NSString *namespace = [NSString stringWithFormat:@"xmlns=\"%@\"", embeddedNamespace];
        [xml appendFormat:@"<%@ %@>", embeddedKey, namespace];                                  
      } else {
        if ([self isKeyInProductNamespace:key]) {
          NSString *namespace = @"xmlns=\"http://ContentDirect.ProductManagement\"";
          [xml appendFormat:@"<%@ %@>", key, namespace];                        
        } else if ([self isKeyInOrderNamespace:key]) {
          NSString *namespace = @"xmlns=\"http://ContentDirect.OrderManagement\"";
          [xml appendFormat:@"<%@ %@>", key, namespace];  
        } else if ([key isEqual:@"SearchParameters"]) {
          NSString *xsitype = @"xmlns=\"http://ContentDirect.ProductManagement\" xsi:type=\"StandardProductSearchParameters\"";
          [xml appendFormat:@"<%@ %@>", key, xsitype];
        } else {
          [xml appendFormat:@"<%@>", key];                        
        }          
      }
      
      // Need to get xml from this nested dictionary
      // Key is key without the "s" at the end.
      NSString *embeddedKey = [self embeddedKeyForKey:key];
      NSString *nestedKey = [embeddedKey stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"s"]];
      NSArray *valueArray = (NSArray *)value;
      for (NSString *valueString in valueArray) {
        [xml appendFormat:@"<%@>%@</%@>", nestedKey, valueString, nestedKey];
      }

      if ([self keyHasEmbeddedNamespace:key]) {
        NSString *embeddedKey = [self embeddedKeyForKey:key];
        [xml appendFormat:@"</%@>", embeddedKey];                                  
      } else {
        [xml appendFormat:@"</%@>", key];        
      }      
    } else {
      [self indentXML:xml toLevel:level];      
      if ([self keyHasEmbeddedNamespace:key]) {
        NSString *embeddedNamespace = [self embeddedNamespaceForKey:key];
        NSString *embeddedKey = [self embeddedKeyForKey:key];
        NSString *namespace = [NSString stringWithFormat:@"xmlns=\"%@\"", embeddedNamespace];
        [xml appendFormat:@"<%@ %@>%@</%@>", embeddedKey, namespace, [value description], embeddedKey];      
      } else {        
        if ([self isKeyInProductNamespace:key]) {
          NSString *namespace = @"xmlns=\"http://ContentDirect.ProductManagement\"";
          [xml appendFormat:@"<%@ %@>%@</%@>", key, namespace, [value description], key];      
        } else if ([self isKeyInOrderNamespace:key]) {
          NSString *namespace = @"xmlns=\"http://ContentDirect.OrderManagement\"";
          [xml appendFormat:@"<%@ %@>%@</%@>", key, namespace, [value description], key];      
        } else {
          NSString *valueString = [value description];
          if ([valueString length] == 0) {
            [xml appendFormat:@"<%@/>", key];                    
          } else {
            [xml appendFormat:@"<%@>%@</%@>", key, valueString, key];          
          }
        }
      }
    }
    
    [self addNewline:xml];
  }
  
  return xml;
}

- (NSString *)xmlFromDictionary:(NSDictionary *)dictionary {
  return [self xmlFromDictionary:dictionary level:0];
}

@end
