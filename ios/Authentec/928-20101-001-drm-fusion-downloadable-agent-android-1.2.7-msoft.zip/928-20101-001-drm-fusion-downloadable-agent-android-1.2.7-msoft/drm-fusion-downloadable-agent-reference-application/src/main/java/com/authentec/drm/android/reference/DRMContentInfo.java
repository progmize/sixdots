package com.authentec.drm.android.reference;

import java.io.Serializable;
import java.net.URI;

import com.authentec.drmagent.v2.*;

/**
 * @author AuthenTec Inc.
 */
public class DRMContentInfo implements Serializable, Comparable<DRMContentInfo>
{
    public DRMContent mDRMContent;
    public String mContentDescriptorLocation;
    public URI mContentLocation;
    public String mTitle;
    public String mLaURLOverride;

    public boolean mStreamLive;
    public String mAuthor;
    public String mGenres;
    public String mLanguage;
    public String mShortDescription;
    public String mLongDescription;
    public String mContainer;
    public String mAudioCodec;
    public String mAudioChannels;
    public String mVideoCodec;
    public String mWidth;
    public String mHeight;
    public String mBitDepth;
    public String mBitRate;
    public String mFramerate;
    public String mRuntime;
    public String mPicture;
    public String mThumbnail;
    public String mLocalFileServerPath;
    public String mContentFormatFromCdesc;

    @Override
    public boolean equals(final Object o)
    {
        if (this == o)
        {
            return true;
        }
        if (!(o instanceof DRMContentInfo))
        {
            return false;
        }

        final DRMContentInfo that = (DRMContentInfo) o;

        if (mStreamLive != that.mStreamLive)
        {
            return false;
        }
        if (mAudioChannels != null ? !mAudioChannels.equals(that.mAudioChannels) : that.mAudioChannels != null)
        {
            return false;
        }
        if (mAudioCodec != null ? !mAudioCodec.equals(that.mAudioCodec) : that.mAudioCodec != null)
        {
            return false;
        }
        if (mAuthor != null ? !mAuthor.equals(that.mAuthor) : that.mAuthor != null)
        {
            return false;
        }
        if (mBitDepth != null ? !mBitDepth.equals(that.mBitDepth) : that.mBitDepth != null)
        {
            return false;
        }
        if (mBitRate != null ? !mBitRate.equals(that.mBitRate) : that.mBitRate != null)
        {
            return false;
        }
        if (mContainer != null ? !mContainer.equals(that.mContainer) : that.mContainer != null)
        {
            return false;
        }
        if (mContentDescriptorLocation != null ? !mContentDescriptorLocation.equals(that.mContentDescriptorLocation) : that.mContentDescriptorLocation != null)
        {
            return false;
        }
        if (mContentLocation != null ? !mContentLocation.equals(that.mContentLocation) : that.mContentLocation != null)
        {
            return false;
        }
        if (mDRMContent != null ? !mDRMContent.equals(that.mDRMContent) : that.mDRMContent != null)
        {
            return false;
        }
        if (mFramerate != null ? !mFramerate.equals(that.mFramerate) : that.mFramerate != null)
        {
            return false;
        }
        if (mGenres != null ? !mGenres.equals(that.mGenres) : that.mGenres != null)
        {
            return false;
        }
        if (mHeight != null ? !mHeight.equals(that.mHeight) : that.mHeight != null)
        {
            return false;
        }
        if (mLaURLOverride != null ? !mLaURLOverride.equals(that.mLaURLOverride) : that.mLaURLOverride != null)
        {
            return false;
        }
        if (mLanguage != null ? !mLanguage.equals(that.mLanguage) : that.mLanguage != null)
        {
            return false;
        }
        if (mLocalFileServerPath != null ? !mLocalFileServerPath.equals(that.mLocalFileServerPath) : that.mLocalFileServerPath != null)
        {
            return false;
        }
        if (mContentFormatFromCdesc != null ? !mContentFormatFromCdesc.equals(that.mContentFormatFromCdesc) : that.mContentFormatFromCdesc != null)
        {
            return false;
        }
        if (mLongDescription != null ? !mLongDescription.equals(that.mLongDescription) : that.mLongDescription != null)
        {
            return false;
        }
        if (mPicture != null ? !mPicture.equals(that.mPicture) : that.mPicture != null)
        {
            return false;
        }
        if (mRuntime != null ? !mRuntime.equals(that.mRuntime) : that.mRuntime != null)
        {
            return false;
        }
        if (mShortDescription != null ? !mShortDescription.equals(that.mShortDescription) : that.mShortDescription != null)
        {
            return false;
        }
        if (mThumbnail != null ? !mThumbnail.equals(that.mThumbnail) : that.mThumbnail != null)
        {
            return false;
        }
        if (mTitle != null ? !mTitle.equals(that.mTitle) : that.mTitle != null)
        {
            return false;
        }
        if (mVideoCodec != null ? !mVideoCodec.equals(that.mVideoCodec) : that.mVideoCodec != null)
        {
            return false;
        }
        if (mWidth != null ? !mWidth.equals(that.mWidth) : that.mWidth != null)
        {
            return false;
        }

        return true;
    }

    @Override
    public String toString()
    {
        return "DRMContentInfo{" +
                "mAudioChannels='" + mAudioChannels + '\'' +
                ", mDRMContent=" + mDRMContent +
                ", mContentDescriptorLocation='" + mContentDescriptorLocation + '\'' +
                ", mContentLocation=" + mContentLocation +
                ", mTitle='" + mTitle + '\'' +
                ", mLaURLOverride='" + mLaURLOverride + '\'' +
                ", mStreamLive='" + mStreamLive + '\'' +
                ", mContentFormatFromCdesc='" + mContentFormatFromCdesc + '\'' +
                ", mAuthor='" + mAuthor + '\'' +
                ", mGenres='" + mGenres + '\'' +
                ", mLanguage='" + mLanguage + '\'' +
                ", mShortDescription='" + mShortDescription + '\'' +
                ", mLongDescription='" + mLongDescription + '\'' +
                ", mContainer='" + mContainer + '\'' +
                ", mAudioCodec='" + mAudioCodec + '\'' +
                ", mVideoCodec='" + mVideoCodec + '\'' +
                ", mWidth='" + mWidth + '\'' +
                ", mHeight='" + mHeight + '\'' +
                ", mBitDepth='" + mBitDepth + '\'' +
                ", mBitRate='" + mBitRate + '\'' +
                ", mFramerate='" + mFramerate + '\'' +
                ", mRuntime='" + mRuntime + '\'' +
                ", mPicture='" + mPicture + '\'' +
                ", mThumbnail='" + mThumbnail + '\'' +
                ", mLocalFileServerPath='" + mLocalFileServerPath + '\'' +
                '}';
    }

    public int compareTo(final DRMContentInfo drmContentInfo)
    {
        return mTitle.compareTo(drmContentInfo.mTitle);
    }

    public DRMScheme getDRMScheme()
    {
        return mDRMContent.getDRMScheme();
    }


    public String getDRMContentFormatFromCdesc()
    {
        return mContentFormatFromCdesc;
    }

    public DRMContentFormat getDRMContentFormat()
    {
        return mDRMContent.getDRMContentFormat();
    }
}
