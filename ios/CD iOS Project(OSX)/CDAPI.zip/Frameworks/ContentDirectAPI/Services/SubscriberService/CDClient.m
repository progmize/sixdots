//
// CDClient.m
// ContentDirect POX API
//
// Created by Luis de la Rosa on 7/28/10.
// Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "CDClient.h"
#import "XPathQuery.h"
#import "OrderedDictionary.h"
#import "ProductCategory.h"
#import "Product.h"
#import "POXClient.h"
#import "Code.h"

@interface CDClient (Private)
- (NSString *)udid;
- (Product *)productFromDictionary:(NSDictionary *)productDictionary;
@end


@implementation CDClient

@synthesize delegate;
@synthesize sessionID;
@synthesize deviceType;
@synthesize distributionChannel;
@synthesize systemID;
@synthesize sessionAuthenticationType;
@synthesize subscriberID;
@synthesize loginName;
@synthesize deviceID;
@synthesize deviceAuthenticationKey;
@synthesize physicalDeviceTypeCode;
@synthesize paymentInstrumentBeingRemoved;
@synthesize storefrontURLString;
@synthesize language;
@synthesize enableInAppPurchase;
@synthesize playlistGUID;

#pragma mark -

- (id)initWithDeviceType:(NSString *)aDeviceType 
	 distributionChannel:(NSString *)aDistributionChannel 
				systemID:(NSString *)aSystemID 
	 storefrontURLString:(NSString *)aURLString 
  physicalDeviceTypeCode:(NSString *)aPhysicalDeviceTypeCode
				language:(NSString *)aLanguage
			playlistGUID:(NSString *)aPlaylistGUID
	 enableInAppPurchase:(BOOL)aInAppPurchase{
    self = [super init];
    
    if (self != nil) {
        poxClient                = [[POXClient alloc] init];
        self.deviceType          = aDeviceType;
        self.distributionChannel = aDistributionChannel;
        self.systemID            = aSystemID;
        self.storefrontURLString = aURLString;
		self.physicalDeviceTypeCode = aPhysicalDeviceTypeCode;
		self.enableInAppPurchase = aInAppPurchase;
        self.language = aLanguage;
        self.playlistGUID		 = aPlaylistGUID;
		
        // Load saved device info
		
		//NSLog(@"Login name: %@", [[CHSettings sharedCHSettings] loginName]);
		
        self.deviceID = [[CDSettings sharedCDSettings] deviceIDForLogin:[CDSettings sharedCDSettings].loginName];
        self.deviceAuthenticationKey = [CDSettings sharedCDSettings].deviceAuthenticationKey;
        
        paymentInstruments = [[NSMutableArray alloc] init];
    }
    
    return self;
}


- (void)retrieveCategoriesByParentCategoryID:(NSString *)parentCategoryID {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrieveProductCategories";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrieveProductCategories", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    // TESTING_NOTE: Commenting out SessionId will induce failure.
    if (self.sessionID != nil) {
        [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    }
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrieveProductCategoriesRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveProductsByCategoryID:(NSString *)categoryID limit:(int)maximumNumberOfProductsToReturn {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrieveProductsByCategory";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrieveProductsByCategory", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:categoryID forKey:@"CategoryId"];
    [requestDictionary setObject:[NSString stringWithFormat:@"%d", maximumNumberOfProductsToReturn] forKey:@"MaximumProductsReturned"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    if (self.sessionID != nil) {
        [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    }
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrieveProductsByCategoryRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveProductsByCategoryID:(NSString *)categoryID page:(int)page itemsPerPage:(int)itemsPerPage {
    NSString *urlString = [NSString stringWithFormat:@"%@/SearchProducts", self.storefrontURLString];
    
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"Everything" forKey:@"http://ContentDirect.ProductManagement|DataToReturn"];
    [requestDictionary setObject:[[NSNumber numberWithInteger:page] stringValue] forKey:@"http://ContentDirect.ProductManagement|PageNumber"];
    [requestDictionary setObject:[[NSNumber numberWithInteger:itemsPerPage] stringValue] forKey:@"http://ContentDirect.ProductManagement|PageSize"];
    
    OrderedDictionary *searchParamsDict = [[OrderedDictionary alloc] init];
    [searchParamsDict setObject:categoryID forKey:@"ProductCategoryId"];
    
    [requestDictionary setObject:searchParamsDict forKey:@"SearchParameters"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"SearchProductsRequest"];
    
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}

-(void)retrieveFeaturedProducts
{
	NSString *urlString = [NSString stringWithFormat:@"%@/RetrievePlayerFeaturedItems", self.storefrontURLString];
	
	//NSLog(@"%@", urlString);
	
	NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
	
	OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
	
	//[requestDictionary setObject:@"Everything" forKey:@"http://ContentDirect.ProductManagement|DataToReturn"];
	[requestDictionary setObject:[self playlistGUID] forKey:@"http://ContentDirect.ProductManagement|PlaylistGuid"];
	[requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
	[requestDictionary setObject:@"true" forKey:@"ReturnFault"];
	
	if([self subscriberID] != nil)
	{
		[requestDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.OrderManagement|SubscriberId"];
	}
	
	[requestDictionary setObject:self.sessionID forKey:@"SessionId"];
	
	OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrievePlayerFeaturedItemsRequest"];
	NSLog(@"Featured Items Request: %@", inputDictionary);
	
	[poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}

- (void)viewProductContent:(Product *)product {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/ViewProductContent";
    NSString *urlString = [NSString stringWithFormat:@"%@/ViewProductContent", self.storefrontURLString];
    //NSLog(@"CDClient -viewProductContent:");
    //NSLog(@"%@", urlString);
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];

	[requestDictionary setObject:product.pricingPlanID forKey:@"http://ContentDirect.OrderManagement|PricingPlanId"];
	
    [requestDictionary setObject:product.productID forKey:@"http://ContentDirect.OrderManagement|ProductId"];
	
    [requestDictionary setObject:@"ContentItem" forKey:@"http://ContentDirect.OrderManagement|ViewContentType"];
    
	
	[requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    if (self.sessionID != nil) {
        [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    }
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"ViewProductContentRequest"];
	NSLog(@"View Product Content request: %@", inputDictionary);
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)createSubscriberWithLogin:(NSString *)login email:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname password:(NSString *)password challengeQuestion:(NSString *)challengeQuestion challengeAnswer:(NSString *)challengeAnswer {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/CreateSubscriber";
    NSString *urlString = [NSString stringWithFormat:@"%@/CreateSubscriber", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *credentialsDictionary = [[OrderedDictionary alloc] init];
    [credentialsDictionary setObject:login forKey:@"Login"];
    [credentialsDictionary setObject:password forKey:@"Password"];
    [credentialsDictionary setObject:challengeQuestion forKey:@"PasswordChallenge"];
    [credentialsDictionary setObject:challengeAnswer forKey:@"PasswordChallengeResponse"];
    
    OrderedDictionary *subscriberDictionary = [[OrderedDictionary alloc] init];
    [subscriberDictionary setObject:email forKey:@"Email"];
    [subscriberDictionary setObject:fname forKey:@"FirstName"];
    [subscriberDictionary setObject:lname forKey:@"LastName"];
    [subscriberDictionary setObject:@"Active" forKey:@"Status"];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:credentialsDictionary forKey:@"Credentials"];
    [requestDictionary setObject:self.deviceType forKey:@"DeviceType"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:subscriberDictionary forKey:@"Subscriber"];
    [requestDictionary setObject:self.systemID forKey:@"SystemId"];
    
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"CreateSubscriberRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)updateSubscriberWithId:(NSString *)anID email:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/UpdateSubscriber";
    NSString *urlString = [NSString stringWithFormat:@"%@/UpdateSubscriber", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *subscriberDictionary = [[OrderedDictionary alloc] init];
    [subscriberDictionary setObject:email forKey:@"Email"];
    [subscriberDictionary setObject:fname forKey:@"FirstName"];
    [subscriberDictionary setObject:anID forKey:@"Id"];
    [subscriberDictionary setObject:self.language forKey:@"Language"];
    [subscriberDictionary setObject:lname forKey:@"LastName"];
    [subscriberDictionary setObject:@"Active" forKey:@"Status"];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:subscriberDictionary forKey:@"Subscriber"];
    
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"UpdateSubscriberRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)loginWithLogin:(NSString *)login password:(NSString *)password {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/Login";
    NSString *urlString = [NSString stringWithFormat:@"%@/Login", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:self.deviceType forKey:@"DeviceType"];
    [requestDictionary setObject:self.distributionChannel forKey:@"DistributionChannel"];
    [requestDictionary setObject:login forKey:@"Login"];
    [requestDictionary setObject:password forKey:@"Password"];
    [requestDictionary setObject:self.language forKey:@"Language"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.systemID forKey:@"SystemId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"LoginRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}

// Logout
-(void)requestToLogout
{
	// NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/LogoutRequest";
	NSString *urlString = [NSString stringWithFormat:@"%@/Logout", self.storefrontURLString];
	
	NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
	
	OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
	
	[requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
	[requestDictionary setObject:@"true" forKey:@"RetainSessionAsAnonymous"];
	[requestDictionary setObject:@"false" forKey:@"RetainSessionAsUnauthenticated"];
	[requestDictionary setObject:@"true" forKey:@"ReturnFault"];
	[requestDictionary setObject:self.sessionID forKey:@"SessionId"];
	
	OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"LogoutRequest"];
	//NSLog(@"Logout Request: %@", inputDictionary);
	
	[poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveEWalletForSubscriber {
    NSString *verb = @"RetrieveEWalletForSubscriber";
    // NSString * urlString   = [NSString stringWithFormat:@"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/%@", verb];
    NSString *urlString   = [NSString stringWithFormat:@"%@/%@", self.storefrontURLString, verb];
    NSURL    *urlEndpoint = [URLFactory escapedURLWithString:urlString];
        
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"IncludePaymentInstrumentDetails"];
    [requestDictionary setObject:@"true" forKey:@"IncludeRemoved"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    
    NSString          *requestName     = [NSString stringWithFormat:@"%@Request", verb];
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:requestName];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveSubscriberInfo {
    NSString *verb = @"RetrieveSubscriber";
    // NSString * urlString   = [NSString stringWithFormat:@"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/%@", verb];
    NSString *urlString   = [NSString stringWithFormat:@"%@/%@", self.storefrontURLString, verb];
    NSURL    *urlEndpoint = [URLFactory escapedURLWithString:urlString];
        
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    
    NSString          *requestName     = [NSString stringWithFormat:@"%@Request", verb];
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:requestName];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)calculateOrderQuoteForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument {
    NSString *verb = @"CalculateOrderQuote";
    // NSString * urlString   = [NSString stringWithFormat:@"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/%@", verb];
    NSString *urlString   = [NSString stringWithFormat:@"%@/%@", self.storefrontURLString, verb];
    NSURL    *urlEndpoint = [URLFactory escapedURLWithString:urlString];
        
    NSDictionary      *paymentInstrumentDictionary  = [paymentInstrument toDictionaryWithSubscriberID:self.subscriberID];
    OrderedDictionary *paymentInstrumentsDictionary = [[OrderedDictionary alloc] init];
    [paymentInstrumentsDictionary setObject:paymentInstrumentDictionary forKey:@"PaymentInstrument"];
    
    OrderedDictionary *shoppingCartItemDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartItemDictionary setObject:product.productID forKey:@"ProductId"];
    [shoppingCartItemDictionary setObject:product.pricingPlanID forKey:@"ProductPricingPlanId"];
    [shoppingCartItemDictionary setObject:@"1" forKey:@"Quantity"];
    
    OrderedDictionary *itemsDictionary = [[OrderedDictionary alloc] init];
    [itemsDictionary setObject:shoppingCartItemDictionary forKey:@"ShoppingCartItem"];
    
    OrderedDictionary *shoppingCartDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartDictionary setObject:@"USD" forKey:@"Currency"];
    [shoppingCartDictionary setObject:itemsDictionary forKey:@"Items"];
    
    [shoppingCartDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.OrderManagement|SubscriberId"];
    
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"CalculateTaxes"];
    [requestDictionary setObject:paymentInstrumentsDictionary forKey:@"PaymentInstruments"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:shoppingCartDictionary forKey:@"ShoppingCart"];
    
    NSString          *requestName     = [NSString stringWithFormat:@"%@Request", verb];
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:requestName];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)calculateOrderQuoteWithDefaultPaymentInstrumentForProduct:(Product *)product {
    PaymentInstrument *defaultPaymentInstrument = [paymentInstruments objectAtIndex:0];
    
    [self calculateOrderQuoteForProduct:product paymentInstrument:defaultPaymentInstrument];
}

- (void)submitOrderForProductWithItunes:(Product *)product receiptCode:(NSString *)receiptCode {
    NSString *verb = @"SubmitOrder";
    
    NSString *urlString   = [NSString stringWithFormat:@"%@/%@", self.storefrontURLString, verb];
    NSURL    *urlEndpoint = [URLFactory escapedURLWithString:urlString];
	
    OrderedDictionary *paymentInstrumentDictionary = [[OrderedDictionary alloc] init];

    [paymentInstrumentDictionary setObject:@"ITunesAccount" forKey:@"Nickname"];
    [paymentInstrumentDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    [paymentInstrumentDictionary setObject:@"ITunesAccount" forKey:@"Type"];
	
    OrderedDictionary *itunesDictionary = [[OrderedDictionary alloc] init];	
    [itunesDictionary setObject:receiptCode forKey:@"ITunesTransactionReceipt"];
	
	[paymentInstrumentDictionary setObject:itunesDictionary forKey:@"WorkaroundITunesAccount"];
	
    OrderedDictionary *paymentInstrumentsDictionary = [[OrderedDictionary alloc] init];
    [paymentInstrumentsDictionary setObject:paymentInstrumentDictionary forKey:@"PaymentInstrument"];
	
	OrderedDictionary *shoppingCartItemDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartItemDictionary setObject:product.productID forKey:@"ProductId"];
    [shoppingCartItemDictionary setObject:product.pricingPlanID forKey:@"ProductPricingPlanId"];
    [shoppingCartItemDictionary setObject:@"1" forKey:@"Quantity"];
    
    OrderedDictionary *itemsDictionary = [[OrderedDictionary alloc] init];
    [itemsDictionary setObject:shoppingCartItemDictionary forKey:@"ShoppingCartItem"];
    
    OrderedDictionary *shoppingCartDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartDictionary setObject:@"USD" forKey:@"Currency"];
    [shoppingCartDictionary setObject:itemsDictionary forKey:@"Items"];
    [shoppingCartDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.OrderManagement|SubscriberId"];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:paymentInstrumentsDictionary forKey:@"PaymentInstruments"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:shoppingCartDictionary forKey:@"ShoppingCart"];
    
    NSString          *requestName     = [NSString stringWithFormat:@"%@Request", verb];
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:requestName];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
	
	
}

- (void)submitOrderForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument {
    NSString *verb = @"SubmitOrder";
    // NSString * urlString   = [NSString stringWithFormat:@"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/%@", verb];
    NSString *urlString   = [NSString stringWithFormat:@"%@/%@", self.storefrontURLString, verb];
    NSURL    *urlEndpoint = [URLFactory escapedURLWithString:urlString];
        
    OrderedDictionary *paymentInstrumentDictionary = [[OrderedDictionary alloc] init];
    [paymentInstrumentDictionary setObject:paymentInstrument.paymentInstrumentID forKey:@"Id"];
    [paymentInstrumentDictionary setObject:paymentInstrument.nickname forKey:@"Nickname"];
    [paymentInstrumentDictionary setObject:paymentInstrument.status forKey:@"Status"];
    [paymentInstrumentDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    [paymentInstrumentDictionary setObject:paymentInstrument.instrumentType forKey:@"Type"];
    
    OrderedDictionary *workaroundCreditCardDictionary = [[OrderedDictionary alloc] init];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_accountNumber forKey:@"AccountNumber"];
    
    OrderedDictionary *billingAddressDictionary = [[OrderedDictionary alloc] init];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_city forKey:@"City"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_country forKey:@"CountryAbbreviation"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_id forKey:@"Id"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_lineOne forKey:@"LineOne"];
    
    if (paymentInstrument.wcc_ba_lineTwo != nil) {
        [billingAddressDictionary setObject:paymentInstrument.wcc_ba_lineTwo forKey:@"LineTwo"];
    }
    
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_nickname forKey:@"Nickname"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_phoneNumber forKey:@"PhoneNumber"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_state forKey:@"StateProvinceRegionAbbreviation"];
    [billingAddressDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    [billingAddressDictionary setObject:paymentInstrument.wcc_ba_zip forKey:@"ZipPostalCode"];
    
    [workaroundCreditCardDictionary setObject:billingAddressDictionary forKey:@"BillingAddress"];
    
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_cardType forKey:@"CardType"];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_expirationMonth forKey:@"ExpirationMonth"];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_expirationYear forKey:@"ExpirationYear"];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_isVerified forKey:@"IsVerified"];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_nameOnCard forKey:@"NameOnCard"];
    [workaroundCreditCardDictionary setObject:paymentInstrument.wcc_phoneNumber forKey:@"PhoneNumber"];
    
    [paymentInstrumentDictionary setObject:workaroundCreditCardDictionary forKey:@"WorkaroundCreditCard"];
    
    OrderedDictionary *paymentInstrumentsDictionary = [[OrderedDictionary alloc] init];
    [paymentInstrumentsDictionary setObject:paymentInstrumentDictionary forKey:@"PaymentInstrument"];
    
    OrderedDictionary *shoppingCartItemDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartItemDictionary setObject:product.productID forKey:@"ProductId"];
    [shoppingCartItemDictionary setObject:product.pricingPlanID forKey:@"ProductPricingPlanId"];
    [shoppingCartItemDictionary setObject:@"1" forKey:@"Quantity"];
    
    OrderedDictionary *itemsDictionary = [[OrderedDictionary alloc] init];
    [itemsDictionary setObject:shoppingCartItemDictionary forKey:@"ShoppingCartItem"];
    
    OrderedDictionary *shoppingCartDictionary = [[OrderedDictionary alloc] init];
    [shoppingCartDictionary setObject:@"USD" forKey:@"Currency"];
    [shoppingCartDictionary setObject:itemsDictionary forKey:@"Items"];
    [shoppingCartDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.OrderManagement|SubscriberId"];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:paymentInstrumentsDictionary forKey:@"PaymentInstruments"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:shoppingCartDictionary forKey:@"ShoppingCart"];
    
    NSString          *requestName     = [NSString stringWithFormat:@"%@Request", verb];
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:requestName];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)submitOrderWithDefaultPaymentInstrumentForProduct:(Product *)product {
    PaymentInstrument *defaultPaymentInstrument = [paymentInstruments objectAtIndex:0];
    
    [self submitOrderForProduct:product paymentInstrument:defaultPaymentInstrument];
}


- (void)fullTextSearchForString:(NSString *)searchString forPage:(NSInteger)page pageSize:(NSInteger)pageSize {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/SearchProducts";
    NSString *urlString = [NSString stringWithFormat:@"%@/SearchProducts", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"Everything" forKey:@"http://ContentDirect.ProductManagement|DataToReturn"];
    [requestDictionary setObject:[[NSNumber numberWithInteger:page] stringValue] forKey:@"http://ContentDirect.ProductManagement|PageNumber"];
    [requestDictionary setObject:[[NSNumber numberWithInteger:pageSize] stringValue] forKey:@"http://ContentDirect.ProductManagement|PageSize"];
    
    OrderedDictionary *searchParamsDict = [[OrderedDictionary alloc] init];
    [searchParamsDict setObject:searchString forKey:@"SearchString"];
    
    [requestDictionary setObject:searchParamsDict forKey:@"SearchParameters"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"SearchProductsRequest"];
    
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveProductByProductID:(NSString *)productID {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrieveProduct";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrieveProduct", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    // This will return the product recommendation info in <ReferencedProductSummaries>.
    [requestDictionary setObject:@"true" forKey:@"http://ContentDirect.ProductManagement|IncludePricingPlanExternalReferences"];
    [requestDictionary setObject:@"true" forKey:@"http://ContentDirect.ProductManagement|IncludeRecommendations"];
    [requestDictionary setObject:productID forKey:@"http://ContentDirect.ProductManagement|ProductId"];
    
    if (self.subscriberID != nil) {
        [requestDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.ProductManagement|SubscriberId"];
    }
    
    [requestDictionary setObject:@"ContentItem" forKey:@"ViewContentType"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrieveProductRequest"];
    
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrieveCodes {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrieveCodes";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrieveCodes", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    NSArray *codeTypesArray = [NSArray arrayWithObjects:@"DefaultPasswordChallenge", @"CreditCardType", @"Rating", nil];
    
    [requestDictionary setObject:codeTypesArray forKey:@"http://ContentDirect.ConfigurationManagement|CodeTypes"];
    [requestDictionary setObject:@"true" forKey:@"http://ContentDirect.ConfigurationManagement|IncludeGlobalCodes"];
    [requestDictionary setObject:self.systemID forKey:@"http://ContentDirect.ConfigurationManagement|SystemId"];
    
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrieveCodesRequest"];
    
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)registerSubscriberDevice {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RegisterSubscriberDevice";
    NSString *urlString = [NSString stringWithFormat:@"%@/RegisterSubscriberDevice", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    OrderedDictionary *physicalDeviceDictionary = [[OrderedDictionary alloc] init];
    [physicalDeviceDictionary setObject:[self udid] forKey:@"DeviceId"];
    [physicalDeviceDictionary setObject:self.deviceType forKey:@"DeviceTypeCode"];
    
    // TODO determine if this should be passed into the init of CDClient.
    [physicalDeviceDictionary setObject:self.physicalDeviceTypeCode forKey:@"PhysicalDeviceTypeCode"];
    
    [physicalDeviceDictionary setObject:[self udid] forKey:@"SerialNumber"];
    [physicalDeviceDictionary setObject:@"Active" forKey:@"Status"];
    
    [requestDictionary setObject:physicalDeviceDictionary forKey:@"http://ContentDirect.DeviceManagement|PhysicalDevice"];
    
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.DeviceManagement|SubscriberId"];
    
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RegisterSubscriberDeviceRequest"];
	
	//NSLog(@"RegisterDevieceRequest: %@", inputDictionary);
    
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


// We have to pass in aSubscriberID because subscriberID is being manipulated by the UI to be set to nil on logout.
- (void)removeSubscriberDeviceWithSubscriberID:(NSString *)aSubscriberID 
{
	// NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RemoveSubscriberDevice";
	NSString *urlString = [NSString stringWithFormat:@"%@/RemoveSubscriberDevice", self.storefrontURLString];
	
	//NSLog(@"%@", urlString);
	
	NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
	
	OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
	
	OrderedDictionary *subscriberDeviceDictionary = [[OrderedDictionary alloc] init];
	[subscriberDeviceDictionary setObject:[self udid] forKey:@"DeviceId"];
	[subscriberDeviceDictionary setObject:self.deviceType forKey:@"DeviceTypeCode"];
	
	if(self.deviceID != nil)
	{
		[subscriberDeviceDictionary setObject:self.deviceID forKey:@"Id"];
	}
	
	[subscriberDeviceDictionary setObject:@"Active" forKey:@"PhysicalDeviceStatus"];
	
	[subscriberDeviceDictionary setObject:self.physicalDeviceTypeCode forKey:@"PhysicalDeviceTypeCode"];
	
	[requestDictionary setObject:subscriberDeviceDictionary forKey:@"http://ContentDirect.DeviceManagement|SubscriberDevice"];
	
	[requestDictionary setObject:aSubscriberID forKey:@"http://ContentDirect.DeviceManagement|SubscriberId"];
	
	[requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
	[requestDictionary setObject:@"true" forKey:@"ReturnFault"];
	
	[requestDictionary setObject:self.sessionID forKey:@"SessionId"];
	
	
	OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RemoveSubscriberDeviceRequest"];
	//NSLog(@"Remove Device Call: %@", inputDictionary);
	
	[poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)retrievePasswordChallenge:(NSString *)login {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrievePasswordChallenge";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrievePasswordChallenge", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:self.language forKey:@"Language"];
    [requestDictionary setObject:login forKey:@"Login"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.systemID forKey:@"SystemId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrievePasswordChallengeRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)resetPasswordForLogin:(NSString *)login challengeResponse:(NSString *)challengeResponse newPassword:(NSString *)newPassword {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/ResetPassword";
    NSString *urlString = [NSString stringWithFormat:@"%@/ResetPassword", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:self.language forKey:@"Language"];
    [requestDictionary setObject:login forKey:@"Login"];
    [requestDictionary setObject:newPassword forKey:@"NewPassword"];
    [requestDictionary setObject:challengeResponse forKey:@"PasswordChallengeResponse"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.systemID forKey:@"SystemId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"ResetPasswordRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)sendNewPasswordForLogin:(NSString *)login {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/GenerateAndEmailNewPassword";
    NSString *urlString = [NSString stringWithFormat:@"%@/GenerateAndEmailNewPassword", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"English-US" forKey:@"Language"];
    [requestDictionary setObject:login forKey:@"Login"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.systemID forKey:@"SystemId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"GenerateAndEmailPasswordRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)updateCredentialsForSubscriberId:(NSString *)anID currentPassword:(NSString *)curPassword newPassword:(NSString *)newPassword newLogin:(NSString *)newLogin newChallengeQuestion:(NSString *)newChallengeQuestion newChallengeResponse:(NSString *)newChallengeResponse {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/UpdateCredentials";
    NSString *urlString = [NSString stringWithFormat:@"%@/UpdateCredentials", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:curPassword forKey:@"CurrentPassword"];
    [requestDictionary setObject:self.language forKey:@"Language"];
    [requestDictionary setObject:newLogin == nil ? @"":newLogin forKey:@"NewLogin"];
    [requestDictionary setObject:newPassword == nil ? @"":newPassword forKey:@"NewPassword"];
    [requestDictionary setObject:newChallengeQuestion == nil ? @"":newChallengeQuestion forKey:@"NewPasswordChallenge"];
    [requestDictionary setObject:newChallengeResponse == nil ? @"":newChallengeResponse forKey:@"NewPasswordChallengeResponse"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    [requestDictionary setObject:self.subscriberID forKey:@"SubscriberId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"UpdateCredentialsRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)createPaymentInstrument:(PaymentInstrument *)paymentInstrument {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/CreatePaymentInstrument";
    NSString *urlString = [NSString stringWithFormat:@"%@/CreatePaymentInstrument", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    [requestDictionary setObject:[paymentInstrument toDictionaryWithSubscriberID:self.subscriberID] forKey:@"PaymentInstrument"];
    
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"CreatePaymentInstrumentRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)sendPing {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/PingSession";
    NSString *urlString = [NSString stringWithFormat:@"%@/PingSession", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"PingSessionRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


- (void)removePaymentInstrument:(PaymentInstrument *)paymentInstrument {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RemovePaymentInstrument";
    NSString *urlString = [NSString stringWithFormat:@"%@/RemovePaymentInstrument", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    [requestDictionary setObject:[paymentInstrument toDictionaryWithSubscriberID:self.subscriberID] forKey:@"PaymentInstrument"];
    
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RemovePaymentInstrumentRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
    
    self.paymentInstrumentBeingRemoved = paymentInstrument;
}


- (void)retrieveSubscriberProducts {
    // NSString * urlString = @"http://services.int1.cdops.net/v3.3/SubscriberServicePox.svc/RetrieveSubscriberProducts";
    NSString *urlString = [NSString stringWithFormat:@"%@/RetrieveSubscriberProducts", self.storefrontURLString];
        
    NSURL *urlEndpoint = [URLFactory escapedURLWithString:urlString];
    
    OrderedDictionary *requestDictionary = [[OrderedDictionary alloc] init];
    
    [requestDictionary setObject:@"true" forKey:@"http://ContentDirect.OrderManagement|IncludeProductSummaries"];
    [requestDictionary setObject:@"true" forKey:@"http://ContentDirect.OrderManagement|IncludeSubscriptionProducts"];
    [requestDictionary setObject:@"1" forKey:@"http://ContentDirect.OrderManagement|PageNumber"];
    [requestDictionary setObject:@"100" forKey:@"http://ContentDirect.OrderManagement|PageSize"];
    [requestDictionary setObject:self.subscriberID forKey:@"http://ContentDirect.OrderManagement|SubscriberId"];
    [requestDictionary setObject:@"true" forKey:@"RaiseFaultWithHttp200"];
    [requestDictionary setObject:@"true" forKey:@"ReturnFault"];
    [requestDictionary setObject:self.sessionID forKey:@"SessionId"];
    
    OrderedDictionary *inputDictionary = [NSDictionary dictionaryWithObject:requestDictionary forKey:@"RetrieveSubscriberProductsRequest"];
    
    [poxClient callPOXEndpoint:urlEndpoint input:inputDictionary delegate:self];
}


#pragma mark -
#pragma mark Callback
#pragma mark -

// TODO break this out (and calls) into subclasses - where each class sends a request and handles a response.
- (void)resultsForLastCallPOXEndpoint:(NSURL *)urlEndpoint output:(NSDictionary *)outputDictionary {
    
    // call back to the delegate; use the urlEndpoint to determine which callback method to call
    NSString *apiVerb = [[urlEndpoint path] lastPathComponent];
    
	NSLog(@"Results for verb: %@", apiVerb);
	
	//NSLog(@"CDClient -resultsForLastCallPOXEndpoint:%@", urlEndpoint);
    NSObject<CDClientDelegate> *myDelegate = (NSObject<CDClientDelegate> *)self.delegate;
    
    if ([apiVerb isEqual:@"RetrieveProductCategories"]) {
        NSDictionary   *responseDictionary         = [outputDictionary objectForKey:@"RetrieveProductCategoriesResponse"];
        NSMutableArray *productCategoryArray       = [[NSMutableArray alloc] init];
        NSArray        *retrievedProductCategories = [responseDictionary objectForKey:@"ProductCategories"];
        
        for (NSDictionary *productCategoryDictionary in retrievedProductCategories) {
            ProductCategory *category = [[ProductCategory alloc] init];
            category.categoryID = [productCategoryDictionary objectForKey:@"id_x003B_"];
            category.name       = [productCategoryDictionary objectForKey:@"Name"];
            [productCategoryArray addObject:category];
        }
        
        if ([myDelegate respondsToSelector:@selector(productCategoriesRetrieved:)]) {
            [delegate productCategoriesRetrieved:productCategoryArray];
        }
        
    } else if ([apiVerb isEqual:@"RetrieveProductsByCategory"]) {
        NSDictionary   *responseDictionary = [outputDictionary objectForKey:@"RetrieveProductsByCategoryResponse"];
        NSMutableArray *productArray       = [[NSMutableArray alloc] init];
        NSArray        *retrievedProducts  = [responseDictionary objectForKey:@"Products"];
        
        for (NSDictionary *productDictionary in retrievedProducts) {
			Product *product = [self productFromDictionary:productDictionary];
			if([[CDServiceFacadeDelegate sharedCDClient] enableInAppPurchase] || ([product isPurchased] || [product isFree] || [product isInstantlyViewableNotOrderable])) // Only add the product is it is free,  purchased or instantly viewable - this hides the purchase options
			{
				[productArray addObject:product];
			}
        }
        
        if ([myDelegate respondsToSelector:@selector(productsRetrieved:)]) {
            [delegate productsRetrieved:productArray];
        }
        
    } else if ([apiVerb isEqual:@"RetrieveSubscriber"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RetrieveSubscriberResponse"];
        
        if ([myDelegate respondsToSelector:@selector(retrieveSubscriberInfoSucceeded:)]) {
            [delegate retrieveSubscriberInfoSucceeded:[responseDictionary objectForKey:@"Subscriber"]];
        }
    }
	else if( [apiVerb isEqual:@"RetrievePlayerFeaturedItems"] )
	{
		NSDictionary *responseDictionary = [outputDictionary valueForKey:@"RetrievePlayerFeaturedItemsResponse"];
		NSLog(@"Featured Items Response: %@", responseDictionary);
		
		NSMutableArray *products = [[NSMutableArray alloc] init];
		NSArray *featuredItems = [responseDictionary objectForKey:@"FeaturedItems"];
		
		// Featured Items (Products)
		for(NSDictionary *feature in featuredItems)
		{
			NSDictionary *productDictionary = [feature objectForKey:@"ProductSummary"];
			Product      *product           = [self productFromDictionary:productDictionary];
			
			if([[CDServiceFacadeDelegate sharedCDClient] enableInAppPurchase] || ([product isPurchased] || [product isFree] || [product isInstantlyViewableNotOrderable])) // Only add the product is it is free, purchased or instantly viewable
			{
				[products addObject:product];
			}
		}
		
		NSLog(@"My Delegate %@ -> responds to featured items delegate? %@", myDelegate, [myDelegate respondsToSelector:@selector(retrieveFeaturedItemsSucceeded:)]?@"YES":@"NO");
		
		if([myDelegate respondsToSelector:@selector(retrieveFeaturedItemsSucceeded:)])
		{
			[delegate retrieveFeaturedItemsSucceeded:products];
		}
		
		
	}
	else if ([apiVerb isEqual:@"ViewProductContent"]) 
	{
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"ViewProductContentResponse"];
        
		NSLog(@"View Content Response: %@", responseDictionary);
		
        ContentItem *contentItem = [[ContentItem alloc] init];
        contentItem.contentItemID = [responseDictionary objectForKey:@"ContentItemId"];
        contentItem.contentURL    = [responseDictionary objectForKey:@"ContentURL"];
        
        if ([myDelegate respondsToSelector:@selector(productContentRetrieved:)]) {
            [delegate productContentRetrieved:contentItem];
        }
        
    } else if ([apiVerb isEqual:@"CreateSubscriber"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"CreateSubscriberResponse"];
        
        if ([myDelegate respondsToSelector:@selector(createSubscriberCompleted:)]) {
            [delegate createSubscriberCompleted:[[responseDictionary objectForKey:@"Subscriber"] objectForKey:@"Id"]];
        }
    } else if ([apiVerb isEqual:@"Login"]) {
        // Parse out the sessionID and store for later calls
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"LoginResponse"];
        self.sessionID = [responseDictionary objectForKey:@"SessionId"];
        
        // Parse login name
        NSDictionary *subscriberLoginSummaryDictionary = [responseDictionary objectForKey:@"SubscriberLoginSummary"];
        self.loginName = [subscriberLoginSummaryDictionary objectForKey:@"Login"];
        
        // Get sessionAuthenticationType in other places where we get sessionID.
        self.sessionAuthenticationType = [responseDictionary objectForKey:@"SessionAuthenticationType"];
        
        NSDictionary *subscriberDictionary = [responseDictionary objectForKey:@"SubscriberLoginSummary"];
        self.subscriberID = [subscriberDictionary objectForKey:@"Id"];
        
        if ([myDelegate respondsToSelector:@selector(loginCompletedWithSessionID:usingTemporaryPassword:)]) {
            [delegate loginCompletedWithSessionID:self.sessionID usingTemporaryPassword:[[subscriberDictionary objectForKey:@"IsPasswordTemporary"] boolValue]];
        }
    }
	else if([apiVerb isEqual:@"Logout"])
	{
		//NSLog(@"**** Logout success ****");
		// Parse out the sessionID and store for later calls
		NSDictionary *responseDictionary = [outputDictionary objectForKey:@"LogoutResponse"];
		//NSLog(@"Logout Response: %@", responseDictionary);
		NSString *newSessionID = [responseDictionary objectForKey:@"SessionId"];
		NSLog(@"Old SesID: %@ | New SesID: %@ | Do they match? %@", self.sessionID, newSessionID, self.sessionID == newSessionID?@"YES":@"NO");
		self.sessionID = newSessionID;
		
		// Get sessionAuthenticationType in other places where we get sessionID.
		self.sessionAuthenticationType = [responseDictionary objectForKey:@"SessionAuthenticationType"];
		
		if([myDelegate respondsToSelector:@selector(logoutCompletedSuccess)])
		{
			[delegate logoutCompletedSuccess];
		}
	}
	else if ([apiVerb isEqual:@"UpdateSubscriber"]) 
	{
        if ([myDelegate respondsToSelector:@selector(updateSubscriberCompleted:)]) {
            [delegate updateSubscriberCompleted:@"Succeeded"];
        }
    } else if ([apiVerb isEqual:@"SearchProducts"]) {
        NSDictionary   *responseDictionary = [outputDictionary objectForKey:@"SearchProductsResponse"];
        NSMutableArray *productArray       = [[NSMutableArray alloc] init];
        NSArray        *retrievedProducts  = [responseDictionary objectForKey:@"Products"];
        int             pageCount          = [[responseDictionary objectForKey:@"TotalPageCount"] intValue];
        
        for (NSDictionary *productDictionary in retrievedProducts) {
			
            Product *product = [self productFromDictionary:productDictionary];
			
			if([[CDServiceFacadeDelegate sharedCDClient] enableInAppPurchase] || ([product isPurchased] || [product isFree] || [product isInstantlyViewableNotOrderable])) // Only add the product is it is free,  purchased or instantly viewable - this hides the purchase options
			{
				[productArray addObject:product];
			}
        }
        
        if ([myDelegate respondsToSelector:@selector(fullTextSearchResults:pageCount:)]) {
            [self.delegate fullTextSearchResults:productArray pageCount:pageCount];
        }
    } else if ([apiVerb isEqual:@"RetrieveProduct"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RetrieveProductResponse"];
        
        NSDictionary *productDictionary = [responseDictionary objectForKey:@"Product"];
		Product *theProduct = [self productFromDictionary:productDictionary];
		
        NSArray *externalReferences = [productDictionary objectForKey:@"ExternalReferences"] ;		
		NSString *externalTypeValue = [[externalReferences objectAtIndex:0] objectForKey:@"ExternalReferenceValue"];
		
        // get the licensing text
        NSArray *pricingPlans = [productDictionary objectForKey:@"PricingPlans"];
        
        NSDictionary *firstPricingPlanSummaryDictionary = [pricingPlans objectAtIndex:0];
        NSString     *licensingText                     = [firstPricingPlanSummaryDictionary objectForKey:@"PricingPlanDescription"];
        
		// Availability dates
		NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
		[dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
		NSArray *startDatelist = [[firstPricingPlanSummaryDictionary objectForKey:@"AvailabilityStartDate"] componentsSeparatedByString:@"T"];
		NSString *startDate = [NSString stringWithFormat:@"%@ %@", [startDatelist objectAtIndex:0], [startDatelist objectAtIndex:1]];
		NSLog(@"%@: startDate: %@", theProduct.name, startDate);
		theProduct.availabilityStartDate = [dateFormatter dateFromString:startDate];
		theProduct.availabilityEndDate = [dateFormatter dateFromString:[firstPricingPlanSummaryDictionary objectForKey:@"AvailabilityEndDate"]];
        
        // get the recommended products
        NSArray *recommendedProducts = [productDictionary objectForKey:@"OrderBasedRecommendedProducts"];
        
        NSArray *referencedProductSummaries = [productDictionary objectForKey:@"ReferencedProductSummaries"];
        
        NSMutableDictionary *productIDsToSummaries = [[NSMutableDictionary alloc] init];
        
        for (NSDictionary *summaryDictionary in referencedProductSummaries) {
            NSString     *productID       = [summaryDictionary objectForKey:@"Key"];
            NSDictionary *valueDictionary = [summaryDictionary objectForKey:@"Value"];
            [productIDsToSummaries setObject:valueDictionary forKey:productID];
        }
        
        
        NSMutableArray *productArray = [[NSMutableArray alloc] init];
        
        
        for (NSString *productIDString in recommendedProducts) {
            NSDictionary *productDictionary = [productIDsToSummaries objectForKey:productIDString];
            
            if (productDictionary != nil) {
                Product *product = [self productFromDictionary:productDictionary];
				
				if([[CDServiceFacadeDelegate sharedCDClient] enableInAppPurchase] || ([product isPurchased] || [product isFree] || [product isInstantlyViewableNotOrderable])) // Only add the product is it is free,  purchased or instantly viewable - this hides the purchase options
				{
					[productArray addObject:product];
				}
            } else {
                //NSLog(@"ERROR: Product summary not found for recommended product with ID:%@", productIDString);
            }
        }
        
        
        NSDictionary *extensions = [[productDictionary objectForKey:@"Extensions"] objectAtIndex:0];
        NSDictionary *value = [extensions objectForKey:@"Value"];
        NSDictionary *contentWork = [value objectForKey:@"ContentWork"];
        NSString *runtime = [contentWork objectForKey:@"Runtime"];
        
        if ([myDelegate respondsToSelector:@selector(retrieveProductSucceededWithLicense:externalTypeValue:recommendedProducts:runtime:product:)]) {
            [myDelegate retrieveProductSucceededWithLicense:licensingText externalTypeValue:externalTypeValue recommendedProducts:productArray runtime:runtime product:theProduct];
        }
    } else if ([apiVerb isEqual:@"RetrieveCodes"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RetrieveCodesResponse"];
        
        NSMutableDictionary *codeTypesToCodes = [[NSMutableDictionary alloc] init];
        
        NSArray *codeDictionariesArray = [responseDictionary objectForKey:@"Codes"];
        
        for (NSDictionary *codeDictionary in codeDictionariesArray) {
            NSString *codeType = [codeDictionary objectForKey:@"Key"];
            
            NSMutableArray *codes = [[NSMutableArray alloc] init];
            [codeTypesToCodes setObject:codes forKey:codeType];
            
            NSArray *codeValues = [codeDictionary objectForKey:@"Value"];
            
            for (NSDictionary *codeValueDictionary in codeValues) {
                NSString *isGlobal    = [codeValueDictionary objectForKey:@"IsGlobal"];
                NSString *name        = [codeValueDictionary objectForKey:@"Name"];
                NSString *numericCode = [codeValueDictionary objectForKey:@"NumericCode"];
                Code     *code        = [[Code alloc] init];
                code.isGlobal    = isGlobal;
                code.name        = name;
                code.numericCode = [numericCode intValue];
                [codes addObject:code];
                
            }
            
        }
        
        // Call back to delegate
        if ([myDelegate respondsToSelector:@selector(codesRetrieved:)]) {
            [self.delegate codesRetrieved:codeTypesToCodes];
        }
        
        //[codeTypesToCodes autorelease];
    } else if ([apiVerb isEqual:@"RegisterSubscriberDevice"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RegisterSubscriberDeviceResponse"];
        
		//NSLog(@"Register Device Response: %@", responseDictionary);
		
        NSDictionary *physicalDeviceDictionary = [responseDictionary objectForKey:@"PhysicalDevice"];
        NSString     *aDeviceAuthenticationKey = [physicalDeviceDictionary objectForKey:@"AuthenticationKey"];
        NSString     *aDeviceID                = [physicalDeviceDictionary objectForKey:@"Id"];
        
        // Remember deviceID so we can unregister if we need to.
        self.deviceID                = aDeviceID;
        self.deviceAuthenticationKey = aDeviceAuthenticationKey;
        
        // Call back to delegate
        if ([myDelegate respondsToSelector:@selector(deviceRegisteredWithDeviceID:deviceAuthenticationKey:subscriberID:)]) {
            [self.delegate deviceRegisteredWithDeviceID:aDeviceID deviceAuthenticationKey:aDeviceAuthenticationKey subscriberID:self.subscriberID];
        }
    } else if ([apiVerb isEqual:@"RetrievePasswordChallenge"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RetrievePasswordChallengeResponse"];
        
        if ([myDelegate respondsToSelector:@selector(retrievePasswordChallengeCompleted:)]) {
            [self.delegate retrievePasswordChallengeCompleted:[responseDictionary objectForKey:@"PasswordChallenge"]];
        }
    } else if ([apiVerb isEqual:@"ResetPassword"]) {
        if ([myDelegate respondsToSelector:@selector(resetPasswordCompleted)]) {
            [self.delegate resetPasswordCompleted];
        }
    } else if ([apiVerb isEqual:@"CalculateOrderQuote"]) {
        if ([myDelegate respondsToSelector:@selector(calculateOrderSucceededWithSubtotal:tax:total:)]) {
            NSDictionary *reponseDictionary    = [outputDictionary objectForKey:@"CalculateOrderQuoteResponse"];
            NSDictionary *orderQuoteDictionary = [reponseDictionary objectForKey:@"OrderQuote"];
            
            NSString *subtotalString = [orderQuoteDictionary objectForKey:@"SubTotalAmount"];
            NSString *taxString      = [orderQuoteDictionary objectForKey:@"TaxAmount"];
            NSString *totalString    = [orderQuoteDictionary objectForKey:@"TotalAmount"];
            
            [self.delegate calculateOrderSucceededWithSubtotal:subtotalString tax:taxString total:totalString];
        }
    } else if ([apiVerb isEqual:@"SubmitOrder"]) {
        if ([myDelegate respondsToSelector:@selector(submitOrderSucceeded)]) {
            // TODO Ask Ani if we need to check anything in the response.
            [self.delegate submitOrderSucceeded];
        }
    } else if ([apiVerb isEqual:@"GenerateAndEmailNewPassword"]) {
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"GenerateAndEmailPasswordResponse"];
        
        if ([myDelegate respondsToSelector:@selector(newPasswordSentTo:)]) {
            [self.delegate newPasswordSentTo:[responseDictionary objectForKey:@"Email"]];
        }
    } else if ([apiVerb isEqual:@"UpdateCredentials"]) {
        if ([myDelegate respondsToSelector:@selector(updateCredentialsSucceeded)]) {
            [self.delegate updateCredentialsSucceeded];
        }
    } else if ([apiVerb isEqual:@"CreatePaymentInstrument"]) {
        NSDictionary      *responseDictionary = [outputDictionary objectForKey:@"CreatePaymentInstrumentResponse"];
        PaymentInstrument *pi                 = [PaymentInstrument paymentInstrumentFromDictionary:[responseDictionary objectForKey:@"PaymentInstrument"]];
        [paymentInstruments addObject:pi];
        
        if ([myDelegate respondsToSelector:@selector(createPaymentInstrumentSucceeded:)]) {
            [self.delegate createPaymentInstrumentSucceeded:pi];
        }
    } else if ([apiVerb isEqual:@"PingSession"]) {
        if ([myDelegate respondsToSelector:@selector(pingSuccess)]) {
            [self.delegate pingSuccess];
        }
    } else if ([apiVerb isEqual:@"RemovePaymentInstrument"]) {
        [paymentInstruments removeObject:self.paymentInstrumentBeingRemoved];
        self.paymentInstrumentBeingRemoved = nil;
        
        if ([myDelegate respondsToSelector:@selector(removePaymentInstrumentSucceeded)]) {
            [self.delegate removePaymentInstrumentSucceeded];
        }
    } else if ([apiVerb isEqual:@"RetrieveSubscriberProducts"]) {
        NSMutableArray *products = [NSMutableArray array];
        
        NSDictionary *responseDictionary = [outputDictionary objectForKey:@"RetrieveSubscriberProductsResponse"];
        NSArray      *retrievedProducts  = [responseDictionary objectForKey:@"Products"];
        
        for (NSDictionary *productDetail in retrievedProducts) {
            Product  *product    = [self productFromDictionary:[productDetail objectForKey:@"ProductSummary"]];
            NSNumber *secondsRemaining = [productDetail objectForKey:@"AccessSecondsRemaining"];
            
            if (secondsRemaining) {
                product.expirationDate = [NSDate dateWithTimeIntervalSinceNow:[secondsRemaining integerValue]];
            }
            
			if([[CDServiceFacadeDelegate sharedCDServiceFacade] enableInAppPurchase] || ([product isPurchased] || [product isFree] || [product isInstantlyViewableNotOrderable])) // Only add the product is it is free,  purchased or instantly viewable - this hides the purchase options
			{
				[products addObject:product];
			}
        }
        
        subscriberProducts = products;
        
        if ([myDelegate respondsToSelector:@selector(retrievedSubscriberProducts:)]) {
            [self.delegate retrievedSubscriberProducts:products];
        }
    } 
	else if ([apiVerb isEqual:@"RemoveSubscriberDevice"]) 
	{
		//NSLog(@"Remove Device Response: %@", [outputDictionary objectForKey:@"RemoveSubscriberDeviceResponse"]);
		// Remove deviceID
        self.deviceID                = nil;
        self.deviceAuthenticationKey = nil;
        
        if ([myDelegate respondsToSelector:@selector(deviceUnregistrationSucceeded)]) {
            [self.delegate deviceUnregistrationSucceeded];
        }
    } else {
        //NSLog(@"Results for Unknown API Verb:%@", apiVerb);
    }
}


- (void)lastCallFailedForPOXEndpoint:(NSURL *)urlEndpoint fault:(Fault *)fault {
    NSString *apiVerb = [[urlEndpoint path] lastPathComponent];
    
	NSLog(@"Response Fault Verb: %@", apiVerb);
	
    NSObject *myDelegate = (NSObject *)self.delegate;
    
    if ([apiVerb isEqual:@"RetrieveProductCategories"]) {
        if ([myDelegate respondsToSelector:@selector(productCategoryRetrievalFailedWithFault:)]) {
            [delegate productCategoryRetrievalFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrieveProductsByCategory"]) {
        if ([myDelegate respondsToSelector:@selector(productRetrievalFailedWithFault:)]) {
            [delegate productRetrievalFailedWithFault:fault];
        }
    }
	else if( [apiVerb isEqual:@"RetrievePlayerFeaturedItems"] )
	{
		if([myDelegate respondsToSelector:@selector(retrieveFeaturedItemsWithFault:)])
		{
			[delegate retrieveFeaturedItemsWithFault:fault];
		}
	}
	else if ([apiVerb isEqual:@"ViewProductContent"]) 
	{
		NSLog(@"View Product Content Fault: %@", fault);
        if ([myDelegate respondsToSelector:@selector(productContentRetrievalFailedWithFault:)]) {
            [delegate productContentRetrievalFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"CreateSubscriber"]) {
        if ([myDelegate respondsToSelector:@selector(createSubscriberFailedWithFault:)]) {
            [delegate createSubscriberFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"Login"]) {
        if ([myDelegate respondsToSelector:@selector(loginFailedWithFault:)]) {
            [delegate loginFailedWithFault:fault];
        }
    } else if([apiVerb isEqual:@"Logout"]) {
		if([myDelegate respondsToSelector:@selector(logoutCompletedFault:)]) {
			[delegate logoutCompletedFault:fault];
		}
	}
	else if ([apiVerb isEqual:@"UpdateSubscriber"]) 
	{
        if ([myDelegate respondsToSelector:@selector(updateSubscriberFailedWithFault:)]) {
            [delegate updateSubscriberFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrieveSubscriber"]) {
        if ([myDelegate respondsToSelector:@selector(retrieveSubscriberInfoFailedWithFault:)]) {
            [delegate retrieveSubscriberInfoFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"SearchProducts"]) {
        if ([myDelegate respondsToSelector:@selector(fullTextSearchFailedWithFault:)]) {
            [delegate fullTextSearchFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrieveCodes"]) {
        if ([myDelegate respondsToSelector:@selector(codeRetrievalFailedWithFault:)]) {
            [delegate codeRetrievalFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RegisterSubscriberDevice"]) {
        if ([myDelegate respondsToSelector:@selector(deviceRegistrationFailedWithFault:)]) {
			//NSLog(@"Problem Registering Device: %@", fault);
            [delegate deviceRegistrationFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrievePasswordChallenge"]) {
        if ([myDelegate respondsToSelector:@selector(retrievePasswordChallengeFailedWithFault:)]) {
            [delegate retrievePasswordChallengeFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"ResetPassword"]) {
        if ([myDelegate respondsToSelector:@selector(resetPasswordFailedWithFault:)]) {
            [delegate resetPasswordFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"CalculateOrderQuote"]) {
        if ([myDelegate respondsToSelector:@selector(calculateOrdedFailedWithFault:)]) {
            [delegate calculateOrdedFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"SubmitOrder"]) {
        if ([myDelegate respondsToSelector:@selector(submitOrderFailedWithFault:)]) {
            [delegate submitOrderFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"GenerateAndEmailNewPassword"]) {
        if ([myDelegate respondsToSelector:@selector(newPasswordFailed:)]) {
            [delegate newPasswordFailed:fault];
        }
    } else if ([apiVerb isEqual:@"UpdateCredentials"]) {
        if ([myDelegate respondsToSelector:@selector(updateCredentialsFailedWithFault:)]) {
            [delegate updateCredentialsFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"CreatePaymentInstrument"]) {
        if ([myDelegate respondsToSelector:@selector(createPaymentInstrumentFailedWithFault:)]) {
            [delegate createPaymentInstrumentFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"PingSession"]) {
        if ([myDelegate respondsToSelector:@selector(pingFailedWithFault:)]) {
            [delegate pingFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RemovePaymentInstrument"]) {
        self.paymentInstrumentBeingRemoved = nil;
        
        if ([myDelegate respondsToSelector:@selector(removePaymentInstrumentFailedWithFault:)]) {
            [delegate removePaymentInstrumentFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrieveSubscriberProducts"]) {
        if ([myDelegate respondsToSelector:@selector(retrievedSubscriberProductsFailedWithFault:)]) {
            [delegate retrievedSubscriberProductsFailedWithFault:fault];
        }
    } 
	else if ([apiVerb isEqual:@"RemoveSubscriberDevice"]) 
	{
		//NSLog(@"Remove Subscriber Device Fault: %@:", fault);
		
		if ([myDelegate respondsToSelector:@selector(deviceUnregistrationFailedWithFault:)]) 
		{
            [delegate deviceUnregistrationFailedWithFault:fault];
        }
    } else if ([apiVerb isEqual:@"RetrieveProduct"]) {
        if ([myDelegate respondsToSelector:@selector(retrieveProductFailedWithFault:)]) {
            [delegate retrieveProductFailedWithFault:fault];
        }
    } else {
        //NSLog(@"Error for Unknown API Verb:%@", apiVerb);
        //NSLog(@"Fault:%@", fault);
    }
}


- (BOOL)loggedIn {
    if (self.subscriberID == nil) {
        return NO;
    }
    
	//NSLog(@"Session Auth Type: %@", [self sessionAuthenticationType]);
	
    if ([self.sessionAuthenticationType isEqualToString:@"Authenticated"] ||
        [self.sessionAuthenticationType isEqualToString:@"Unauthenticated"]) {
        return YES;
    }
    
    return NO;
}


- (BOOL)authenticated {
    if (self.subscriberID == nil) {
        return NO;
    }
    
    if ([self.sessionAuthenticationType isEqualToString:@"Authenticated"]) {
        return YES;
    }
    
    return NO;
}


- (NSArray *) paymentInstruments 
{
    return paymentInstruments;
}


- (NSArray *) subscriberProducts 
{
    return subscriberProducts;
}


- (void) productPurchased:(Product *)aProduct 
{
    if ([self doesUserOwnProduct:aProduct]) 
	{
        return; // already added.
    }
    
    [subscriberProducts addObject:aProduct];
}


- (BOOL) doesUserOwnProduct:(Product *)aProduct 
{
    NSInteger index = [[self subscriberProducts] indexOfObject:aProduct];
    
    if(index != NSNotFound) 
	{
        Product *subProduct = [[self subscriberProducts] objectAtIndex:index];
        
        if((subProduct != nil) && ([subProduct isExpired] == NO)) 
		{
			return YES;
        }
    }
    
    return NO;
}


- (BOOL) deviceHasBeenRegisteredPreviously 
{
    // Assume that user has just logged in.
    // We can detect this if:
    // saved deviceID is not nil and saved subscriberID equals current subscriberID
    NSString *savedSubscriberID = [CDSettings sharedCDSettings].subscriberID;
    
    return (self.deviceID != nil) && ([self.subscriberID isEqual:savedSubscriberID]);
}


#pragma mark -
#pragma mark Private
- (NSString *)udid {
    // TESTING - generate a unique udid here so that we work around the duplicate registration fault
    // return [NSString stringWithFormat:@"test-%ud", arc4random()];
    // /TESTING
    
    // TODO set this back, so that the udid is correct
	NSString *theUDID = [[UIDevice currentDevice] uniqueIdentifier];
	//NSLog(@"UDID: %@", theUDID);
    return theUDID;
}


- (Product *)productFromDictionary:(NSDictionary *)productDictionary {
    Product *product = [[Product alloc] init];
    
    product.productID        = [productDictionary objectForKey:@"Id"];
    product.name             = [productDictionary objectForKey:@"Name"];
    product.shortDescription = [productDictionary objectForKey:@"ShortDescription"];
    NSString *peerRatingString = [productDictionary objectForKey:@"PeerRating"];
    product.peerRating   = [peerRatingString intValue];
	product.orderingType = [productDictionary objectForKey:@"PricingPlanOrderingType"];
    
	NSArray *guidanceRatings = [productDictionary objectForKey:@"GuidanceRatings"];
	
	NSLog(@"Ratings: %@", guidanceRatings);
	
	if( [guidanceRatings count] > 0 )
	{
		product.guidanceRatingCode = [[guidanceRatings objectAtIndex:0] intValue];
	}
	
    product.thumbnailURL = [[productDictionary objectForKey:@"ThumbnailUrl"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    product.thumbnailURL = [product.thumbnailURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	product.imageURL = [[productDictionary objectForKey:@"ImageUrl"] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
	product.imageURL = [product.imageURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSString *pricingPlanOrderaingTypeString = [productDictionary objectForKey:@"PricingPlanOrderingType"];
    product.isOnDemand = [pricingPlanOrderaingTypeString isEqual:@"Orderable"];
    
	NSArray *externalReferences = [productDictionary objectForKey:@"ExternalReferences"];
	product.pricingPlanReferenceID = [[externalReferences objectAtIndex:0] objectForKey:@"ExternalReferenceValue"];
	
	product.purchasedPricingPlanID = [productDictionary objectForKey:@"PurchasedPricingPlanId"];
    NSArray *pricingPlanSummaries = [productDictionary objectForKey:@"PricingPlanOverviews"];
    
    if (pricingPlanSummaries == nil) {
        pricingPlanSummaries = [productDictionary objectForKey:@"PricingPlanSummaries"];
    }
	
    // Default to the first pricing plan
	NSDictionary *firstPricingPlanSummaryDictionary = [pricingPlanSummaries objectAtIndex:0];
	
	// Get the right purchase plan (if there are multiple) and there is a purchased plan id
	for(NSDictionary *summary in pricingPlanSummaries) // Loop through any of the pricing plan summaries
	{
		NSString *summaryPlanID = [summary objectForKey:@"Id"];
		// Match the ordering type of the product to the ordering type of the pricing plan
		NSString *summaryOrderingType = [summary objectForKey:@"OrderingType"];
		
		if([product purchasedPricingPlanID] != nil && [[product purchasedPricingPlanID] isEqualToString:summaryPlanID])
		{
			firstPricingPlanSummaryDictionary = summary;
		}
		else if([[product orderingType] isEqualToString:summaryOrderingType])
		{
			firstPricingPlanSummaryDictionary = summary;
		}
	}
	
    product.pricingPlanID = [firstPricingPlanSummaryDictionary objectForKey:@"Id"];
    NSString *licenseText = [firstPricingPlanSummaryDictionary objectForKey:@"PricingPlanDescription"];
    if (licenseText != nil) {
        product.licensingText = licenseText;
    }
    product.isSubscription = [[firstPricingPlanSummaryDictionary objectForKey:@"IsSubscription"] boolValue];
    
    NSString *chargeAmount = [firstPricingPlanSummaryDictionary objectForKey:@"ChargeAmount"];
    
    if (chargeAmount == nil) 
	{
        // Try workaround of parsing the name
        NSString *pricingPlanSummaryName = [firstPricingPlanSummaryDictionary objectForKey:@"Name"];
        
        if ([pricingPlanSummaryName rangeOfString:@"FREE3"].location != NSNotFound) 
		{
            chargeAmount = @"0.0";
        } 
		else 
		{
            NSArray *components = [pricingPlanSummaryName componentsSeparatedByString:@"$"];
            chargeAmount = [components lastObject];
        }
    } 
	else 
	{
        if ([pricingPlanOrderaingTypeString isEqualToString:@"InstantlyViewableNotOrderable"]) 
		{
            chargeAmount = @"0.0";
        }
    }
    
    product.price = chargeAmount;
	
	// HasPreview
	NSString *hasPreview = [productDictionary objectForKey:@"HasPreview"];
	//NSLog(@"hasPreview:%@", hasPreview);
	product.hasPreview = ([hasPreview isEqual:@"true"]);
	
	NSArray *productPreviews = [productDictionary objectForKey:@"ProductPreviews"];
	//NSLog(@"productPreviews:%@", productPreviews);
	if((productPreviews != nil) && [productPreviews isKindOfClass:[NSArray class]] && ([productPreviews count] > 0))
	{
		
		NSDictionary *previewDictionary = [productPreviews objectAtIndex:0];
		NSString *previewID = [previewDictionary objectForKey:@"Id"];
		product.previewID = previewID;
		//NSLog(@"previewID:%@", product.previewID);
	}
	
    return product;
}


@end
