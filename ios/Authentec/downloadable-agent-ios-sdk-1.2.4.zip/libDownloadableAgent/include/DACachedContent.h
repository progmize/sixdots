//
//  DACachedContent.h
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DADataTypes.h"

#pragma mark - DACachedContent class interface declaration

/**
 Represents a content cached -totally or partially- on the local storage for offline playback. 
 */
@interface DACachedContent : NSObject 
{
    NSURL *contentURL;
    DAContentType contentType;
    
    float totalDuration;
    float cachedDuration;
    
    DACachingStatus status;    
    BOOL isReadyToPlay;
}

/** the original content URL */
@property (nonatomic, copy) NSURL *contentURL;

/** the original content type */
@property (nonatomic, assign) DAContentType contentType;

//
// the following properties are KVO compliant and thus can be observed
// to track any change in the status of the cached content.
//

/** the total duration of the content (in seconds) or -1 if not available yet */
@property (assign) float totalDuration;

/** the duration of the content that is currently cached (in seconds) */
@property (assign) float cachedDuration;

/** the current status of the cached content @see DACachingStatus for a list of possible values */
@property (assign) DACachingStatus status;

/** whether there is a minimum amount of content in cache to allow offline playback */
@property (assign) BOOL isReadyToPlay;


#pragma mark -- Class Methods

/**
 A factory method that MUST be used to obtain instances of DACachedContent for each content that
 is to be stored in the cache. 
 
 The instance returned allows you to start or resume caching the content onto the local storage
 as a background process. If the content was already partly or entirely stored in the cache then 
 the object will reflect the current status.
 
 The following DAContentType's are exclusively supported:
    - PIFFType (remotely hosted PIFF files)
 
 Passing unsupported content types to this method will result in an exception being thrown.
 
 This method is thread safe and if invoked multiple times with the same content URL it will
 return a pointer to the first instance of DACachedContent created. The life cycle of this instance
 is managed internally by the Agent.
 
 @see DACachedContent for more information about the exposed details.
 
 @param contentURL  The URL of a content supported by the Agent.
 @param contentType The type of the content pointed by the contentURL parameter.
 
 @returns an instance of the DACachedContent class.
 */
+ (DACachedContent *)cachedContentWithURL:(NSURL *)contentURL ofType:(DAContentType)contentType;

/**
 Returns a list of all the content items currently stored in the cache (whether partially or fully).
 
 @returns an array of DACachedContent instances.
 */
+ (NSArray *)allCachedContentItems;


#pragma mark -- Instance Methods

/**
 Starts caching this content onto the local storage. If the content was already partly cached
 then the caching will resume where it left.
 
 Note: this method dispatches the work asynchronously to a concurrent queue and returns inmediatly.
 */
- (void)startCaching;

/**
 Interrupts the caching of this content if it was in progress. The caching process can be
 resumed later on by invoking the startCaching method again.
 
 Note: this method returns inmediatly but the cancellation might take a bit longer to be effective.
 */
- (void)pauseCaching;

/**
 Removes all the data stored in the cache for this content.
 
 Note: this method returns inmediatly but the purge might take a bit longer to be effective.
 */
- (void)purgeCache;

@end
