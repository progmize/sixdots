//
//  ConsoleLogViewController.m
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "ConsoleLogViewController.h"


@implementation ConsoleLogViewController

@synthesize loggedMessages;


- (void)viewDidLoad 
{
    [super viewDidLoad];

    self.view.backgroundColor = [UIColor viewFlipsideBackgroundColor]; 
	textview.font = [UIFont fontWithName:@"Arial" size:9];	
	textview.text = [NSString stringWithString:[loggedMessages componentsJoinedByString:@"\n"]];
}

- (IBAction)done:(id)sender 
{
    [self dismissModalViewControllerAnimated:YES];
}

- (IBAction)clear:(id)sender
{
	// clear log
	[loggedMessages removeAllObjects];
	textview.text = @"";	
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}


- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	return YES;
}

- (void)dealloc 
{
    NSLog(@"dealloc");
    
	[loggedMessages release];
    [textview release];
    [super dealloc];
}


@end
