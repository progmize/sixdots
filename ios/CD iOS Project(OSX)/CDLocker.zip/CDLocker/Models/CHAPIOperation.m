//
// CHAPIOperation.m
// Chicago
//
// Created by Brian Cooke on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHAPIOperation.h"
#import "CHVideoViewController.h"


@implementation CHAPIOperation

+ (CHAPIOperation *)operationToRetrieveCategoriesByParentCategoryID:(__unsafe_unretained NSString *)parentCategoryID {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveCategoriesByParentCategoryID:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&parentCategoryID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveProductsByCategoryID:(__unsafe_unretained NSString *)categoryID limit:(int)maximumNumberOfProductsToReturn {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveProductsByCategoryID:limit:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&categoryID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&maximumNumberOfProductsToReturn atIndex:3];
	[ret.invocation retainArguments];

	return ret;
}

+ (CHAPIOperation *)operationToRetrieveProductsByCategoryID:(__unsafe_unretained NSString *)categoryID page:(int)page itemsPerPage:(int)itemsPerPage {
    CHAPIOperation *ret = [[CHAPIOperation alloc] init];
    SEL             sel = @selector(retrieveProductsByCategoryID:page:itemsPerPage:);
        
    ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
    [ret.invocation setSelector:sel];
    [ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
    [ret.invocation setArgument:&categoryID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
    [ret.invocation setArgument:&page atIndex:3];
    [ret.invocation setArgument:&itemsPerPage atIndex:4];
    [ret.invocation retainArguments];
    
    return ret;
}


+ (CHAPIOperation *)operationToSearchForProductsWithFullText:(__unsafe_unretained NSString *)fullText limit:(int)maximumNumberOfProductsToReturn page:(int)pageNumber {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];

	// TODO implement limit and page in underlying API
	SEL sel = @selector(fullTextSearchForString:forPage:pageSize:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&fullText atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
  [ret.invocation setArgument:&pageNumber atIndex:3];
  [ret.invocation setArgument:&maximumNumberOfProductsToReturn atIndex:4];
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveProductByProductID:(__unsafe_unretained NSString *)productID {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveProductByProductID:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&productID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToViewProductContent:(__unsafe_unretained Product *)product {
    //NSLog(@"CHAPIOperation -operationToViewProductContent:");
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(viewProductContent:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&product atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToLoginWithLogin:(__unsafe_unretained NSString *)login password:(__unsafe_unretained NSString *)password {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(loginWithLogin:password:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&password atIndex:3];
	[ret.invocation retainArguments];

	return ret;
}

+ (CHAPIOperation *)operationToLogout {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(requestToLogout);
	
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation retainArguments];
	
	return ret;
}

+ (CHAPIOperation *)operationToRetrieveSubscriberInfo {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveSubscriberInfo);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];

	return ret;
}


+ (CHAPIOperation *)operationToCreateSubscriberWithLogin:(__unsafe_unretained NSString *)login email:(__unsafe_unretained NSString *)email firstName:(__unsafe_unretained NSString *)fname lastName:(__unsafe_unretained NSString *)lname password:(__unsafe_unretained NSString *)password challengeQuestion:(__unsafe_unretained NSString *)challengeQuestion challengeAnswer:(__unsafe_unretained NSString *)challengeAnswer {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(createSubscriberWithLogin:email:firstName:lastName:password:challengeQuestion:challengeAnswer:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&email atIndex:3];
	[ret.invocation setArgument:&fname atIndex:4];
	[ret.invocation setArgument:&lname atIndex:5];
	[ret.invocation setArgument:&password atIndex:6];
	[ret.invocation setArgument:&challengeQuestion atIndex:7];
	[ret.invocation setArgument:&challengeAnswer atIndex:8];

	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveCodes {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveCodes);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];

	return ret;
}


+ (CHAPIOperation *)operationToRegisterDevice {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(registerSubscriberDevice);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveChallengeQuestionForLogin:(__unsafe_unretained NSString *)login {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrievePasswordChallenge:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToResetPasswordForLogin:(__unsafe_unretained NSString *)login challengeResponse:(__unsafe_unretained NSString *)challengeResponse newPassword:(__unsafe_unretained NSString *)newPassword {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(resetPasswordForLogin:challengeResponse:newPassword:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&challengeResponse atIndex:3];
	[ret.invocation setArgument:&newPassword atIndex:4];
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToUpdateSubscriberWithCurrentPassword:(__unsafe_unretained NSString *)curPassword newLogin:(__unsafe_unretained NSString *)newLogin newPassword:(__unsafe_unretained NSString *)newPassword newChallengeQuestion:(__unsafe_unretained NSString *)newChallengeQuestion newChallengeResponse:(__unsafe_unretained NSString *)newChallengeResponse {
	__unsafe_unretained NSString       *subscriberID = [CDLockerAppDelegate sharedCDClient].subscriberID;
	CHAPIOperation *ret          = [[CHAPIOperation alloc] init];
	SEL             sel          = @selector(updateCredentialsForSubscriberId:currentPassword:newPassword:newLogin:newChallengeQuestion:newChallengeResponse:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&subscriberID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&curPassword atIndex:3];
	[ret.invocation setArgument:&newPassword atIndex:4];
	[ret.invocation setArgument:&newLogin atIndex:5];
	[ret.invocation setArgument:&newChallengeQuestion atIndex:6];
	[ret.invocation setArgument:&newChallengeResponse atIndex:7];
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToCalculateOrderQuoteForProduct:(__unsafe_unretained Product *)product paymentInstrument:(__unsafe_unretained PaymentInstrument *)paymentInstrument {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(calculateOrderQuoteForProduct:paymentInstrument:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&product atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&paymentInstrument atIndex:3];
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToSubmitOrderForProduct:(__unsafe_unretained Product *)product 
								   paymentInstrument:(__unsafe_unretained PaymentInstrument *)paymentInstrument{
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(submitOrderForProduct:paymentInstrument:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&product atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&paymentInstrument atIndex:3];
	[ret.invocation retainArguments];

	return ret;
}

+ (CHAPIOperation *)operationToSubmitOrderForProductWithItunes:(__unsafe_unretained Product *)product 
												   receiptCode:(__unsafe_unretained NSData *)receiptCode {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(submitOrderForProductWithItunes:receiptCode:);
	
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&product atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&receiptCode atIndex:3];
	[ret.invocation retainArguments];
	
	return ret;
}


+ (CHAPIOperation *)operationToGenerateNewPasswordForLogin:(__unsafe_unretained NSString *)login {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(sendNewPasswordForLogin:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToUpdateSubscriberEmail:(__unsafe_unretained NSString *)email firstName:(__unsafe_unretained NSString *)fname lastName:(__unsafe_unretained NSString *)lname {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(updateSubscriberWithId:email:firstName:lastName:);
  
  __unsafe_unretained NSString *subscriberID = [CDLockerAppDelegate sharedCDClient].subscriberID;
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&subscriberID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
  [ret.invocation setArgument:&email atIndex:3];
  [ret.invocation setArgument:&fname atIndex:4];
  [ret.invocation setArgument:&lname atIndex:5];
	[ret.invocation retainArguments];
  
	return ret;  
}


+ (CHAPIOperation *)operationToCreatePaymentInstrument:(__unsafe_unretained PaymentInstrument *)aPaymentInstrument {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(createPaymentInstrument:);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
  [ret.invocation setArgument:&aPaymentInstrument atIndex:2];
	[ret.invocation retainArguments];
  
	return ret;    
}


+ (CHAPIOperation *)operationToRemovePaymentInstrument:(__unsafe_unretained PaymentInstrument *)aPaymentInstrument {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(removePaymentInstrument:);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
  [ret.invocation setArgument:&aPaymentInstrument atIndex:2];
	[ret.invocation retainArguments];
  
	return ret;    
}


+ (CHAPIOperation *)operationToSendPing {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(sendPing);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];  
	return ret;  
}


+ (CHAPIOperation *)operationToRetrieveSubscriberProducts {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveSubscriberProducts);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	return ret;    
}

+ (CHAPIOperation *)operationToRetrieveFeaturedProducts {
    CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveFeaturedProducts);
    
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
    
	return ret;
}

+ (CHAPIOperation *)operationToUnregisterDeviceWithSubscriberID:(__unsafe_unretained NSString *)subscriberID {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(removeSubscriberDeviceWithSubscriberID:);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDLockerAppDelegate sharedCDClient] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDLockerAppDelegate sharedCDClient]];
	[ret.invocation setArgument:&subscriberID atIndex:2];
	[ret.invocation retainArguments];
  
	return ret;      
}




- (void)main
{
	if ([[self delegate] respondsToSelector:@selector(isKindOfClass:)]) {
		if ([[self delegate] isKindOfClass:[CHVideoViewController class]]) {
            CHVideoViewController *del = (CHVideoViewController *) [self delegate];
			[del petWatchdog];
		}
	}
	
	assert(self.delegate);
	[CDLockerAppDelegate sharedCDClient].delegate = self.delegate;
	[self.invocation invoke];
}


@synthesize delegate = ch_delegate, invocation = ch_invocation;
@end
