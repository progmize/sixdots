//
// CHBaseLoginRequiredViewController.h
// Chicago
//
// Created by Brian Cooke on 8/30/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CHBaseViewController.h"
#import "CHLoginViewController.h"
#import "NotLoggedInView.h"

@interface CHBaseLoginRequiredViewController : CHBaseViewController<CHLoginViewControllerDelegate, NotLoggedInViewDelegate> {}

@property (nonatomic, strong) NotLoggedInView * notLoggedInView;
@property (nonatomic, assign) BOOL     loggedInRequired;
@property (nonatomic, assign) BOOL     authenticatedRequired;

- (IBAction)login:(id)sender;
- (void)showLoggedInUI;

@end
