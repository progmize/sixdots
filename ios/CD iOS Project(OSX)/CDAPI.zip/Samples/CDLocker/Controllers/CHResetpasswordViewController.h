//
// CHResetpasswordViewController.h
// Chicago
//
// Created by Brian Cooke on 8/21/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"

@class MBProgressHUD;
@class TKLabelTextFieldCell;

@interface CHResetpasswordViewController : UITableViewController<CDClientDelegate, UITextFieldDelegate, UIAlertViewDelegate> {
  NSString             * ch_login;
  NSString             * ch_question;
  MBProgressHUD        * ch_progressHUD;
  TKLabelTextFieldCell * ch_answerCell;
  TKLabelTextFieldCell * ch_passwordCell;
  TKLabelTextFieldCell * ch_passwordConfirmationCell;
}

@property (nonatomic, strong) NSString             * login;
@property (nonatomic, strong) NSString             * question;
@property (nonatomic, strong) MBProgressHUD        * progressHUD;
@property (nonatomic, strong) TKLabelTextFieldCell * answerCell;
@property (nonatomic, strong) TKLabelTextFieldCell * passwordCell;
@property (nonatomic, strong) TKLabelTextFieldCell * passwordConfirmationCell;

- (id)initWithLogin:(NSString *)aLogin;
- (IBAction)resetPassword:(id)sender;
@end
