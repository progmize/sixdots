//
//  CachedContentViewController.h
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DACachedContent.h"


@interface CachedContentViewController : UIViewController
{
    NSURL *contentURL;
    DAContentType contentType;
    
    IBOutlet UILabel *contentURLLabel;
    IBOutlet UILabel *statusLabel;
    IBOutlet UILabel *cachedDurationLabel;
    IBOutlet UIProgressView *progressview;
	IBOutlet UIButton *startCachingButton;
	IBOutlet UIButton *stopCachingButton;
    IBOutlet UIButton *purgeCacheButton;
    
    DACachedContent *cachedContent;
}

// initialization method
- (id)initWithContentURL:(NSURL *)theContentURL ofType:(DAContentType)theContentType;

// button handlers
- (IBAction)startCaching:(id)sender;
- (IBAction)stopCaching:(id)sender;
- (IBAction)purgeCache:(id)sender;

@end
