//
// CHBaseViewController.m
// Chicago
//
// Created by louie on 8/13/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHBaseViewController.h"
#import "CHDetailsViewController.h"
#import "CHVideoViewController.h"

@implementation CHBaseViewController

@synthesize productToPurchase, libraryItem = ch_libraryItem, backgroundView = ch_backgroundView;

// Support all orientations
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return YES;
}

// Notifies when rotation begins, reaches halfway point and ends.
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [self showLogoBranding];
}

- (void)showLogoBranding {
    CDLockerAppDelegate * appDelegate = (CDLockerAppDelegate *)[CDLockerAppDelegate sharedAppDelegate];
    UIImage *logoImage = nil;  
    if (UIInterfaceOrientationIsPortrait([self interfaceOrientation])) {
        logoImage = [appDelegate logoImage];  
    } else {
        logoImage = [appDelegate landscapeLogoImage];  
    }
    if (logoImage != nil) {
        self.navigationItem.titleView = [[UIImageView alloc] initWithImage:logoImage];     
    }  
}


- (void)viewDidLoad {
    [self showCSGBranding];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    // Load the branding logo
    [self showLogoBranding];
}

- (void)showCSGBranding {
    // Show the CSG branding in upper right corner.
    UIImage *csgBrandingImage = [UIImage imageNamed:@"cd-logo.png"];
    
    //  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:csgBrandingImage style:UIBarButtonItemStyleBordered target:nil action:nil];  
    UIImageView *brandingImageView = [[UIImageView alloc] initWithImage:csgBrandingImage];
    UIBarButtonItem *brandingButtonItem = [[UIBarButtonItem alloc] initWithCustomView:brandingImageView];
    self.navigationItem.rightBarButtonItem = brandingButtonItem;
}


- (void)setBackgroundImage:(UIImage *)bgImage {
	self.backgroundView = [[UIImageView alloc] initWithImage:bgImage];
	//[self.backgroundView release]; // retained by the property
	
	self.backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	self.backgroundView.contentMode = UIViewContentModeScaleToFill;
	self.backgroundView.frame = self.view.bounds;
}


- (void)setBackgroundView:(UIImageView *)bgView {
	if (ch_backgroundView == bgView)
		return;
	
	[ch_backgroundView removeFromSuperview];
	ch_backgroundView = bgView;
	[self.view insertSubview:ch_backgroundView atIndex:0];
}


- (void)registerForImageCacheNotifications {
    // Register for ImageCache notifications
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(imageWasDownloaded:)
                                                 name:@"ImageDownloaded"
                                               object:nil];
}


- (void)unregisterForImageCacheNotifications {
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"ImageDownloaded" object:nil];
}


#pragma mark ImageCache notifications
- (void)imageWasDownloaded:(id)object {}





#pragma mark -
#pragma mark PurchaseProductDelegate

- (void)showLoginView {
    CHLoginViewController * loginVC = [[CHLoginViewController alloc] init];
    
    loginVC.delegate = self;
    UINavigationController * nc = [[UINavigationController alloc] initWithRootViewController:loginVC];
    
    [self presentModalViewController:nc animated:YES];
    
}


- (BOOL)loggedIn {
    return [[CDLockerAppDelegate sharedCDClient] loggedIn];
}


- (BOOL)authenticated {
    return [[CDLockerAppDelegate sharedCDClient] authenticated];
}


- (void)purchaseProduct:(Product *)product 
{
    //NSLog(@"CHBaseViewController -purchaseProduct:%@", product.name);
    self.productToPurchase = product;
	
	NSLog(@"product: %@ product.pricingPlanID: %@", product, product.pricingPlanID);
    
	// Content is free or the user owns the product
    if ([product isFree] || [[CDLockerAppDelegate sharedCDClient] doesUserOwnProduct:product])
	{
		// Authenticated and ... (not sure what pricing plan 1832 is)
		if ([product.pricingPlanID isEqualToString:@"1832"] && ![self authenticated]) 
		{
			NSLog(@"Purchase prod: Pricing plan 1832 and authenticated");
            //NSLog(@"productToView1 = %@", product);
			CHLoginViewController *loginVC = [[CHLoginViewController alloc] init];
			UINavigationController * nc = [[UINavigationController alloc] initWithRootViewController:loginVC];
			loginVC.delegate = self;
			[self.navigationController presentModalViewController:nc animated:YES];
			return;
		}
		
		NSLog(@"Purchase prod: Free or user owns the prod");
		NSLog(@"Free? %@", [product isFree]?@"Yes":@"No");
		NSLog(@"User owns? %@", [[CDLockerAppDelegate sharedCDClient] doesUserOwnProduct:product]?@"Yes":@"No");
		
		// Otherwise view the product
        CHVideoViewController * videoVC = [[CHVideoViewController alloc] init];
        videoVC.product = product;
        //NSLog(@"productToView2 = %@", product);
        [self.navigationController dismissModalViewControllerAnimated:NO];
        [self.navigationController presentModalViewController:videoVC animated:YES];
    } 
	else // Otherwise they need to login or purchase the product 
	{
		NSLog(@"Purchase prod: Login or purchase");
        if ([self authenticated]) // If they are authenticated (and logged in - this happes by default if authed)
		{
            /* taking out cause no purchasing
            // Show confirm purchase - modal view controller
			if ([CDLockerAppDelegate sharedCDClient].enableInAppPurchase) // If in app purchase is enabled
			{
				NSLog(@"Purchase prod: Auth'd & purchase enabled");
				CHConfirmInAppPurchaseViewController * confirmPurchaseViewController = [[CHConfirmInAppPurchaseViewController alloc] init];
				confirmPurchaseViewController.product  = product;
				confirmPurchaseViewController.delegate = self;
				// Hide tab bar to make the view more modal.
				[confirmPurchaseViewController setHidesBottomBarWhenPushed:YES];            
				[self.navigationController pushViewController:confirmPurchaseViewController animated:YES];            
				// Reset text field
				[confirmPurchaseViewController reset];            
			}
			else // In-app purchase is not enabled
			{
				NSLog(@"Purchase prod: Auth'd & purchase NOT enabled");
				CHConfirmPurchaseViewController * confirmPurchaseViewController = [[CHConfirmPurchaseViewController alloc] init];
				confirmPurchaseViewController.product  = product;
				confirmPurchaseViewController.delegate = self;
				// Hide tab bar to make the view more modal.
				[confirmPurchaseViewController setHidesBottomBarWhenPushed:YES];            
				[self.navigationController pushViewController:confirmPurchaseViewController animated:YES];            
				// Reset text field
				[confirmPurchaseViewController reset];            
			}*/

        } 
		else // Let them know they need to log in
		{
			NSLog(@"Purchase prod: NOT Auth'd -> login please.");
            // Save the product
            [self showLoginView];
        }
    }
}


- (void)showDetailsForProduct:(Product *)product {
    CHDetailsViewController * detail = [[CHDetailsViewController alloc] init];
    
    detail.product = product;
    [self.navigationController pushViewController:detail animated:YES];
}


#pragma mark -
#pragma mark CHLoginViewControllerDelegate
- (void)loginCompletedWithLogin:(NSString *)login password:(NSString *)password {
    if (self.productToPurchase) {
        [self purchaseProduct:self.productToPurchase];
    }
}


#pragma mark -
#pragma mark CHConfirmPurchaseViewControllerDelegate
- (void)userPurchasedAndWantsToViewProduct:(Product *)product {
    // Show the video player view.
    CHVideoViewController * videoVC = [[CHVideoViewController alloc] init];
    videoVC.product = product;
    [self.navigationController presentModalViewController:videoVC animated:YES];
}



@end
