//
//  Fault.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "Fault.h"
#import <UIKit/UIPasteboard.h>

@implementation Fault

@synthesize typeName;
@synthesize message;
@synthesize displayMessage;
@synthesize details;



- (NSString *)description {
  return [NSString stringWithFormat:@"Fault type:%@ message:%@", self.typeName, self.message];
}


+ (void) showWithTitle:(NSString *)aTitle andMessage:(NSString *)aMessage {
  UIAlertView *av = [[UIAlertView alloc] initWithTitle:aTitle message:aMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
  [av show];
}


+ (void) showWithTitle:(NSString *)aTitle andMessage:(NSString *)aMessage andFault:(Fault *)aFault {
   // we're the delegate
  UIAlertView *av = [[UIAlertView alloc] initWithTitle:aTitle message:aMessage delegate:aFault cancelButtonTitle:@"OK" otherButtonTitles:NSLocalizedString(@"MESSAGE_POPUP_DETAILS_BUTTON_TEXT", @"Details"), nil];
  [av show];
}


- (void) showWithTitle:(NSString *)aTitle {
   // we're the delegate
  UIAlertView *av = [[UIAlertView alloc] initWithTitle:aTitle message:[self displayMessage] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:NSLocalizedString(@"MESSAGE_POPUP_DETAILS_BUTTON_TEXT", @"Details"), nil];
  [av show];
}


- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
  if (buttonIndex == 1) {
    // copy the details to the clipboard
    [UIPasteboard generalPasteboard].string = self.details;//] setValue:self.details forPasteboardType:@"public.utf8-plain-text"];
    
    UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Details copied to clipboard" message:self.details delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [av show];
  }
}


- (BOOL) isSessionTimeout {
  if ([self.typeName rangeOfString:@"SessionExpired"].location != NSNotFound ||
      [self.typeName rangeOfString:@"AccessDenied"].location != NSNotFound) {
    return YES;
  }
  return NO;
}


- (BOOL) isAccessDenied {
  if ([self.typeName rangeOfString:@"AccessDenied"].location != NSNotFound) {
    return YES;
  }
  return NO;  
}


- (BOOL) isAccessToContentDenied {
  if ([self.typeName rangeOfString:@"ContentAccessLimitExceeded"].location != NSNotFound ||
      [self.typeName rangeOfString:@"ContentTimeLimitExceeded"].location != NSNotFound ||
      [self.typeName rangeOfString:@"ContentLicenseLimitExceeded"].location != NSNotFound) {
    return YES;
  }
  return NO;    
}

@end
