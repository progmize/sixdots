//
//  ImageCachingOperation.m
//  Chicago
//
//  Created by louie on 8/12/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "ImageCachingOperation.h"
#import "ImageCache.h"
#import <UIKit/UIKit.h>
#import "UIImage-Resizing.h"

@implementation ImageCachingOperation

@synthesize imageURL;


- (id)init {
  return [self initScaled:NO];
}

- (id)initScaled:(BOOL)shouldScale {
    if ((self = [super init])) {
      ch_shouldScale = shouldScale;
    }
    return self;
}

- (void)main {
  // Download image
  NSData *receivedData = [NSData dataWithContentsOfURL:self.imageURL];
  UIImage *image = [[UIImage alloc] initWithData:receivedData];

  UIImage *resized;
  if (ch_shouldScale) {
    [[UIDevice currentDevice] model];
    CGSize theSizeToAdjustTo = CGSizeMake(75., 105.);
    if ([[UIScreen mainScreen] respondsToSelector:@selector(scale)]){
      theSizeToAdjustTo.width *= [[UIScreen mainScreen] scale];
      theSizeToAdjustTo.height *= [[UIScreen mainScreen] scale];
    }
    resized = [UIImage imageWithImage:image scaledToSize:theSizeToAdjustTo];
  } else {
    resized = image;
  }
  [[ImageCache sharedImageCache] storeImage:resized forURL:self.imageURL];
}

@end
