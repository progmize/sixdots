//
// CHBrowseViewController.h
// Chicago
//
// Created by Brian Cooke on 8/2/10.
// Copyright 2010 Push.IO Inc, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"
#import "CHFeaturedCell.h"
#import "PurchasProductDelegate.h"
#import "CHBaseViewController.h"
#import "CHSplash.h"

@class MBProgressHUD;

@interface CHBrowseViewController : CHBaseViewController <CDClientDelegate, CHFeaturedCellDataSource, PurchasProductDelegate> 
{
	NSArray *ch_productCategories;
	UITableView *ch_tableView;
	NSArray *ch_featuredProducts;	
	CHFeaturedCell *ch_featuredCell;
	CHSplash *ch_splash;
}

@property (nonatomic, strong) CHSplash *splash;
@property (nonatomic, strong) NSArray *productCategories;
@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (nonatomic, copy) NSArray *featuredProducts;

- (void) showFeaturedItems;

@end
