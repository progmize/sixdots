//
//  CDServiceFacade.h
//  ContentDirectAPI
//
//  Created by Brandon on 2/21/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CDServiceFacade.h"
#import "CDClient.h"
#import "CDServiceFacadeDelegate.h"
#import "CDExceptionDelegate.h"
#import "Reachability.h"

@interface CDServiceFacade : NSObject<CDClientDelegate, CDExceptionDelegate> {
    CDClient        *cdClient;
    NSDictionary    *codeTypesToCodes;
    
    Reachability    *internetReachable;
    Reachability    *hostReachable;
}
- (BOOL)enableInAppPurchase;
- (BOOL)isAuthenticated; // able to purchase


@property (nonatomic, strong) CDClient *cdClient;
@property (nonatomic) BOOL internetConnected;
@property (nonatomic) BOOL connectMessageDisplayed;

+ (CDClient *)sharedCDClient;
+ (CDServiceFacade *)sharedCDServiceFacade;

- (NSArray *)passwordChallengeCodes;
- (NSArray *)ratingCodes;

- (void) checkNetworkStatus:(NSNotification *)notice;
- (void) showConnectionMessage;

- (BOOL) isAuthenticated;
@end
