//
//  Fault.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Fault : NSObject<UIAlertViewDelegate> {
  NSString *typeName;
  NSString *message;
  NSString *displayMessage;
  NSString *details;
}

@property (copy) NSString *typeName;
@property (copy) NSString *message;
@property (copy) NSString *displayMessage;
@property (copy) NSString *details;

+ (void) showWithTitle:(NSString *)aTitle andMessage:(NSString *)aMessage;
+ (void) showWithTitle:(NSString *)aTitle andMessage:(NSString *)aMessage andFault:(Fault *)aFault;
- (void) showWithTitle:(NSString *)aTitle;
- (BOOL) isSessionTimeout;
- (BOOL) isAccessDenied;
- (BOOL) isAccessToContentDenied;
@end
