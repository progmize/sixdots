//
// PaymentInstrument.m
// ContentDirect POX API
//
// Created by Luis de la Rosa on 8/2/10.
// Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "PaymentInstrument.h"
#import "OrderedDictionary.h"

@implementation PaymentInstrument

@synthesize paymentInstrumentID;
@synthesize nickname;
@synthesize status;
@synthesize instrumentType;
@synthesize wcc_accountNumber;
@synthesize wcc_cardType;
@synthesize wcc_cvv;
@synthesize wcc_expirationMonth;
@synthesize wcc_expirationYear;
@synthesize wcc_isVerified;
@synthesize wcc_nameOnCard;
@synthesize wcc_phoneNumber;

@synthesize wcc_ba_city;
@synthesize wcc_ba_country;
@synthesize wcc_ba_id;
@synthesize wcc_ba_lineOne;
@synthesize wcc_ba_lineTwo;
@synthesize wcc_ba_nickname;
@synthesize wcc_ba_phoneNumber;
@synthesize wcc_ba_state;
@synthesize wcc_ba_zip;

@synthesize wsva_accountNumber;
@synthesize wsva_adminOverride;
@synthesize wsva_brandableCurrency;
@synthesize wsva_currentBalance;
@synthesize wsva_initialAmount;
@synthesize wsva_isChargeable;
@synthesize wsva_loyaltyPointsCard;
@synthesize wsva_rechargeAmount;
@synthesize wsva_rechargeType;




- (NSString *)description {
  NSString * ret = [NSString stringWithFormat:@"PaymentInstrument ID:%@ nickname:%@ status:%@ type:%@", self.paymentInstrumentID, self.nickname, self.status, self.instrumentType];

  if ([self.instrumentType isEqualToString:@"CreditCard"]) {
    ret = [ret stringByAppendingFormat:@" accountNumber:%@\nAddress[%@]:%@\n%@\n%@\n%@, %@ %@ %@\nPhone:%@\nCard type:%@\nExpiration:%@\%@\nVerified:%@\nName:%@\nPhone:%@", self.wcc_accountNumber,
           self.wcc_ba_id, self.wcc_ba_nickname,
           self.wcc_ba_lineOne, self.wcc_ba_lineTwo, self.wcc_ba_city, self.wcc_ba_state, self.wcc_ba_zip, self.wcc_ba_country, self.wcc_ba_phoneNumber,
           self.wcc_cardType,
           self.wcc_expirationMonth, self.wcc_expirationYear,
           self.wcc_isVerified,
           self.wcc_nameOnCard,
           self.wcc_phoneNumber
          ];
  }

  return ret;
}


+ (PaymentInstrument *)paymentInstrumentFromDictionary:(NSDictionary *)paymentInstrumentDictionary {
  NSString * paymentInstrumentID       = [paymentInstrumentDictionary objectForKey:@"Id"];
  NSString * paymentInstrumentNickname = [paymentInstrumentDictionary objectForKey:@"Nickname"];

  NSDictionary * detailDictionary         = [paymentInstrumentDictionary objectForKey:@"Detail"];
  NSDictionary * billingAddressDictionary = [detailDictionary objectForKey:@"BillingAddress"];

  PaymentInstrument * paymentInstrument = [[PaymentInstrument alloc] init];

  paymentInstrument.paymentInstrumentID = paymentInstrumentID;
  paymentInstrument.nickname            = paymentInstrumentNickname;

  paymentInstrument.status         = [paymentInstrumentDictionary objectForKey:@"Status"];
  paymentInstrument.instrumentType = [paymentInstrumentDictionary objectForKey:@"Type"];

  if ([paymentInstrument.instrumentType isEqualToString:@"CreditCard"]) {
    paymentInstrument.wcc_accountNumber = [detailDictionary objectForKey:@"AccountNumber"];
    paymentInstrument.wcc_ba_city       = [billingAddressDictionary objectForKey:@"City"];
    paymentInstrument.wcc_ba_country    = [billingAddressDictionary objectForKey:@"CountryAbbreviation"];
    paymentInstrument.wcc_ba_id         = [billingAddressDictionary objectForKey:@"Id"];
    paymentInstrument.wcc_ba_lineOne    = [billingAddressDictionary objectForKey:@"LineOne"];
    // TODO ensure we handle nil
    paymentInstrument.wcc_ba_lineTwo     = [billingAddressDictionary objectForKey:@"LineTwo"];
    paymentInstrument.wcc_ba_nickname    = [billingAddressDictionary objectForKey:@"Nickname"];
    paymentInstrument.wcc_ba_phoneNumber = [billingAddressDictionary objectForKey:@"PhoneNumber"];
    paymentInstrument.wcc_ba_state       = [billingAddressDictionary objectForKey:@"StateProvinceRegionAbbreviation"];
    paymentInstrument.wcc_ba_zip         = [billingAddressDictionary objectForKey:@"ZipPostalCode"];

    paymentInstrument.wcc_cardType        = [detailDictionary objectForKey:@"CardType"];
    paymentInstrument.wcc_expirationMonth = [detailDictionary objectForKey:@"ExpirationMonth"];
    paymentInstrument.wcc_expirationYear  = [detailDictionary objectForKey:@"ExpirationYear"];
    paymentInstrument.wcc_isVerified      = [detailDictionary objectForKey:@"IsVerified"];
    paymentInstrument.wcc_nameOnCard      = [detailDictionary objectForKey:@"NameOnCard"];

    // TODO figure out if this is the same as wcc_ba_phoneNumber?
    paymentInstrument.wcc_phoneNumber = [detailDictionary objectForKey:@"PhoneNumber"];
  } else if ([paymentInstrument.instrumentType isEqualToString:@"StoredValueAccount"]) {
    paymentInstrument.wsva_accountNumber     = [detailDictionary objectForKey:@"AccountNumber"];
    paymentInstrument.wsva_adminOverride     = [detailDictionary objectForKey:@"AdminOverride"];
    paymentInstrument.wsva_brandableCurrency = [detailDictionary objectForKey:@"BrandableCurrency"];
    paymentInstrument.wsva_currentBalance    = [detailDictionary objectForKey:@"CurrentBalance"];
    paymentInstrument.wsva_initialAmount     = [detailDictionary objectForKey:@"InitialAmount"];
    paymentInstrument.wsva_isChargeable      = [detailDictionary objectForKey:@"IsChargeable"];
    paymentInstrument.wsva_loyaltyPointsCard = [detailDictionary objectForKey:@"LoyaltyPointsCard"];
    paymentInstrument.wsva_rechargeAmount    = [detailDictionary objectForKey:@"RechargeAmount"];
    paymentInstrument.wsva_rechargeType      = [detailDictionary objectForKey:@"RechargeType"];
  }

  return paymentInstrument;
}


- (NSDictionary *)toDictionaryWithSubscriberID:(NSString *)subscriberID {
  OrderedDictionary * paymentInstrumentDictionary = [[OrderedDictionary alloc] init];
  NSString          * fake                        = [NSString stringWithFormat:@"Demo - TBD_%f", [[NSDate date] timeIntervalSince1970]];

  if ([self.nickname length] == 0) {
    if (self.wcc_cardType && [self.wcc_accountNumber length] > 0) {
      self.nickname = [NSString stringWithFormat:@"%@ %@", self.wcc_cardType, [self.wcc_accountNumber substringFromIndex:[self.wcc_accountNumber length] - 4]];
    } else {
      self.nickname = fake;
    }
  }

  if ([self.wcc_ba_nickname length] == 0) {
    self.wcc_ba_nickname = self.wcc_ba_lineOne;
  }

  if ([self.wcc_ba_phoneNumber length] == 0) {
    self.wcc_ba_phoneNumber = @"6035551234";
  }
  
  if (self.paymentInstrumentID) {
    [paymentInstrumentDictionary setObject:self.paymentInstrumentID forKey:@"Id"];
  }

  [paymentInstrumentDictionary setObject:self.nickname forKey:@"Nickname"];
  [paymentInstrumentDictionary setObject:subscriberID forKey:@"SubscriberId"];
  [paymentInstrumentDictionary setObject:self.instrumentType forKey:@"Type"];


  if ([self.instrumentType isEqualToString:@"CreditCard"] || [self.instrumentType isEqualToString:@"Credit Card"]) {
    OrderedDictionary * workaroundCreditCardDictionary = [[OrderedDictionary alloc] init];
    [workaroundCreditCardDictionary setObject:self.wcc_accountNumber forKey:@"AccountNumber"];

    OrderedDictionary * billingAddressDictionary = [[OrderedDictionary alloc] init];
    [billingAddressDictionary setObject:self.wcc_ba_city forKey:@"City"];
    [billingAddressDictionary setObject:self.wcc_ba_country forKey:@"CountryAbbreviation"];

    if (self.wcc_ba_id) {
      [billingAddressDictionary setObject:self.wcc_ba_id forKey:@"Id"];
    }

    [billingAddressDictionary setObject:self.wcc_ba_lineOne forKey:@"LineOne"];

    if (self.wcc_ba_lineTwo != nil) {
      [billingAddressDictionary setObject:self.wcc_ba_lineTwo forKey:@"LineTwo"];
    }

    [billingAddressDictionary setObject:self.wcc_ba_nickname forKey:@"Nickname"];
    [billingAddressDictionary setObject:self.wcc_ba_phoneNumber forKey:@"PhoneNumber"];
    [billingAddressDictionary setObject:self.wcc_ba_state forKey:@"StateProvinceRegionAbbreviation"];
    [billingAddressDictionary setObject:subscriberID forKey:@"SubscriberId"];
    [billingAddressDictionary setObject:self.wcc_ba_zip forKey:@"ZipPostalCode"];
    [workaroundCreditCardDictionary setObject:billingAddressDictionary forKey:@"BillingAddress"];
    [workaroundCreditCardDictionary setObject:self.wcc_cardType forKey:@"CardType"];

    if (self.wcc_cvv) {
      [workaroundCreditCardDictionary setObject:self.wcc_cvv forKey:@"Cvv"];
    }

    [workaroundCreditCardDictionary setObject:self.wcc_expirationMonth forKey:@"ExpirationMonth"];
    [workaroundCreditCardDictionary setObject:self.wcc_expirationYear forKey:@"ExpirationYear"];

    if (self.wcc_isVerified) {
      [workaroundCreditCardDictionary setObject:self.wcc_isVerified forKey:@"IsVerified"];
    }

    [workaroundCreditCardDictionary setObject:self.wcc_nameOnCard forKey:@"NameOnCard"];
    [workaroundCreditCardDictionary setObject:self.wcc_ba_phoneNumber forKey:@"PhoneNumber"];

    [paymentInstrumentDictionary setObject:workaroundCreditCardDictionary forKey:@"WorkaroundCreditCard"];
    
  } else if ([self.instrumentType isEqualToString:@"StoredValueAccount"]) {
    OrderedDictionary * svaDictionary = [[OrderedDictionary alloc] init];
    [svaDictionary setObject:self.wsva_accountNumber forKey:@"AccountNumber"];
    [svaDictionary setObject:self.wsva_adminOverride forKey:@"AdminOverride"];
    [svaDictionary setObject:self.wsva_currentBalance forKey:@"CurrentBalance"];
    [svaDictionary setObject:self.wsva_initialAmount forKey:@"InitialAmount"];
    [svaDictionary setObject:self.wsva_isChargeable forKey:@"IsChargeable"];
    [svaDictionary setObject:self.wsva_loyaltyPointsCard forKey:@"LoyaltyPointsCard"];
    [svaDictionary setObject:self.wsva_rechargeAmount forKey:@"RechargeAmount"];
    [svaDictionary setObject:self.wsva_rechargeType forKey:@"RechargeType"];
    
    [paymentInstrumentDictionary setObject:svaDictionary forKey:@"WorkaroundStoredValueAccount"];
  }

  return paymentInstrumentDictionary;
}


- (NSString *) cardTypeShortName {
  if ([[self.wcc_cardType lowercaseString] isEqualToString:@"americanexpress"]) {
    return @"Amex";
  } else {
    return self.wcc_cardType;
  }
}
@end
