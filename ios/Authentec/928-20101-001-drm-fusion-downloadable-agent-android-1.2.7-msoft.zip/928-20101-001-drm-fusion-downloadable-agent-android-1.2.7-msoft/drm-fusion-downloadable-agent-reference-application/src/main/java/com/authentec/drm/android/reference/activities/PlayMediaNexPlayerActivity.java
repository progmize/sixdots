package com.authentec.drm.android.reference.activities;

import java.io.File;
import java.net.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

import android.app.Dialog;
import android.content.*;
import android.content.pm.ActivityInfo;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.authentec.drm.android.reference.*;
import com.authentec.drm.android.reference.ContentHandler;
import com.authentec.drmagent.v2.*;
import com.nextreaming.nexplayerengine.*;

import android.util.Log;

/**
 * Main activity for rendering video.  This handles both license acquisition and content playback.
 *
 * @author AuthenTec Inc.
 */
public class PlayMediaNexPlayerActivity extends AbstractNexPlayerActivity implements SurfaceHolder.Callback, NexPlayer.IListener
{
    private static final String TAG = "PlayMediaNexPlayerActivity";

    /**
     * Defines the buffering times used  by the NexPlayer (in milliseconds).
     */
    public static final int RE_BUFFERING_TIME = 10000;
    public static final int INITIAL_BUFFERING_TIME = 5000;
    public static final int BUFFERING_TIME = 5000;

    // Defines the tolerance (in seconds) before a warning is reported about 'skips' in the playback
    public static final int SKIP_TOLERANCE = 1;

    /*

     */
    private NexPlayerGuard mNexPlayerGuard;

    /**
     * Holds the start time of this activity.  Used for printing debugging information (duration of operations since
     * start of the activity.
     */
    private long mStartTime;

    /**
     * Holds the current play time - how much of the stream has been played
     */
    public int mPlayingTime;

    /**
     * Holds the duration of the current stream - e.g. how long the clip is
     */
    public int mContentDuration;

    /**
     * Holds the amount of content (in milliseconds) currently in the buffer.
     */
    public int mBufferedTime;

    /**
     * Maintains the current surface width/height - mainly used for re-sizing operations
     */
    private int mSurfaceWidth = 0;
    private int mSurfaceHeight = 0;

    /**
     * Maintains the current video width/height - mainly used for re-sizing operations
     */
    private int mVideoWidth = 0;
    private int mVideoHeight = 0;

    /**
     * Holds the URI of the current clip
     */
    private URI mUri;

    private SurfaceHolder mSurfaceHolder;

    /**
     * Maintains the wake locks for the screen -this prevents the screen from turning off during play
     */
    private PowerManager.WakeLock mWakeLock = null;
    private PowerManager.WakeLock mDimLock = null;

    /** */
    public static final Handler mHandler = new Handler();

    /** */
    private DRMContentInfo mDRMContentInfo;

    private ImageButton mButtonPlayPause;
    private SeekBar mSeekBar;
    private boolean mSeekBarTracking = false;
    private int mDesiredPosition = -1;
    private TextView mStatusText;
    private LinearLayout mControlPanelLinearLayout;

    private NexContentInformation mCurrentNexContentInformation;
    private PowerManager mPowerManager;

    private ImageView mNoAudioImageView;
    private boolean mActive;
    private int mColorDepth = 4;
    private int mScreenPixelFormat;

    private Bitmap mFrameBitmap = null;
    private Paint mPaint = null;
    public int mTop;
    public int mLeft;
    public int mFullSizeWidth;
    public int mFullSizeHeight;

    private Intent mLastIntent;
    private boolean mUseOpenGL = false;
    private GLRenderer mGLRenderer;

    private boolean mShowSubtitles = true;

    public static final int ERROR_REPORTED = 1;
    private Dialog mErrorDialog;


    @Override
    protected void onCreate(final Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        if(getLockScreenLandscape())
        {
            this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }

        mPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (!mPowerManager.isScreenOn())
        {
            Log.i(TAG, "Received onCreate & screen if off, will reset state");
            mNexPlayerGuard = null;
            return;
        }

        setContentView(getContentView());

        // Extract the information about the display in order to setup the pixel format & color depth.
        final Display display = ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        final int devicePixelFormat = display.getPixelFormat();

        Log.d(TAG, String.format("PixelFormat: %d", devicePixelFormat));

        mColorDepth = 4;
        switch (devicePixelFormat)
        {
            case PixelFormat.RGBA_8888:
            case PixelFormat.RGBX_8888:
            case PixelFormat.RGB_888:
            case 5:
                mScreenPixelFormat = PixelFormat.RGBA_8888;
                mColorDepth = 1;
                Log.d(TAG, "888 : DevicePixelFormat:" + devicePixelFormat + "  ScreenPixelFormat:" + mScreenPixelFormat);
                break;
            default:
                mScreenPixelFormat = PixelFormat.RGB_565;
                Log.d(TAG, "565 : DevicePixelFormat:" + devicePixelFormat + "  ScreenPixelFormat:" + mScreenPixelFormat);
        }

        if (Build.MODEL.equals("Milestone"))
        {
            Log.d(TAG, "Detected Motorola Droid/Milestone, forcing pixel fromat RGB_565");
            mScreenPixelFormat = PixelFormat.RGB_565;
        }


    }

    protected boolean getLockScreenLandscape()
    {
        final SharedPreferences authentec = this.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        return authentec.getBoolean(Constants.PREFERENCES_LOCK_SCREEN_TO_LANDSCAPE_MODE_FOR_NEXPLAYER, true);
    }

    @Override
    protected void onResume()
    {
        super.onResume();

        // This captures the last intent which caused this activity to show
        mLastIntent = getIntent();

        mStartTime = System.currentTimeMillis();

        mWakeLock = mPowerManager.newWakeLock(PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "AuthenTec");
        mDimLock = mPowerManager.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK, "AuthenTec");

        Log.d(TAG, "Locks acquired, now locking: " + getElapsedTime());

        mWakeLock.acquire();
        mDimLock.acquire();

        Log.d(TAG, "Resuming activity: " + getElapsedTime());

        initializePlay();
        mActive = true;

        Log.d(TAG, "Registering HDMI broadcast receiver");
        DRMAgentDelegate.addHDMIBroadcastReceiver(getBaseContext());



    }

    private void initializePlay()
    {
        Log.d(TAG, "Initializing play: " + getElapsedTime());

        try
        {
            Log.d(TAG, "Retrieving screen locks et al: " + getElapsedTime());

            final Intent lastIntent = getIntent();
            Bundle extras = lastIntent.getExtras();
            if (getIntent().getStringExtra("CUSTOM_URL") != null)
            {
                final URI uri = URI.create(extras.getString(Constants.CUSTOM_URL));
                mDRMContentInfo = ContentHandler.createDRMContentInfoForUnknownURI(this, uri);
            }
            else
            {
                String selectedContentIdentifier = extras.getString(Constants.DESCRIPTOR_LOCATION);
                mDRMContentInfo = ContentHandler.parseAsXML(this, new File(selectedContentIdentifier), true, true);
            }

            // set the HDMI client control mode
            mDRMContentInfo.mDRMContent.setHDMIControl(HDMIControl.DEFAULT);

            mUri = mDRMContentInfo.mContentLocation;
            Log.d(TAG, "Opening content: " + mUri);

            // This checks whether or not the Agent has rights for the content in question.  This check will
            // verify both if the content is clear-text or protected & rights exists
            if (ContentHandler.hasRights(mDRMContentInfo))
            {

                if (ContentHandler.isClearText(mDRMContentInfo))
                {
                    Log.d(TAG, "Content is clear-text, initiating initialization: " + getElapsedTime());
                }
                else
                {
                    Log.d(TAG, "Rights available, initiating initialization: " + getElapsedTime());

                    // Register with the DRM Agent to receive any errors that occur during playback
                    // This allows the application to handle the case where the license expires
                    // during playback or the clock has been tampered with
                    DRMAgentDelegate.addDRMCallbackListener(this, new AbstractDRMCallbackListener()
                    {
                        public void errorReceived(final DRMError drmError, final URI uri)
                        {
                            Log.w(TAG, "Received error from the DRM agent: " + drmError);

                            // Always stop the player in this case to prevent further callbacks from it
                            if (mNexPlayerGuard.isPlaying())
                            {
                                mNexPlayerGuard.stop();
                            }

                            Intent intent = new Intent(getBaseContext(), getLicenseAcquisitionActivityClass());
                            intent.putExtra("DESCRIPTOR_LOCATION", mDRMContentInfo.mContentDescriptorLocation);
                            intent.putExtra("DRM_ERROR", drmError.name());
                            intent.putExtra("startFrom", Integer.valueOf(mPlayingTime));
                            startActivity(intent);
                            finish();
                        }
                    });


                }

                // Retrieve the NexPlayerGuard instance to use to play the content in question
                mNexPlayerGuard = NexPlayerHandler.getNexPlayerGuard(this, mColorDepth);

                if (mNexPlayerGuard.GetRenderMode() == 0 ||  mNexPlayerGuard.GetRenderMode() == NexPlayer.NEX_USE_RENDER_OPENGL)
                {
                    mUseOpenGL = true;
                }


                if (mUseOpenGL)
                {
                    if (mGLRenderer == null)
                    {
                        mGLRenderer = new GLRenderer(this, mNexPlayerGuard.getNexPlayerInstance(), new GLRenderer.IListener()
                        {
                            public void onGLChangeSurfaceSize(final int width, final int height)
                            {
                                Log.d(TAG, "onGLChangeSurfaceSize: w=" + width + "; h=" + height);
                                mSurfaceHeight = height;
                                mSurfaceWidth = width;
                                //not sure if needed ???
                                //if (mNexPlayerGuard != null)
                                //{
                                //    mNexPlayerGuard.getNexPlayerInstance().GLInit(width, height);
                                //}
                                //float scale = Math.min((float) mSurfaceWidth / (float) mVideoWidth, (float) mSurfaceHeight / (float) mVideoHeight);
                                float scale = (float) mSurfaceWidth / (float) mVideoWidth;
                                int w = (int) (mVideoWidth * scale);
                                int h = (int) (mVideoHeight * scale);
                                int top = (mSurfaceHeight - h) / 2;
                                int left = (mSurfaceWidth - w) / 2;

                                Log.d(TAG, "GLSurface - FILLSCREEN : " + left + " " + top + " " + w + " " + h + " ");
                                Log.d(TAG, "Surface Width : " + mSurfaceWidth + " SurfaceHeight : " + mSurfaceHeight);
                                mNexPlayerGuard.setOutputPos(left, top, w, h);
                    // do we really need this???
//                                // if openGL mode and pause state, app have to call request render for redrawing.
//                                    mGLRenderer.requestRender();
                            }
                        }, 4);

                        final int relativeLayoutID = getRelativeLayout();
                        FrameLayout view = (FrameLayout) findViewById(relativeLayoutID);
                        view.addView(mGLRenderer);
                        view.setVisibility(View.VISIBLE);
                        view.setOnClickListener(new View.OnClickListener()
                        {
                            public void onClick(final View view)
                            {
                                mControlPanelLinearLayout.setVisibility(mControlPanelLinearLayout.isShown() ? View.INVISIBLE : View.VISIBLE);
                            }
                        });
                        // Setup a long click listener on the view - this allows the application to produce a Toast pop-up
                        // which display content related information - track, bit-rates, etc
                        view.setLongClickable(true);
                        view.setOnLongClickListener(getLongClickListener());
                    }
                    mGLRenderer.onResume();
                }

                Log.d(TAG, "NexPlayerGuard acquired in state: " + NexUtils.toStateStr(mNexPlayerGuard.getState()) + " (" + getElapsedTime() + ")");

                // If the content is not clear text (i.e. it has been protected) it must first be opened in order
                // to establish the correct internal bindings between the DRM agent and the player
                if (!ContentHandler.isClearText(mDRMContentInfo))
                {
                    Log.d(TAG, "Opening DRM protected content: " + getElapsedTime());
                    final CyclicBarrier cyclicBarrier = new CyclicBarrier(2);
                    final AtomicBoolean errorSignaled = new AtomicBoolean(false);
                    Thread t = new Thread(new Runnable()
                    {
                        public void run()
                        {
                            try
                            {
                                mUri = mDRMContentInfo.mDRMContent.open();
                            }
                            catch (Exception e)
                            {
                                Log.e(TAG, "Error opening content: " + e.getMessage(), e);
                                errorSignaled.set(true);
                            }

                            try
                            {
                                cyclicBarrier.await();
                            }
                            catch (Exception e)
                            {
                                Log.e(TAG,"Error while signalling main thread");
                            }

                        }
                    });
                    t.start();
                    cyclicBarrier.await();

                    if (!errorSignaled.get())
                    {
                        Log.d(TAG, "DRM Content opened: " + getElapsedTime());
                    }
                    else
                    {
                        // Error opening content - say so!
                        reportError("Error opening content: ");
                    }
                }

                getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

                // Setup video rendering view
                SurfaceView surfaceView = (SurfaceView) findViewById(getSurfaceView());
                surfaceView.setClickable(true);

                // Setup a click listener which will allow the user to show/hide the scrubber and play controls
                surfaceView.setOnClickListener(new View.OnClickListener()
                {
                    public void onClick(final View view)
                    {
                        mControlPanelLinearLayout.setVisibility(mControlPanelLinearLayout.isShown() ? View.INVISIBLE : View.VISIBLE);
                    }
                });

                // Setup a long click listener on the surface - this allows the application to produce a Toast pop-up
                // which display content related information - track, bit-rates, etc
                surfaceView.setLongClickable(true);
                surfaceView.setOnLongClickListener(getLongClickListener());
                mSurfaceHolder = surfaceView.getHolder();

                mSurfaceHolder.setFormat(mScreenPixelFormat);
                mSurfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);


                // Register callback listeners with both the SurfaceHolder and the NexPlayer
                // This will allow control of graphic initialization & playback
                mNexPlayerGuard.setListener(this);
                mSurfaceHolder.addCallback(this);

                // Set some of the various options available in the NexPlayer
                mNexPlayerGuard.setProperty(NexPlayer.NexProperty.PREFER_AV, 1);
                mNexPlayerGuard.setProperty(NexPlayer.NexProperty.SUPPORT_SMOOTH_SKIPPING, 1);
                mNexPlayerGuard.setProperty(NexPlayer.NexProperty.AV_INIT_OPTION, NexPlayer.NexProperty.AV_INIT_ALL);
                mNexPlayerGuard.setProperty(NexPlayer.NexProperty.INITIAL_BUFFERING_DURATION, INITIAL_BUFFERING_TIME);
                mNexPlayerGuard.setProperty(NexPlayer.NexProperty.RE_BUFFERING_DURATION, RE_BUFFERING_TIME);

                // Sets the user agent on the nexplayer calls - commented out for now since it breaks progressive
                // downloads of PR and WM DRM ASF
                // mNexPlayerGuard.setProperties(58, Constants.DRM_AGENT_USER_STRING);

                // Set up a listener on the control panel - this prevents clicks outside of any of the controls
                // used in the panel from 'leaking' onto the surfaceview and causing the panel to be removed
                // by accident
                mControlPanelLinearLayout = (LinearLayout) findViewById(getControlPanelLinearLayout());
                mControlPanelLinearLayout.setVisibility(View.VISIBLE);

                mControlPanelLinearLayout.setOnTouchListener(new View.OnTouchListener()
                {
                    public boolean onTouch(final View view, final MotionEvent motionEvent)
                    {
                        return true;
                    }
                });

                // Setup the PlayPause button - this adds the listener required to handle clicks
                // as well as the graphics for the button (play selector by default)
                // The onClickListener will handle pause/play switching and deal with graphic (button)
                // updates
                mButtonPlayPause = (ImageButton) findViewById(getPlayPauseImageButton());
                mButtonPlayPause.setOnClickListener(mPlayPauseOnClickListener);
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));

                // Setup the seek bar - this nullifies the current play position to 0 & adds a listener
                // to control the actual seeking operations
                mSeekBar = (SeekBar) findViewById(getSeekBar());
                mSeekBar.setProgress(0);
                mSeekBar.setSecondaryProgress(0);
                mSeekBar.setMax(0);
                mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener()
                {
                    public void onProgressChanged(final SeekBar seekBar, final int currentPosition, final boolean seekBarTracking)
                    {
                        Log.v(TAG, "Progress changed: " + currentPosition + " (" + (seekBarTracking ? "tracking)" : "not tracking)"));
                        if (seekBarTracking)
                        {
                            mDesiredPosition = currentPosition;
                        }
                    }

                    public void onStartTrackingTouch(final SeekBar seekBar)
                    {
                        Log.v(TAG, "SeekBar tracking started");
                        mSeekBarTracking = true;
                    }

                    public void onStopTrackingTouch(final SeekBar seekBar)
                    {
                        Log.v(TAG, "SeekBar tracking stopped");
                        if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PLAY)
                        {
                            // Means we were tracking & now we are not - seek to the time specified
                            final int seek = mNexPlayerGuard.seek(mDesiredPosition * 1000);
                            Log.d(TAG, "Seek operation status: " + seek);
                            updateUserMessage("Seeking...");
                        }
                        mSeekBarTracking = false;
                    }
                });

                // Retrieve the view that displays the status text - this displays things like status
                // (opening, buffering) and the elapsed time within the play
                mStatusText = (TextView) findViewById(getStatusTextView());

                mNoAudioImageView = (ImageView) findViewById(getAudioOnlyImageView());
                mNoAudioImageView.setImageDrawable(getResources().getDrawable(getAudioOnlyDrawable()));
                mNoAudioImageView.setVisibility(View.INVISIBLE);

                //subtitles
                final SharedPreferences authentec = this.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
                mShowSubtitles = authentec.getBoolean(Constants.PREFERENCES_SHOW_SUBTITLES, true);

                // Next, initiate opening of the content
                openContent();

                if (mUseOpenGL)
                {
                    surfaceView.setVisibility(View.GONE);
                }

                Log.d(TAG, "initializePlay complete");
            }
            else
            {
                Log.d(TAG, "No rights available, going back to licensing activity");

                Intent intent = new Intent(getBaseContext(), getLicenseAcquisitionActivityClass());
                intent.putExtra(Constants.DESCRIPTOR_LOCATION, mDRMContentInfo.mContentDescriptorLocation);
                startActivity(intent);
                finish();
            }

        }
        catch (Exception e)
        {
            final String initFailedMessage = getInitFailedMessage();
            Log.e(TAG, initFailedMessage + ": " + e.getMessage(), e);
            Toast.makeText(this, initFailedMessage, Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private View.OnLongClickListener getLongClickListener() {
        return new View.OnLongClickListener()
        {
            public boolean onLongClick(final View view)
            {
                final NexContentInformation nexContentInformation = mCurrentNexContentInformation;

                if (nexContentInformation == null)
                {
                    return true;
                }

                final NexTrackInformation nexTrackInformation = NexUtils.extractCurrentNexTrackInformation(mCurrentNexContentInformation);
                int bandwidth = 0;

                if (nexTrackInformation != null)
                {
                    bandwidth = nexTrackInformation.mBandWidth / 1000;
                }

                final int audioBitRate = mCurrentNexContentInformation.mAudioBitRate / 1000;
                final int videoBitRate = mCurrentNexContentInformation.mVideoBitRate / 1000;
                final String duration = Tools.convertToNiceTime(mCurrentNexContentInformation.mMediaDuration);
                final String played = Tools.convertToNiceTime(mPlayingTime);

                final String toastText = String.format("Content Information\n\nPlayed: %s\nLength: %s\nBandwidth: %d kbps\nAudio Bitrate: %d\nVideo Bitrate: %d", played, duration, bandwidth, audioBitRate, videoBitRate);
                Toast.makeText(getBaseContext(), toastText, Toast.LENGTH_LONG).show();

                return true;
            }
        };
    }

    protected int getSubtitlesTextView()
    {
        return R.id.subtitle;
    }

    protected int getContentView()
    {
        return R.layout.video;
    }

    protected int getSeekBar()
    {
        return R.id.SeekBar;
    }

    public String getInitFailedMessage()
    {
        return getString(R.string.cp_init_failed);
    }

    protected Class getLicenseAcquisitionActivityClass()
    {
        return LicenseAcquisitionActivity.class;
    }

    protected int getStatusTextView()
    {
        return R.id.StatusTextView;
    }

    protected int getAudioOnlyDrawable()
    {
        return R.drawable.audio_only_3color;
    }

    protected int getAudioOnlyImageView()
    {
        return R.id.noAudioImageView;
    }

    protected int getPlayPauseImageButton()
    {
        return R.id.PlayPauseButton;
    }

    protected int getButtonDrawablePlay()
    {
        return R.drawable.play_selector;
    }

    protected int getControlPanelLinearLayout()
    {
        return R.id.ControlPanel;
    }

    protected int getSurfaceView()
    {
        return R.id.surface;
    }

    protected int getRelativeLayout()
    {
        return R.id.frameLayout;
    }

    protected int getButtonDrawablePause()
    {
        return R.drawable.pause_selector;
    }

    private void openContent()
    {
        boolean streaming = (mUri.getScheme() != null && (mUri.getScheme().equals("http") || mUri.getScheme().equals("https")));

        String url = mUri.toString();

        Log.d(TAG, "Content Mode: " + (streaming ? "Streaming" : "File"));

        Log.d(TAG, "Initiating opening of content located at: " + mUri.toString());

        updateUserMessage((streaming ? "Connecting..." : "Opening..."));
        String path = (streaming ? url : mUri.getPath());

        //subtitles for local files
        String smiPath = null;

        if(mShowSubtitles && !streaming)
        {
            smiPath = getSmiPath(path);

            Log.d(TAG, "Subtitles path: " + smiPath);
        }


        if (mNexPlayerGuard.open(path, smiPath, streaming ? NexPlayer.NEXPLAYER_SOURCE_TYPE_STREAMING : NexPlayer.NEXPLAYER_SOURCE_TYPE_LOCAL_NORMAL, NexPlayer.NEXPLAYER_TRANSPORT_TYPE_TCP, BUFFERING_TIME) != 0)
        {
            reportError("[Error] Can't open content");
        }
        else
        {
            Log.d(TAG, "Content opening initiated for : " + url);
            mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePause()));
        }
    }

    @Override
    protected void onPause()
    {

        Log.d(TAG, "Unregistering HDMI Broadcast receiver.");
        DRMAgentDelegate.removeHDMIBroadcastReceiver(getBaseContext());


        mActive = false;
        if (mNexPlayerGuard != null)
        {
            long timestamp = (mNexPlayerGuard.isInitialized() && mNexPlayerGuard.isPlaying() ? mPlayingTime : 0);
            Tools.saveStartFrom(this,timestamp, mUri);
        }

        if (mWakeLock != null && mWakeLock.isHeld())
        {
            mWakeLock.release();
            mWakeLock = null;
        }

        if (mDimLock != null && mDimLock.isHeld())
        {
            mDimLock.release();
            mDimLock = null;
        }

        try
        {
            stopPlayback();

            // Finally, close agent
            DRMAgentDelegate.uninitialize();

        }
        catch (Exception e)
        {
            Log.e(TAG, "error: " + e.getMessage(), e);
        }

        if (mUseOpenGL && mGLRenderer != null)
        {
            mGLRenderer.onPause();
        }

        super.onPause();
    }

    private void waitConditionallyOnPlayer(int timeout)
    {
        int waitCount = 0;
        while (mNexPlayerGuard != null && mNexPlayerGuard.getLastIssuedCommand() > 0 && waitCount++ < 10)
        {
            // Sleep for a bit
            sleep(timeout);
        }
    }

    private void sleep(int duration)
    {
        try
        {
            Thread.sleep(duration);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }

    private long getElapsedTime()
    {
        return (System.currentTimeMillis() - mStartTime);
    }

    View.OnClickListener mPlayPauseOnClickListener = new View.OnClickListener()
    {
        public void onClick(View v)
        {

            Log.i(TAG, "Play listener entered");
            Log.d(TAG, "Opening URL: " + mUri);

                if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PAUSE)
                {
                    if (!ContentHandler.isClearText(mDRMContentInfo))
                    {
                        mDRMContentInfo.mDRMContent.startConsumption();
                    }
                    mNexPlayerGuard.resume();
                    mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePause()));
                }
                else if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_STOP)
                {
                    if (!ContentHandler.isClearText(mDRMContentInfo))
                    {
                        mDRMContentInfo.mDRMContent.startConsumption();
                    }
                    mNexPlayerGuard.start(0);
                    mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePause()));
                }
                else if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PLAY)
                {
                    if (!ContentHandler.isClearText(mDRMContentInfo))
                    {
                        mDRMContentInfo.mDRMContent.stopConsumption();
                    }
                    mNexPlayerGuard.pause();
                    mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));
                }

            }
    };

    public void updateUserMessage(final String strMsg)
    {
        mHandler.post(new Runnable()
        {
            public void run()
            {
                try
                {
                    mStatusText.setText(strMsg);
                }
                catch (Throwable e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    // SurfaceHolder::Callback
    public void surfaceChanged(SurfaceHolder surfaceholder, int format, int w, int h)
    {
        if (!mActive)
        {
            // We are no longer active, bailing out
            Log.i(TAG, "Received surfaceChanged & we are not active, will bail");
            return;
        }

        if (mNexPlayerGuard == null)
        {
            Log.i(TAG, "Received surfaceCreated & we have no player yet, will bail");
            return;
        }

        if (!mPowerManager.isScreenOn())
        {
            Log.i(TAG, "Received surfaceChanged & screen is off, will reset state");
            return;
        }

        Log.d(TAG, "Surface changed: " + getElapsedTime());
        Log.d(TAG, "Surface dimensions: " + h + "/" + w);
        Log.d(TAG, "NexPlayer State: " + NexUtils.toStateStr(mNexPlayerGuard.getState()));

        mSurfaceWidth = w;
        mSurfaceHeight = h;

        // Small fix for situations when the surface was destroyed but player was never closed
        // Can happen on the DesireHD, A2.2 when, for example, the USB cable is plugged in for charging
        if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_STOP)
        {
            // Simply start!
            mNexPlayerGuard.start(0);
            return;
        }
        else if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PLAY || mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PAUSE)
        {
            final int renderMode = mNexPlayerGuard.GetRenderMode();
            if (renderMode != 0 && renderMode != NexPlayer.NEX_USE_RENDER_OPENGL)
            {
                //maybe we might need to tune the way we calculate scale (for certain video???)
                //float scale = Math.min((float) mSurfaceWidth / (float) mVideoWidth, (float) mSurfaceHeight / (float) mVideoHeight);
                float scale = (float) mSurfaceWidth / (float) mVideoWidth;
                mFullSizeWidth = (int) (mVideoWidth * scale);
                mFullSizeHeight = (int) (mVideoHeight * scale);
                mTop = (mSurfaceHeight - mFullSizeHeight) / 2;
                mLeft = (mSurfaceWidth - mFullSizeWidth) / 2;

                Log.d(TAG, "Calling setOutputPos mLeft: " + mLeft + "; mTop:" + mTop + "; mFullSizeWidth:" + mFullSizeWidth + "; mFullSizeHeight:" + mFullSizeHeight);
                mNexPlayerGuard.setOutputPos(mLeft, mTop, mFullSizeWidth, mFullSizeHeight);

                //looking at Nextreaming sample code and by testing, looks this is not needed anymore
                // Still playing - simply set the surface
                //mNexPlayerGuard.setDisplay(surfaceholder);
            }
        }

        Log.d(TAG, "surfaceChanged completed: " + getElapsedTime());

    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        Log.d(TAG, "surfaceDestroyed called");
    }

    public void surfaceCreated(SurfaceHolder holder)
    {
        Log.d(TAG, "surfaceCreated called: " + getElapsedTime());

        if (!mActive)
        {
            // We are no longer active, bailing out
            Log.i(TAG, "Received surfaceCreated & we are not active, will bail");
            return;
        }

        if (mNexPlayerGuard == null)
        {
            // Hmm
            Log.i(TAG, "Received surfaceCreated & we have no player yet, will bail");
            return;
        }

        final int renderMode = mNexPlayerGuard.GetRenderMode();
        Log.d(TAG, "Render Mode: " + renderMode);

        if (renderMode != 0 && renderMode != NexPlayer.NEX_USE_RENDER_OPENGL)
        {
            // Update the NexPlayer with the surface just provided
            Log.d(TAG, "Updating display on NexPlayer");
            mNexPlayerGuard.setDisplay(mSurfaceHolder, 0);
        }
    }

    public void onEndOfContent(NexPlayer nexPlayer)
    {
        Log.d(TAG, "endOfContent signaled");


        final SharedPreferences authentec = getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        if (authentec.getBoolean(Constants.PREFERENCES_RESUME_PLAY_FROM_LAST_KNOWN_TIME,true))
        {
            final SharedPreferences.Editor edit = authentec.edit();
            edit.remove(mUri.toString() + ".uri");
            edit.remove(mUri.toString() + ".time");
            edit.commit();
        }

        mHandler.post(new Runnable()
        {
            public void run()
            {
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));
                mSeekBar.setProgress(0);
                mSeekBar.setSecondaryProgress(0);
                mPlayingTime = 0;
                mBufferedTime = 0;
                updateUserMessage("Stopped");
            }
        });

    }

    public void onTime(final NexPlayer nexPlayer, final int sec)
    {
        Log.v(TAG, "onTime called (" + sec + " sec)");

        // We only update if we are currently tracking in the seekbar
        if (!mSeekBarTracking)
        {
            mSeekBar.setProgress(sec / 1000);
        }

        // Always update the secondary progress no matter what - this will increment the current pos even while
        // the user is seeking
        mSeekBar.setSecondaryProgress(sec / 1000);

        // Validate we have the same player still as is kept by the guard
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);

        final int bufferTime = mNexPlayerGuard.getBufferStatus();

        // This is a sanity check that validates whether or not we have experienced any significantly large 'skips'
        // in the playing of the content.  This is mainly to act as a guard to signal behaviours out of the ordinary.
        if (((mPlayingTime / 1000) + SKIP_TOLERANCE) < (sec / 1000) || ((mPlayingTime / 1000) - SKIP_TOLERANCE) > (sec / 1000))
        {
            Log.w(TAG, "***********************");
            Log.w(TAG, "*!! Detected skip in time beyond my tolerance of " + SKIP_TOLERANCE);
            Log.w(TAG, "*!! Previous timestamp: " + (mPlayingTime / 1000) + " second(s)");
            Log.w(TAG, "*!! New timestamp: " + (sec / 1000) + " second(s)");
            Log.w(TAG, "*!! Delta: " + ((mPlayingTime / 1000) - (sec / 1000)) + " second(s)");
            Log.w(TAG, "***********************");
        }

        mPlayingTime = sec;
        mBufferedTime = bufferTime;

        updateUserMessage(Tools.convertToNiceTime(sec));

    }

    public void onError(NexPlayer nexPlayer, NexPlayer.NexErrorCode errorCode)
    {
        Log.d(TAG, "onError: 0x" + Integer.toHexString(errorCode.getIntegerCode()) + " (" + errorCode.getCategory() + "/" + errorCode.name() + ")");

        switch (errorCode.getCategory())
        {
            case AUTH:
                Log.w(TAG, "Received authentication/DRM related error code: " + errorCode);
                break;
            default:
        }

        stopPlayback();

        mHandler.post(new Runnable()
        {
            public void run()
            {
                mButtonPlayPause.setImageDrawable(getResources().getDrawable(getButtonDrawablePlay()));
                mSeekBar.setProgress(0);
                mSeekBar.setSecondaryProgress(0);
                mPlayingTime = 0;
                mBufferedTime = 0;
            }
        });
        updateUserMessage("Error");
        reportError("Error occured: " + errorCode.getDesc() + "(" + errorCode.name() + ")");
    }

    private void stopPlayback()
    {
        if (mNexPlayerGuard != null)
        {
            // If still playing, simply stop the player
            if (mNexPlayerGuard.isPlaying())
            {
                Log.d(TAG, "Stopping playback");
                mNexPlayerGuard.stop();
            }

            // Wait for the stop to actually occur as well - wait is a little longer here as it may time out
            waitConditionallyOnPlayer(400);

            if (mNexPlayerGuard.isPlaying())
            {
                Log.d(TAG, "Player is still playing, even after stop ... will force close");
                mNexPlayerGuard.forceClose();
            }
            else
            {
                Log.d(TAG, "Closing player");
                mNexPlayerGuard.close();
            }

            // Wait a little more to allow any pending decryption to complete - just in case
            waitConditionallyOnPlayer(100);

            if (mNexPlayerGuard.isInitialized())
            {
                // Still around - force close again
                mNexPlayerGuard.forceClose();
                waitConditionallyOnPlayer(100);
            }

            if (!ContentHandler.isClearText(mDRMContentInfo))
            {
                Log.d(TAG, "Stopping consumption");
                mDRMContentInfo.mDRMContent.stopConsumption();
            }

            Log.d(TAG, "Player closed, un-registering content");
            if (mDRMContentInfo.mDRMContent != null)
            {
                // AUTHENTEC COMMENT
                // Make any open references to the content are cleared up
                Log.d(TAG, "Releasing content");
                mDRMContentInfo.mDRMContent.release();
            }

            // Finally release the nexplayer instance
            NexPlayerHandler.releaseNexPlayerGuard(mNexPlayerGuard);
            mNexPlayerGuard = null;

        }
    }

    private void reportError(final String errorMessage)
    {
        mHandler.post(new Runnable() {
            public void run() {
                updateErrorDialog(errorMessage);
                showDialog(ERROR_REPORTED);
            }
        });
    }

    private void updateErrorDialog(final String errorMessage)
    {
        if (mErrorDialog == null)
        {
            final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
            {
                public void onClick(DialogInterface dialog, int id)
                {
                    dialog.cancel();
                }
            };
            mErrorDialog = Tools.createAlertDialog(this, "DRM Fusion Agent for Android", errorMessage, false, "Ok", positiveListener, null, null);
        }
    }

     @Override
    protected Dialog onCreateDialog(int id)
    {
        switch (id)
        {
            case ERROR_REPORTED:
                return mErrorDialog;
            default:
                Log.d(TAG, "No such dialog");
                return null;
        }
    }

    public void onStateChanged(NexPlayer nexPlayer, int pre, int now)
    {
        Log.d(TAG, "onStateChanged called (" + pre + "->" + now + ")");
    }

    public void onVideoRenderCreate(NexPlayer nexPlayer, int width, int height, Object rgbBuffer)
    {
        //save video width and height; they will be used when handling screen rotation
        mVideoWidth = width;
        mVideoHeight = height;

        if (!mActive)
        {
            Log.d(TAG, "Received videoRenderCreate while we are not active, will ignore");
            return;
        }

        Log.d(TAG, "Initiating video rendering (width/height): " + width + "/" + height + " (" + getElapsedTime() + "ms");

        float scale = (float) mSurfaceWidth / (float) width;
        mFullSizeWidth = (int) (width * scale);
        mFullSizeHeight = (int) (height * scale);
        mTop = (mSurfaceHeight - mFullSizeHeight) / 2;
        mLeft = (mSurfaceWidth - mFullSizeWidth) / 2;

        Log.d(TAG, "Screen dimensions (left/top/width/height): " + mLeft + "/" + mTop + "/" + mFullSizeWidth + "/" + mFullSizeHeight);


        Log.d(TAG, "onVideoRenderCreate called (width:" + width + " height : "
                + height);

        final int renderMode = mNexPlayerGuard.GetRenderMode();
        Log.d(TAG, "Render Mode: " + renderMode);

        if (renderMode == 0 || renderMode == NexPlayer.NEX_USE_RENDER_OPENGL)
        {
            // Do nothing?
            mNexPlayerGuard.setOutputPos(mLeft, mTop, mFullSizeWidth, mFullSizeHeight);
        }
        else if (renderMode == NexPlayer.NEX_USE_RENDER_AND)
        {
            mNexPlayerGuard.setDisplay(mSurfaceHolder, 0);
            mNexPlayerGuard.setOutputPos(mLeft, mTop, mFullSizeWidth, mFullSizeHeight);
            mNexPlayerGuard.setRenderOption(NexPlayer.RENDER_MODE_VIDEO_NONE);
        }

        clearCanvas();
    }

    @Override
    public void onVideoRenderRender(NexPlayer mp)
    {
        if (mUseOpenGL)
        {
            mGLRenderer.requestRender();
        }
        else
        {

            if (mFrameBitmap != null)
            {
                Canvas canvas = mSurfaceHolder.lockCanvas();

                if (canvas != null)
                {
                    Rect rctSrc = new Rect(0, 0, mFrameBitmap.getWidth(), mFrameBitmap.getHeight());

                    canvas.drawColor(Color.BLACK);

                    Rect rctDst = new Rect(mLeft, mTop, mLeft + mFullSizeWidth, mTop + mFullSizeHeight);
                    canvas.drawBitmap(mFrameBitmap, rctSrc, rctDst, mPaint);
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }

    public void onVideoRenderDelete(NexPlayer nexPlayer)
    {
        Log.d(TAG, "onVideoRenderDelete called: " + NexUtils.toStateStr(mNexPlayerGuard.getState()));
    }

    public void onTextRenderInit(NexPlayer nexPlayer, int classNum)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);

        for (int i = 0; i < classNum; i++)
        {
            String strClassName = mNexPlayerGuard.getSMIClassInfo(i);
            Log.d(TAG, "ClassName[" + i + "] = " + strClassName);
        }
    }

    public void onTextRenderRender(final NexPlayer mp, final int trackIndex, final NexClosedCaption textInfo)
    {
        try
        {
            Log.d(TAG, "About to render sub-titles");
            NexUtils.logNexClosedCaption(textInfo);

            if (mShowSubtitles)
            {

                // Extract the character encoding of the sub-titles/closed caption
                final int encoding = textInfo.getEncodingType();

                // The data to be rendered for sub-titles/data
                final byte[] textData = textInfo.getTextData();

                final String strSub;
                switch (encoding)
                {
                    case NexClosedCaption.ENCODING_TYPE_ISO8859_1:
                        // FIXME: This is broken on the NexPlayer side since they
                        // FIXME: will ship UTF8 and report ISO_8859_1
                        strSub = new String(textData,"UTF-8");
                        break;
                    case NexClosedCaption.ENCODING_TYPE_ASCII:
                    case NexClosedCaption.ENCODING_TYPE_UTF8:
                        strSub = new String(textData, "UTF-8");
                        break;
                    case NexClosedCaption.ENCODING_TYPE_UTF16_BE:
                    case NexClosedCaption.ENCODING_TYPE_UTF16:
                        strSub = new String(textData, "UTF-16BE");
                        break;
                    default:
                        Log.w(TAG,"Unhandled encoding: " + encoding);
                        return;
                }

                mHandler.post(new Runnable()
                {
                    public void run()
                    {
                        try
                        {
                            TextView txtSubtitle = (TextView) findViewById(getSubtitlesTextView());
                            txtSubtitle.setText(strSub);
                        }
                        catch (Throwable e)
                        {
                            Log.e(TAG, "Error while updating subtitles: " + e.getMessage());
                        }
                    }
                });
            }

        }
        catch (Exception e)
        {
            Log.e(TAG, "Exception while processing closed caption: " + e.getMessage(), e);
        }
    }


    public void onStatusReport(final NexPlayer nexPlayer, final int msg, final int param1)
    {
        Looper.prepare();
        AsyncTask asyncTask = new AsyncTask()
        {
            @Override
            protected Object doInBackground(final Object... objects)
            {
                Log.d(TAG, "Status report: " + NexUtils.toStatusReportString(msg) + " (" + param1 + ")");
                switch (msg)
                {
                    case NexPlayer.NEXPLAYER_STATUS_REPORT_STREAM_CHANGED:
                        Log.d(TAG, "Stream changed: " + param1);
                        updateContentInformation();
                        printContentInformation();
                        handlePossibleImageOverlay();
                        break;
                    case NexPlayer.NEXPLAYER_STATUS_REPORT_TRACK_CHANGED:
                        Log.d(TAG, "Track changed: " + param1);
                        updateContentInformation();
                        printContentInformation();
                        handlePossibleImageOverlay();
                        break;
                    case NexPlayer.NEXPLAYER_STATUS_REPORT_DSI_CHANGED:
                        Log.d(TAG, "Content changed: " + param1);
                        printContentInformation();
                        break;
                    case NexPlayer.NEXPLAYER_STATUS_REPORT_CONTENT_INFO_UPDATED:
                        Log.d(TAG, "Content info updated: " + param1);
                        updateContentInformation();
                        printContentInformation();
                        handlePossibleImageOverlay();
                        break;
                    case NexPlayer.NEXPLAYER_STATUS_REPORT_HTTP_INVALID_RESPONSE:
                    default:
                        Log.d(TAG, "Status report: " + msg + " (" + param1 + ")");
                }
                return null;
            }
        };
        asyncTask.execute();

    }

    private void handlePossibleImageOverlay()
    {
        if (mCurrentNexContentInformation.mMediaType == 1)
        {
            Log.d(TAG, "!!!!!---------------------------------!!!!");
            Log.d(TAG, "Audio only data detected");
            if (mCurrentNexContentInformation.mID3Tag != null && mCurrentNexContentInformation.mID3Tag.getPicture() != null)
            {
                Log.d(TAG, "Found image in the stream, should overlay!");
                AsyncTask<NexContentInformation, Object, Bitmap> imageLoadingTask = new AsyncTask<NexContentInformation, Object, Bitmap>()
                {
                    protected Bitmap doInBackground(final NexContentInformation... nexContentInformations)
                    {
                        final byte[] pictureData = nexContentInformations[0].mID3Tag.getPicture().getPictureData();
                        return BitmapFactory.decodeByteArray(pictureData, 0, pictureData.length);
                    }

                    @Override
                    protected void onPostExecute(final Bitmap bitmap)
                    {
                        mNoAudioImageView.setImageBitmap(bitmap);
                        mNoAudioImageView.setVisibility(View.VISIBLE);
                    }
                };
                imageLoadingTask.execute(mCurrentNexContentInformation);
            }
            else
            {
                mHandler.post(new Runnable()
                {
                    public void run()
                    {
                        mNoAudioImageView.setVisibility(View.VISIBLE);
                    }
                });
            }
        }
        else
        {
            mHandler.post(new Runnable()
            {
                public void run()
                {
                    mNoAudioImageView.setVisibility(View.GONE);
                }
            });
        }
    }

    public void onAsyncCmdComplete(NexPlayer nexPlayer, int command, int result, int param1, int param2)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);
        Log.d(TAG, "Command completed: " + NexUtils.toCommandStr(command) + " (" + result + "/" + mNexPlayerGuard + "/" + NexUtils.toStateStr(mNexPlayerGuard.getState()) + ")");
        switch (command)
        {
            case NexPlayer.NEXPLAYER_ASYNC_CMD_OPEN_LOCAL:
            case NexPlayer.NEXPLAYER_ASYNC_CMD_OPEN_STREAMING:
                if (result == 0)
                {
                    Log.d(TAG, "Content opened: " + getElapsedTime());

                    if (mActive)
                    {
                        Log.d(TAG, "Still active, will start play and then update the content information");

                        // AUTHENTEC COMMENT
                        // This signals to the DRM sub-system that consumption is beginning
                        if (!ContentHandler.isClearText(mDRMContentInfo))
                        {
                            mDRMContentInfo.mDRMContent.startConsumption();
                        }

                        int startFrom = Tools.extractStartFrom(this, mLastIntent, mUri);
                        Log.d(TAG, "Start from: " + startFrom);

                        // Next, start playing the content
                        mNexPlayerGuard.start(startFrom);

                        updateContentInformation();

                        mContentDuration = mCurrentNexContentInformation.mMediaDuration;
                        mSeekBar.setMax(mContentDuration / 1000);

                    }
                }
                else
                {
                    reportError("Could not open content: " + mUri);
                    onError(nexPlayer, NexPlayer.NexErrorCode.fromIntegerValue(result));
                }
                break;
            case NexPlayer.NEXPLAYER_ASYNC_CMD_START_LOCAL:
            case NexPlayer.NEXPLAYER_ASYNC_CMD_START_STREAMING:
                if (result != 0)
                {
                    Log.d(TAG, "Start Failed : " + result);
                    onError(nexPlayer, NexPlayer.NexErrorCode.fromIntegerValue(result));
                }
                else
                {
                    Log.d(TAG, "Content started: " + getElapsedTime());
                }

                break;
            case NexPlayer.NEXPLAYER_ASYNC_CMD_STOP:
                clearCanvas();
                updateUserMessage("Stopped");
                break;
            case NexPlayer.NEXPLAYER_ASYNC_CMD_SEEK:
                break;
            default:

        }
    }

    private void updateContentInformation()
    {
        mCurrentNexContentInformation = mNexPlayerGuard.getContentInfo();

        // Extract the languages available at this point

        // Extract the subtitles available at this point

    }

    public void onDataInactivityTimeOut(NexPlayer nexPlayer)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);
        if (mNexPlayerGuard.getState() == NexPlayer.NEXPLAYER_STATE_PLAY)
        {
            mNexPlayerGuard.stop();
        }
    }

    /**
     * @param nexPlayer Nexplayer instance
     */
    public void onBufferingBegin(NexPlayer nexPlayer)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);
        Log.d(TAG, "Buffering begin");
        updateUserMessage("Buffering 0 %");
    }

    /**
     * Callback received from Nexplayer when buffering has been completed (buffer is full).
     *
     * @param nexPlayer Nexplayer instance
     */
    public void onBufferingEnd(NexPlayer nexPlayer)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);
        Log.d(TAG, "Buffering end");
        updateUserMessage("Buffering 100 %");
    }

    /**
     * Callback received from Nexplayer when there is data that has been buffered
     *
     * @param nexPlayer Nexplayer instance
     * @param progress  The current buffer (as a percentage)
     */
    public void onBuffering(NexPlayer nexPlayer, int progress)
    {
        mNexPlayerGuard.ensureSameNexPlayer(nexPlayer);
        Log.d(TAG, "Buffering " + progress + " %");
        updateUserMessage("Buffering " + progress + " %");
    }

    /**
     *
     */
    public void printContentInformation()
    {
        NexUtils.logNexContentInformation(mCurrentNexContentInformation);
    }

    private void clearCanvas()
    {
        Paint clsPaint = new Paint();
        if (mSurfaceHolder != null)
        {
            Canvas canvas = mSurfaceHolder.lockCanvas();

            try
            {
                if (canvas != null)
                {
                    Rect rctDst = new Rect(0, 0, canvas.getWidth(), canvas.getHeight());
                    clsPaint.setColor(Color.BLACK);
                    canvas.drawRect(rctDst, clsPaint);
                }
            }
            finally
            {
                if (canvas != null)
                {
                    mSurfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }

     /*
         Check for subtitle file with extension: .srt or .sub
        * @return the path if file exist; otherwise null.
        */
    private String getSmiPath(String strURL)
    {
        //check for
        String strSMI;
        String strTemp;
        int nIndex = strURL.lastIndexOf('.');
        strSMI = strURL.substring(0, nIndex);
        strTemp = strSMI + ".srt";
        File file = new File(strTemp);
        if(file.exists())
        {
            strSMI = strTemp;
        }
        else
        {
            strTemp = strSMI + ".sub";
            file = new File(strTemp);
            if(file.exists())
            {
                strSMI = strTemp;
            }
            else
            {
                strSMI = null;
            }
        }
        return strSMI;
    }

    private class AudioStream
    {
        int mStreamIndex;
        String mName;

    }

}

