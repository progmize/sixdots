//
//  SampleViewController.h
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>
#import "MBProgressHUD.h"
#import "AVPlayerViewController.h"
#import "DownloadableAgent.h"

@interface SampleViewController : UIViewController <UIAlertViewDelegate, LicenseAcquisitionDelegate, UIPickerViewDelegate, UIPickerViewDataSource>
{
	IBOutlet UITextField *textbox;
	IBOutlet UIPickerView *pickerView;
	IBOutlet UIButton *testActionButton1;
	IBOutlet UIButton *testActionButton2;
	IBOutlet UISwitch *playerSwitch;
    
    DownloadableAgent *agent;
	NSURL *selectedContentURL;
	BOOL shouldUseAgentForPlayback;
	NSMutableArray *messageLog;
	NSMutableArray *contentList;
	MBProgressHUD *HUD;
    
    BOOL useAVFoundationPlayer;
    
    // if using the MediaPlayer framework
	MPMoviePlayerController *mpPlayer;
    
	// if using the AVFoundation framework
    AVPlayer *avPlayer;
}

@property (nonatomic, retain) IBOutlet UITextField *textbox;
@property (nonatomic, retain) IBOutlet UIPickerView *pickerView;
@property (nonatomic, retain) MBProgressHUD *HUD;
@property (nonatomic, retain) NSMutableArray *messageLog;
@property (nonatomic, retain) NSMutableArray *contentList;
@property (nonatomic, retain) DownloadableAgent *agent;
@property (nonatomic, retain) NSURL *selectedContentURL;
@property (nonatomic, retain) MPMoviePlayerController *mpPlayer;
@property (nonatomic, retain) AVPlayer *avPlayer;

- (IBAction)playFromTextbox:(id)sender;
- (IBAction)deleteDRMStore:(id)sender;
- (IBAction)showLogView:(id)sender;
- (IBAction)showCachedContentView:(id)sender;
- (IBAction)showContentPicker:(id)sender;
- (IBAction)dismissKeyboard:(id)sender;
- (IBAction)changePlayerSwitch:(id)sender;
- (IBAction)testAction1:(id)sender;
- (IBAction)testAction2:(id)sender;

// expose this as a public method for the AVPlayerViewController to be able 
// to tell this controller when it is done playing the content
- (void)stopPlayback;

@end