//
//  POXClient.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/28/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "POXClient.h"
#import "POXRequest.h"


@implementation POXClient

//@synthesize delegate;

- (id)init {
  self = [super init];
	if (self != nil) {
		operationQueue = [[NSOperationQueue alloc] init];
		[operationQueue setMaxConcurrentOperationCount:1];
	}
	return self;	
}



- (NSDictionary *)callPOXEndpoint:(NSURL *)urlEndpoint input:(NSDictionary *)inputDictionary {
  return [NSDictionary dictionary]; 
}

// Async - but this is limited to one call at a time.
// This overrides the previous delegate.
- (void)callPOXEndpoint:(NSURL *)urlEndpoint input:(NSDictionary *)inputDictionary delegate:(id)aDelegate {
  POXRequest *request = [[POXRequest alloc] init];
  request.urlEndpoint = urlEndpoint;
  request.inputDictionary = inputDictionary;
  request.delegate = aDelegate;
  [operationQueue addOperation:request];
}


@end
