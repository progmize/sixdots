//
//  ProductCategory.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ProductCategory : NSObject {
  NSString *categoryID;
  NSString *name;
}

@property (copy) NSString *categoryID;
@property (copy) NSString *name;


@end
