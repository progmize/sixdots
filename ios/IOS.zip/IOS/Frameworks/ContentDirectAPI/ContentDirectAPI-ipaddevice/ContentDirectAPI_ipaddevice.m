//
//  ContentDirectAPI_ipaddevice.m
//  ContentDirectAPI-ipaddevice
//
//  Created by Brandon on 2/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ContentDirectAPI_ipaddevice.h"

@implementation ContentDirectAPI_ipaddevice

- (id)init
{
    self = [super init];
    if (self) {
        // Initialization code here.
    }
    
    return self;
}

@end
