//
// CHBrowseCategoryViewController.h
// Chicago
//
// Created by Derr on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDClient.h"
#import "CHBaseProductListViewController.h"

@class MBProgressHUD;
@class ProductCategory;

@interface CHBrowseCategoryViewController : CHBaseProductListViewController <CDClientDelegate> {
	MBProgressHUD		* ch_progressHUD;
	ProductCategory	* ch_category;
    int currentPage;
    int pageCount;
    int pageToLoad;
}

@property (nonatomic, strong) MBProgressHUD        * progressHUD;
@property (nonatomic, strong) ProductCategory      * category;
@property (nonatomic, assign) int                    currentPage;
@property (nonatomic, assign) int                    pageCount;
@property (nonatomic, assign) int                    pageToLoad;

@end

