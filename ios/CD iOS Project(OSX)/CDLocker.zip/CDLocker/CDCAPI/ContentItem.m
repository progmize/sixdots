//
//  ContentItem.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "ContentItem.h"


@implementation ContentItem

@synthesize contentItemID;
@synthesize contentURL;


- (NSString *)description {
  return [NSString stringWithFormat:@"ContentItem ID:%@ URL:%@", self.contentItemID, self.contentURL];
}

@end
