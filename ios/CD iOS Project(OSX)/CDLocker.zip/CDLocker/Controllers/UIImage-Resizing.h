//
//  UIImage-Resizing.h
//  Chicago
//
//  Created by louie on 8/13/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIImage (Resizing)
+ (UIImage *)imageWithImage:(UIImage *)image scaledToSize:(CGSize)newSize;
@end
