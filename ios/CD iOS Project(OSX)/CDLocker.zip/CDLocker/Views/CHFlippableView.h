//
// FlippableThumbnailView.h
// Chicago
//
// Created by Derr on 8/28/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kFlipImageDuration    .25

@class CHFlippableView;

@protocol CHFlippableViewDelegate
- (NSTimeInterval)flippableView:(CHFlippableView *)flipView timeIntervalToWaitBeforFlippingToView:(UIView *)view;
- (void)flippableView:(CHFlippableView *)flipView finishedFlippingToView:(UIView *)view;
@end

@interface CHFlippableView : UIView {
  UIView *ch_frontView;
  UIView *ch_backView;

  CGRect ch_backFrame;
  UIView *ch_blackOutView;

  BOOL ch_frontVisible;

  id<CHFlippableViewDelegate> __unsafe_unretained ch_delegate;
}

@property (nonatomic, strong) UIView                     *frontView;
@property (nonatomic, strong) UIView                     *backView;
@property (nonatomic, unsafe_unretained) id<CHFlippableViewDelegate> delegate;

- (id)initWithFrame:(CGRect)frame;

- (void)showFrontView;
- (void)showBackView;

@end
