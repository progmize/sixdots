//
//  StarsView.h
//  Chicago
//
//  Created by Derr on 9/13/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CHStarsView : UIView {
	UIImage *starImage;
	int stars;
}

@property (assign) int stars;

@end
