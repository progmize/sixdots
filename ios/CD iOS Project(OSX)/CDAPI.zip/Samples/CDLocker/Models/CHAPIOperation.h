//
// CHAPIOperation.h
// Chicago
//
// Created by Brian Cooke on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDClient.h"
#import "CHAPIOperationQueue.h"


@interface CHAPIOperation : NSOperation {
	id<CDClientDelegate> __unsafe_unretained ch_delegate;
	NSInvocation        *ch_invocation;
}

@property (nonatomic, unsafe_unretained) id<CDClientDelegate> delegate;
@property (nonatomic, strong) NSInvocation        *invocation;

+ (CHAPIOperation *)operationToRetrieveCategoriesByParentCategoryID:(NSString *)parentCategoryID;
+ (CHAPIOperation *)operationToRetrieveProductsByCategoryID:(NSString *)categoryID limit:(int)maximumNumberOfProductsToReturn;
+ (CHAPIOperation *)operationToRetrieveProductsByCategoryID:(NSString *)categoryID page:(int)page itemsPerPage:(int)itemsPerPage;
+ (CHAPIOperation *)operationToViewProductContent:(Product *)product;
+ (CHAPIOperation *)operationToLoginWithLogin:(NSString *)login password:(NSString *)password;
+ (CHAPIOperation *)operationToLogout;
+ (CHAPIOperation *)operationToRetrieveSubscriberInfo;
+ (CHAPIOperation *)operationToRetrieveSubscriberInfo;
+ (CHAPIOperation *)operationToCreateSubscriberWithLogin:(NSString *)login email:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname password:(NSString *)password challengeQuestion:(NSString *)challengeQuestion challengeAnswer:(NSString *)challengeAnswer;
+ (CHAPIOperation *)operationToSearchForProductsWithFullText:(NSString *)fullText limit:(int)maximumNumberOfProductsToReturn page:(int)pageNumber;
+ (CHAPIOperation *)operationToRetrieveProductByProductID:(NSString *)productID;
+ (CHAPIOperation *)operationToRetrieveFeaturedProducts;
+ (CHAPIOperation *)operationToRetrieveCodes;
+ (CHAPIOperation *)operationToRegisterDevice;
+ (CHAPIOperation *)operationToRetrieveChallengeQuestionForLogin:(NSString *)login;
+ (CHAPIOperation *)operationToResetPasswordForLogin:(NSString *)login challengeResponse:(NSString *)challengeResponse newPassword:(NSString *)newPassword;
+ (CHAPIOperation *)operationToGenerateNewPasswordForLogin:(NSString *)login;
+ (CHAPIOperation *)operationToUpdateSubscriberWithCurrentPassword:(NSString *)curPassword newLogin:(NSString *)newLogin newPassword:(NSString *)newPassword newChallengeQuestion:(NSString *)newChallengeQuestion newChallengeResponse:(NSString *)newChallengeResponse;
+ (CHAPIOperation *)operationToCalculateOrderQuoteForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument;
+ (CHAPIOperation *)operationToSubmitOrderForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument;
+ (CHAPIOperation *)operationToSubmitOrderForProductWithItunes:(Product *)product receiptCode:(NSString *)receiptCode;
+ (CHAPIOperation *)operationToUpdateSubscriberEmail:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname;
+ (CHAPIOperation *)operationToCreatePaymentInstrument:(PaymentInstrument *)aPaymentInstrument;
+ (CHAPIOperation *)operationToRemovePaymentInstrument:(PaymentInstrument *)aPaymentInstrument;
+ (CHAPIOperation *)operationToSendPing;
+ (CHAPIOperation *)operationToRetrieveSubscriberProducts;
+ (CHAPIOperation *)operationToUnregisterDeviceWithSubscriberID:(NSString *)subscriberID;

@end
