//
//  ContentItem.m
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "ContentItem.h"


@implementation ContentItem

@synthesize contentURL, contentName, contentType;

+ (ContentItem *)contentItemWithName:(NSString *)name andURL:(NSString *)url ofType:(DAContentType)type
{
	ContentItem *item = [[[ContentItem alloc] init] autorelease];
	item.contentName = name;
	item.contentURL = url;
	item.contentType = type;
	
	return item;
}

- (void)dealloc
{
	[contentName release];
	[contentURL release];
	
	[super dealloc];
}

@end
