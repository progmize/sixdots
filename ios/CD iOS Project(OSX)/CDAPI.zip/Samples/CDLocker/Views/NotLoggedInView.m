//
//  NotLoggedInView.m
//  Chicago
//
//  Created by Derr on 9/22/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "NotLoggedInView.h"


@implementation NotLoggedInView

@synthesize delegate;

- (void)login {
  [self.delegate promptLogin];
}

- (id)initWithFrame:(CGRect)frame {
  if ((self = [super initWithFrame:frame])) {
      self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
      
      UIImageView * bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];
      bg.frame = self.bounds;
      bg.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
      bg.contentMode = UIViewContentModeScaleToFill;
      
      [self addSubview:bg];
      
      UILabel * mustBeLoggedIn = [[UILabel alloc] initWithFrame:CGRectMake(0, 20, self.bounds.size.width, 21)];
      mustBeLoggedIn.autoresizingMask = UIViewAutoresizingFlexibleWidth;
      mustBeLoggedIn.font            = [UIFont boldSystemFontOfSize:17.0];
      mustBeLoggedIn.textColor       = [UIColor whiteColor];
      mustBeLoggedIn.text            = NSLocalizedString(@"LIBRARY_LOGIN_MESSAGE", @"You must be logged in");
      mustBeLoggedIn.backgroundColor = [UIColor clearColor];
      mustBeLoggedIn.textAlignment   = UITextAlignmentCenter;
      [self addSubview:mustBeLoggedIn];
      
      UIButton * login = [UIButton buttonWithType:UIButtonTypeCustom];
      login.frame = CGRectMake(14, self.bounds.size.height - 22 - 12, 291, 22);
      login.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin;
      [login setBackgroundImage:[UIImage imageNamed:@"more_button.png"] forState:UIControlStateNormal];
      [login setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
      [login setTitle:NSLocalizedString(@"CONTENT_MENU_LOGIN", @"Login") forState:UIControlStateNormal];
      [login addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
      login.titleLabel.font = [UIFont boldSystemFontOfSize:13];
      [self addSubview:login];
      
    }
    return self;
}



@end
