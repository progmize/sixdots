// This displays a list of products.
//
// CHBaseProductListViewController.h
// Chicago
//
// Created by louie on 8/13/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CHBaseLoginRequiredViewController.h"

@interface CHBaseProductListViewController : CHBaseLoginRequiredViewController <UITableViewDataSource, UITableViewDelegate> {
  NSArray			* ch_products;
  UITableView	* ch_tableView;
}

@property (nonatomic, strong) NSArray * products;

@property (nonatomic, strong) IBOutlet UITableView * tableView;

@end
