//
// PaymentInstrument.h
// ContentDirect POX API
//
// Created by Luis de la Rosa on 8/2/10.
// Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PaymentInstrument : NSObject {
  NSString * paymentInstrumentID;
  NSString * nickname;
  NSString * status;
  NSString * instrumentType;

  // We are flattening out WorkaroundCreditCard and its BillingAddress here as wcc and wcc_ba.
  NSString * wcc_accountNumber;
  NSString * wcc_cardType;
  NSString * wcc_cvv;
  NSString * wcc_expirationMonth;
  NSString * wcc_expirationYear;
  NSString * wcc_isVerified;
  NSString * wcc_nameOnCard;
  NSString * wcc_phoneNumber;

  NSString * wcc_ba_city;
  NSString * wcc_ba_country;
  NSString * wcc_ba_id;
  NSString * wcc_ba_lineOne;
  NSString * wcc_ba_lineTwo;
  NSString * wcc_ba_nickname;
  NSString * wcc_ba_phoneNumber;
  NSString * wcc_ba_state;
  NSString * wcc_ba_zip;

  // StoredValueAccount fields
  NSString * wsva_accountNumber;
  NSString * wsva_adminOverride;
  NSString * wsva_brandableCurrency;
  NSString * wsva_currentBalance;
  NSString * wsva_initialAmount;
  NSString * wsva_isChargeable;
  NSString * wsva_loyaltyPointsCard;
  NSString * wsva_rechargeAmount;
  NSString * wsva_rechargeType;
}

@property (copy) NSString * paymentInstrumentID;
@property (copy) NSString * nickname;
@property (copy) NSString * status;
@property (copy) NSString * instrumentType;

// We are flattening out WorkaroundCreditCard and its BillingAddress here as wcc and wcc_ba.
@property (copy) NSString * wcc_accountNumber;
@property (copy) NSString * wcc_cardType;
@property (copy) NSString * wcc_cvv;
@property (copy) NSString * wcc_expirationMonth;
@property (copy) NSString * wcc_expirationYear;
@property (copy) NSString * wcc_isVerified;
@property (copy) NSString * wcc_nameOnCard;
@property (copy) NSString * wcc_phoneNumber;

@property (copy) NSString * wcc_ba_city;
@property (copy) NSString * wcc_ba_country;
@property (copy) NSString * wcc_ba_id;
@property (copy) NSString * wcc_ba_lineOne;
@property (copy) NSString * wcc_ba_lineTwo;
@property (copy) NSString * wcc_ba_nickname;
@property (copy) NSString * wcc_ba_phoneNumber;
@property (copy) NSString * wcc_ba_state;
@property (copy) NSString * wcc_ba_zip;

@property (copy) NSString * wsva_accountNumber;
@property (copy) NSString * wsva_adminOverride;
@property (copy) NSString * wsva_brandableCurrency;
@property (copy) NSString * wsva_currentBalance;
@property (copy) NSString * wsva_initialAmount;
@property (copy) NSString * wsva_isChargeable;
@property (copy) NSString * wsva_loyaltyPointsCard;
@property (copy) NSString * wsva_rechargeAmount;
@property (copy) NSString * wsva_rechargeType;

+ (PaymentInstrument *)paymentInstrumentFromDictionary:(NSDictionary *)paymentInstrumentDictionary;
- (NSDictionary *)toDictionaryWithSubscriberID:(NSString *)subscriberID;
- (NSString *)cardTypeShortName;

@end
