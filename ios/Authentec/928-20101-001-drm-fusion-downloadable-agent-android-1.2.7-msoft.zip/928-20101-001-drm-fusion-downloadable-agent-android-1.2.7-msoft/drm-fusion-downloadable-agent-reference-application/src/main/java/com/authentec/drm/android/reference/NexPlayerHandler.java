package com.authentec.drm.android.reference;

import android.content.*;
import android.util.Log;
import com.nextreaming.nexplayerengine.*;

/**
 * @author AuthenTec Inc.
 */
public class NexPlayerHandler
{
    public static final String TAG = "NexPlayerHandler";
    public static NexPlayerGuard mNexPlayerGuard;

    public static NexPlayerGuard getNexPlayerGuard(final Context context, int colorDepth)
    {
        if (mNexPlayerGuard != null)
        {
            Log.w(TAG,"Received call for NexPlayer but guard has not been released, check your code for logic flaws?");
            return mNexPlayerGuard;
        }

        long t1 = System.currentTimeMillis();

        final NexPlayer nexPlayer = new NexPlayer();

        final SharedPreferences sharedPreferences = context.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        final int logLevel = sharedPreferences.getInt(Constants.PREFERENCES_NEXTREAMING_LOG_LEVEL, -1);

        final int selectedRenderer = sharedPreferences.getInt(Constants.PREFERENCES_NEXTREAMING_RENDERER, 0);

        String rendererStr = NexPlayer.NEX_DEVICE_USE_ONLY_ANDROID;
        switch (selectedRenderer)
        {
            case 0:
            case 1:
                // Auto-detect/Nextreaming - leave as Nex Android
                // This may still cause the player to choose (on 3.x devices for example) the Java selectedRenderer
                break;
            case 2:
                // OPEN GL
                rendererStr = NexPlayer.NEX_DEVICE_USE_OPENGL;
                colorDepth = 4;
                break;
            default:
                throw new RuntimeException("Unhandled renderer selection: " + selectedRenderer);

        }

        Log.i(TAG, "Initializing NexPlayer");
        Log.i(TAG, "Log level: " + logLevel);
        Log.i(TAG, "Color depth: " + colorDepth);
        Log.i(TAG, "Renderer: " + rendererStr);

        final boolean resultCode = nexPlayer.init(context, rendererStr, logLevel, colorDepth);

        if (!resultCode)
        {
            Log.w(TAG, "NexPlayerSDK Initialize Failed");
            throw new RuntimeException("Error creating the NexPlayer instance: " + resultCode);
        }
        else
        {
            long t2 = System.currentTimeMillis();
            Log.i(TAG, "NexPlayer Initialized in " + (t2 - t1) + " millisecond(s)");

            final NexPlayerGuard nexPlayerGuard = new NexPlayerGuard(nexPlayer);
            int rendererMode = nexPlayer.GetRenderMode();
            // Work around issue in Nex 5.x
            if (rendererMode == 0)
            {
                // Hmmm
                rendererMode = NexUtils.resolveRendererModeFromString(rendererStr);
            }

            nexPlayerGuard.setSelectedRendererMode(rendererMode);

            Log.i(TAG, "NexPlayer Renderer Mode: " + NexUtils.resolveRendererMode(rendererMode));

            return nexPlayerGuard;
        }
    }

    public static void releaseNexPlayerGuard(NexPlayerGuard nexPlayerGuard)
    {
        if (nexPlayerGuard != mNexPlayerGuard)
        {
            Log.w(TAG, "Releasing guard instance, but not the same instance");
        }

        // Check state too

        if (nexPlayerGuard != null)
        {
            nexPlayerGuard.release();
        }

        if (mNexPlayerGuard != null)
        {
            mNexPlayerGuard.release();
            mNexPlayerGuard = null;
        }


    }

}
