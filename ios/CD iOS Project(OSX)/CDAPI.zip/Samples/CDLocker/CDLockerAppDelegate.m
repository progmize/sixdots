//
//  CDLockerAppDelegate.m
//  CDLocker
//
//  Created by Kelly Lein on 2/6/12.
//  Copyright (c) 2012 Content Direct. All rights reserved.
//

#import "CDLockerAppDelegate.h"
#import "CHLibraryViewController.h"
#import "ImageCache.h"
#import "UIImage-Resizing.h"
#import "CDClient.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"
#import "CHSettings.h"
#import "Reachability.h"

#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>

#define kCHPingTimeoutInSeconds    (60 * 9)

@implementation CDLockerAppDelegate

@synthesize internetConnected;
@synthesize connectMessageDisplayed;
@synthesize storeManager;
@synthesize cdClient;
@synthesize featuredProducts;
@synthesize pingTimer;

@synthesize imageLogoURL;
@synthesize backgroundImageURL;
@synthesize window = _window;
@synthesize navigationController = _navigationController;


+ (CDLockerAppDelegate *)sharedAppDelegate {
    return (CDLockerAppDelegate *)[UIApplication sharedApplication].delegate;
}


+ (CDClient *)sharedCDClient {
    return [self sharedAppDelegate].cdClient;
}




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    ////////// Localization Information //////////
    //NSLog(@"////////// <Localization Information> //////////");
    //NSLog(@"NSBundle localizedInfoDictionary: %@", [[NSBundle mainBundle] localizedInfoDictionary]);
    //NSLog(@"NSBundle localizations: %@", [[NSBundle mainBundle] localizations]);
    //NSLog(@"NSBundle developmentLocalization: %@", [[NSBundle mainBundle] developmentLocalization]);
    //NSLog(@"NSBundle preferredLocalizations: %@", [[NSBundle mainBundle] preferredLocalizations]);
    //NSLog(@"////////// </Localization Information> //////////");
    ///////////////////////////////////
	
	// check for internet connection
	[[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(checkNetworkStatus:) 
                                                 name:kReachabilityChangedNotification
                                               object:nil];
	
	internetReachable = [Reachability reachabilityForInternetConnection];
	[internetReachable startNotifier];
	
	// check if a pathway to a random host exists
	hostReachable = [Reachability reachabilityWithHostName: @"www.apple.com"];
	[hostReachable startNotifier];
	
	logoImage = nil;
	landscapeLogoImage = nil;
	[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque animated:YES];
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    CHLibraryViewController *libraryVC = [[CHLibraryViewController alloc] init];
    self.navigationController = [[UINavigationController alloc] initWithRootViewController:libraryVC];
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];
    
    // Register for ImageCache notifications
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(imageWasDownloaded:)
                                                 name:@"ImageDownloaded"
                                               object:nil];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(userLoggedOut)
                                                 name:@"UserLoggedOut"
                                               object:nil];
    
    NSError *error = nil;
    [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayback error:&error];
    if (error) {
        //NSLog(@"%@", error);
    }
    
	return YES;
}

#pragma mark notifications

- (void) checkNetworkStatus:(NSNotification *)notice
{
	NetworkStatus internetStatus = [internetReachable currentReachabilityStatus];
	switch (internetStatus)
	{
		case ReachableViaWiFi:
		case ReachableViaWWAN:
		{
			// Retrieve codes
			CHAPIOperation *retrieveCodesOperation = [CHAPIOperation operationToRetrieveCodes];
			retrieveCodesOperation.delegate = self;
			[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:retrieveCodesOperation];
			
			break;
		}
		case NotReachable:
		default:
		{
			// Let them know
			//NSLog(@"You are no longer connected. Please try again."); 
			if( !connectMessageDisplayed )
			{
				connectMessageDisplayed = YES;
				[self showConnectionMessage];
			}
			break;
			
		}
	}
}

- (void) showConnectionMessage {
	UIAlertView *av = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"No connection", @"ALERT_NO_CONNECTION_TITLE")
                                                 message:NSLocalizedString(@"You are no longer connected. Please try again.", @"ALERT_NO_CONNECTION") 
                                                delegate:self cancelButtonTitle:@"Done" 
                                       otherButtonTitles:nil];
	[av show];
}

- (void)imageWasDownloaded:(NSNotification *)notification {
    NSURL *urlForDownloadedImage = [notification object];  
    ////NSLog(@"imageWasDownloaded url:%@", urlForDownloadedImage);
    
    if ([urlForDownloadedImage isEqual:self.imageLogoURL]) {
        // Make sure that logo is updated in the main thread.
        [self performSelectorOnMainThread:@selector(showLogoImage) withObject:nil waitUntilDone:NO];    
    } else if ([urlForDownloadedImage isEqual:self.backgroundImageURL]) {
        // Make sure that background Image is updated in the main thread.
        [self performSelectorOnMainThread:@selector(showBackgroundImage) withObject:nil waitUntilDone:NO];    
    }
}

- (void) userLoggedOut
{
	// Call initialize store again to reset data
	
    //TODO: change to offline mode
}



#pragma mark image methods

- (UIImage *)loadAndResizeLogoImage {
    // Get the imageLogo and assign to all the navigation bars
    UIImage *imageLogo = [[ImageCache sharedImageCache] imageForURL:self.imageLogoURL];
    
    if (imageLogo == nil) { return nil; }
    
    //  UINavigationController *firstNavController = [tabViewControllers objectAtIndex:0];
    //  // Resize image to look decent.
    //  CGSize titleSize = firstNavController.navigationBar.topItem.titleView.frame.size;
    
    // TODO adjust for iPhone4
    CGSize titleSize = CGSizeMake(200.0, 44.0);
    UIImage *resizedImage = [UIImage imageWithImage:imageLogo scaledToSize:titleSize];
    logoImage = resizedImage;
    
    return logoImage;
}

- (UIImage *)logoImage {
    return logoImage;
}

- (UIImage *)landscapeLogoImage {
    // TODO figure out the cause of this crash.
    // Caching this seems to cause a crash.
    //  if (landscapeLogoImage != nil) {
    //    return landscapeLogoImage;
    //  }
    
    // Otherwise, then resize the logo
    UIImage *imageLogo = [[ImageCache sharedImageCache] imageForURL:self.imageLogoURL];
    
    if (imageLogo == nil) { return nil; }
    
    CGSize landscapeTitleSize = CGSizeMake(200.0, 32.0);
    UIImage *resizedLandscapeImage = [UIImage imageWithImage:imageLogo scaledToSize:landscapeTitleSize];
    landscapeLogoImage = resizedLandscapeImage;
    
    return landscapeLogoImage;
}

- (void)showLogoImage {
    [self loadAndResizeLogoImage];
    
    if (logoImage == nil) { return; }
    
    NSArray *tabViewControllers = [self.navigationController viewControllers];
    for (UINavigationController *navController in tabViewControllers) {
        
        UIViewController *topViewController = navController.topViewController;
        if ([topViewController isKindOfClass:[CHBaseViewController class]]) {
            CHBaseViewController *baseViewController = (CHBaseViewController *)topViewController;
            [baseViewController showLogoBranding];
            [baseViewController showCSGBranding];
        }
    }  
}

- (void)loadAndResizeBackgroundImage {
    // Get the imageLogo and assign to all the navigation bars
    UIImage *backgroundImageOriginal = [[ImageCache sharedImageCache] imageForURL:self.backgroundImageURL];  
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    CGSize applicationSize = CGSizeMake(applicationFrame.size.width, applicationFrame.size.height);
    UIImage *resizedImage = [UIImage imageWithImage:backgroundImageOriginal scaledToSize:applicationSize];  
    backgroundImage = resizedImage;
}

- (UIImage *)backgroundImage {
    [self loadAndResizeBackgroundImage];
    
    if (backgroundImage == nil) { return nil; }
    
    return backgroundImage;
}

- (void)showBackgroundImage {
    [self loadAndResizeBackgroundImage];
    
    if (backgroundImage == nil) { return; }
	
	UIViewController *selectedNavController = self.navigationController.topViewController;
	UIViewController *current = nil;
	if ([selectedNavController isKindOfClass:[UINavigationController class]]) {
		current = ((UINavigationController *)selectedNavController).topViewController;
	}
	else {
		current = selectedNavController;
	}
	if ([current isKindOfClass:[CHBaseViewController class]]) {
		[((CHBaseViewController *)current) setBackgroundImage:backgroundImage];
	}
}   
    
- (CDClient *)cdClient {
        if (cdClient == nil) {
            NSString *storefrontPlist = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"Storefront Info"];
            NSDictionary *clientInfo				= [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:storefrontPlist ofType:@"plist"]];
            NSString     *deviceType				= [clientInfo valueForKey:@"deviceType"];
            NSString     *distributionChannel		= [clientInfo valueForKey:@"distributionChannel"];
            NSString     *systemID					= [clientInfo valueForKey:@"systemId"];
            NSString     *storefrontURLString		= [clientInfo valueForKey:@"poxService"];
            NSString     *physicalDeviceTypeCode	= [clientInfo valueForKey:@"physicalDeviceType"];
            NSString     *language					= [clientInfo valueForKey:@"language"];
            NSString	 *playlistGUID				= [clientInfo valueForKey:@"playlistGUID"];
            BOOL		  enableInAppPurchase = NO;
            if([clientInfo objectForKey:@"enableInAppPurchase"] != nil)		
            {
                enableInAppPurchase = [[clientInfo objectForKey:@"enableInAppPurchase"] boolValue];			
            }
            
            ////NSLog(@"\ndeviceType = %@ \ndistChannel = %@ \nsystemID = %@ \nstorefrontURL = %@", deviceType, distributionChannel, systemID, storefrontURLString);
            
            cdClient = [[CDClient alloc] initWithDeviceType:deviceType
                                           distributionChannel:distributionChannel
                                                      systemID:systemID
                                           storefrontURLString:storefrontURLString
										physicalDeviceTypeCode:physicalDeviceTypeCode
                                                      language:language
                                                  playlistGUID:playlistGUID
                                           enableInAppPurchase:enableInAppPurchase];
            cdClient.loginName    = [CHSettings sharedCHSettings].loginName;
            cdClient.subscriberID = [CHSettings sharedCHSettings].subscriberID;
            cdClient.delegate     = self;
            
            // Retrieve codes
            //CHAPIOperation *retrieveCodesOperation = [CHAPIOperation operationToRetrieveCodes];
            //retrieveCodesOperation.delegate = self;
            //[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:retrieveCodesOperation];
        }
        
        return cdClient;
    }
    
    - (NSArray *)passwordChallengeCodes {
        return [codeTypesToCodes objectForKey:@"DefaultPasswordChallenge"];
    }
    
    
    - (NSArray *)creditCardCodes {
        return [codeTypesToCodes objectForKey:@"CreditCardType"];
    }
    
    
    - (NSArray *)ratingCodes {
        return [codeTypesToCodes objectForKey:@"Rating"];
    }
    
    
    - (void)sendPing:(NSTimer *)theTimer {
        //NSLog(@"Sending ping...");
        CHAPIOperation *op = [CHAPIOperation operationToSendPing];
        op.delegate = self;
        [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}


#pragma mark -
#pragma mark CDClientDelegate


- (void)codesRetrieved:(NSDictionary *)aCodeTypesToCodes {
    // Store the codes
    codeTypesToCodes = aCodeTypesToCodes;
    
    //TODO: create session with auth key
    
    //for now just wait until login
}


- (void)codeRetrievalFailedWithFault:(Fault *)fault {
    // TODO handle the fault
    
}



- (void) retrievedSubscriberProducts:(NSArray *)products {
}



- (void) retrievedSubscriberProductsFailedWithFault:(Fault *)aFault {
}


- (void)pingSuccess {
    //NSLog(@"Ping success...");
    self.pingTimer = [NSTimer scheduledTimerWithTimeInterval:kCHPingTimeoutInSeconds target:self selector:@selector(sendPing:) userInfo:nil repeats:NO];
}


- (void)pingFailedWithFault:(Fault *)fault {
    NSLog(@"Ping failed: %@", fault);
    if ([fault isSessionTimeout]) {
        //TODO: create session with auth key
        
    }
    self.pingTimer = [NSTimer scheduledTimerWithTimeInterval:kCHPingTimeoutInSeconds target:self selector:@selector(sendPing:) userInfo:nil repeats:NO];
}





- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

@end
