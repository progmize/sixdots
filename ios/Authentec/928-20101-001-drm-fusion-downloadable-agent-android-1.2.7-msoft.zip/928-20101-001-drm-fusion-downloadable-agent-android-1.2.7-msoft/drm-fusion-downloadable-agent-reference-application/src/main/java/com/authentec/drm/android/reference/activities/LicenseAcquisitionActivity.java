package com.authentec.drm.android.reference.activities;

import java.io.File;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.*;

import android.app.*;
import android.content.*;
import android.os.*;
import android.util.Log;
import android.widget.Toast;
import com.authentec.drm.android.reference.*;
import com.authentec.drm.android.reference.ContentHandler;
import com.authentec.drmagent.v2.*;
import com.authentec.drmagent.v2.utils.*;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpRequestBase;

/**
 * @author AuthenTec Inc.
 */
public class LicenseAcquisitionActivity extends Activity
{
    /**
     * Defines the identifiers of the various dialogs used by this activity.
     */
    public static final int NO_LICENSE = 1;
    public static final int RETRIEVING_LICENSE = 2;
    public static final int LICENSE_RETRIEVED = 3;
    public static final int ERROR_RETRIEVING_LICENSE = 4;
    public static final int CANCELLING_RETRIEVING_LICENSE = 5;
    public static final int TIMEOUT_RETRIEVING_LICENSE = 6;
    public static final int UNTRUSTED_TIME = 7;
    public static final int POLICY_CHECK_FAILED = 8;
    public static final int JOIN_DOMAIN_REQUIRED = 9;
    public static final int RETRIEVING_JOIN_DOMAIN = 10;
    public static final int JOIN_DOMAIN_COMPLETED = 11;

    /**
     * Defines the maximum amount of time for which to wait for a license to be installed (in seconds).
     * This controls how long the application will display the 'Retrieving License' dialog.
     */
    public static final int LICENSE_ACQUISITION_MAX_WAIT = 30;

    public static final String TAG = "LicenseAcquisitionActivity";
    private DRMContentInfo mDRMContentInfo;
    private Integer mStartFrom;
    private DRMLicenseAcquisitionHandler mDRMLicenseAcquisitionHandler;
    private LicenseAcquisitionResult mLicenseAcquisitionResult = LicenseAcquisitionResult.NONE;
    private Lock mLicenseAcquisitionResultLock = new ReentrantLock();
    public static final Handler mHandler = new Handler();
    private boolean mCustomURL = false;

    private PlayReadyDRMJoinDomainHandler mPlayReadyDRMJoinDomainHandler;
    private byte[] mAcquireLicenseResponse = null;
    private ProgressDialog mRetrievingLicenseDialog;


    @Override
    protected void onResume()
    {
        super.onResume();

        final Intent lastIntent = getIntent();
        Bundle extras = lastIntent.getExtras();

        if (getIntent().getStringExtra("CUSTOM_URL") != null)
        {
            mCustomURL = true;
            final URI uri = URI.create(extras.getString(Constants.CUSTOM_URL));
            mDRMContentInfo = ContentHandler.createDRMContentInfoForUnknownURI(this, uri);
        }
        else
        {
            mCustomURL = false;
            String selectedContentIdentifier = extras.getString(Constants.DESCRIPTOR_LOCATION);
            mDRMContentInfo = ContentHandler.parseAsXML(this, new File(selectedContentIdentifier), true, true);
        }

        mStartFrom = (Integer) lastIntent.getSerializableExtra(Constants.START_FROM);

        final String drmErrorStr = lastIntent.getStringExtra("DRM_ERROR");
        if (drmErrorStr != null)
        {
            // Something went wrong during playback
            final DRMError drmError = DRMError.valueOf(drmErrorStr);
            switch (drmError)
            {
                case NO_RIGHTS:
                    noLicenseDetected();
                    break;
                case UNTRUSTED_TIME:
                    untrustedTimeDetected();
                    break;
                case POLICY_CHECK_FAILURE:
                    policyCheckFailed();
                    break;
                case GENERAL_DRM_ERROR:
                default:
                    Log.d(TAG, "DRM error: " + drmError);
            }
        }
        else
        {

            // This checks whether or not the Agent has rights for the content in question.  This check will
            // verify both if the content is clear-text or protected & rights exists
            if (ContentHandler.hasRights(mDRMContentInfo))
            {
                startPlayer();
            }
            else
            {
                Log.d(TAG, "No rights available");

                final DRMRights.DRMRightsType drmRightsType = mDRMContentInfo.mDRMContent.getDRMRights().getDRMRightsType();
                switch (drmRightsType)
                {
                    case UNTRUSTED_TIME:
                        untrustedTimeDetected();
                        break;
                    case NO_RIGHTS:
                    case RIGHTS_IN_FUTURE:
                    case EXPIRED:
                        // No license available - display the dialog or simply initiate license acquisition
                        noLicenseDetected();
                        break;
                    default:
                        throw new RuntimeException("Unhandled DRM rights type: " + drmRightsType);
                }
            }
        }


    }

    private void policyCheckFailed()
    {
        showDialog(LicenseAcquisitionActivity.POLICY_CHECK_FAILED);
    }

    protected void noLicenseDetected()
    {
        showDialog(LicenseAcquisitionActivity.NO_LICENSE);
    }

    protected void untrustedTimeDetected()
    {
        showDialog(LicenseAcquisitionActivity.UNTRUSTED_TIME);
    }

    protected void startPlayer()
    {
        final boolean useNativePlayer = useNativePlayer(mDRMContentInfo);

        final Intent intent;
        switch (mDRMContentInfo.mDRMContent.getDRMContentFormat())
        {
            case HTTP_LIVE_STREAMING:
            case PIFF:
                if (useNativePlayer)
                {
                    Log.d(TAG, "Native player in use, starting it");
                    intent = new Intent(getBaseContext(), getPlayMediaNativePlayerActivityClass());
                }
                else
                {
                    Log.d(TAG, "NexPlayer in use, starting it");
                    intent = new Intent(getBaseContext(), getPlayMediaNexPlayerActivityClass());
                }
                break;
            default:
                intent = new Intent(getBaseContext(), getPlayMediaNexPlayerActivityClass());
        }

        if (mCustomURL)
        {
            intent.putExtra(Constants.CUSTOM_URL, mDRMContentInfo.mContentLocation.toString());
        }
        else
        {
            intent.putExtra(Constants.DESCRIPTOR_LOCATION, mDRMContentInfo.mContentDescriptorLocation);
        }
        if (mStartFrom != null)
        {
            intent.putExtra("startFrom", mStartFrom);
        }
        startActivity(intent);

        finish();
    }

    protected Class getPlayMediaNexPlayerActivityClass()
    {
        return PlayMediaNexPlayerActivity.class;
    }

    protected Class getPlayMediaNativePlayerActivityClass()
    {
        return PlayMediaNativePlayerActivity.class;
    }

    protected boolean useNativePlayer(final DRMContentInfo mDRMContentInfo)
    {
        final SharedPreferences authentec = LicenseAcquisitionActivity.this.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        return authentec.getBoolean(Constants.PREFERENCES_USE_NATIVE_PLAYER, false);
    }

    protected boolean useAsynchLicenseAcknowledgement()
    {
        final SharedPreferences authentec = LicenseAcquisitionActivity.this.getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
        return authentec.getBoolean(Constants.PREFERENCES_ACKNOWLEDGE_LICENSES_ASYNCHRONOUSLY, false);
    }


    @Override
    protected Dialog onCreateDialog(int id)
    {
        Dialog dialog;

        Log.d(TAG, "onCreateDialog: " + id);

        switch (id)
        {
            case NO_LICENSE:
                dialog = createAskRetrieveLicenseDialog();
                break;
            case RETRIEVING_LICENSE:
                dialog = createRetrievingLicenseDialog();
                break;
            case LICENSE_RETRIEVED:
                dialog = createLicenseRetrievedDialog();
                break;
            case ERROR_RETRIEVING_LICENSE:
                dialog = createErrorRetrievingLicenseDialog();
                break;
            case TIMEOUT_RETRIEVING_LICENSE:
                dialog = createRetrievingLicenseTimeOutDialog();
                break;
            case CANCELLING_RETRIEVING_LICENSE:
                dialog = createCancellingLicenseDialog();
                break;
            case UNTRUSTED_TIME:
                dialog = createUntrustedTimeDialog();
                break;
            case POLICY_CHECK_FAILED:
                dialog = createPolicyCheckFailedDialog();
                break;
            case JOIN_DOMAIN_REQUIRED:
                dialog = createAskJoinDomainDialog();
                break;
            case RETRIEVING_JOIN_DOMAIN:
                dialog = createJoiningDomainDialog();
                break;
            case JOIN_DOMAIN_COMPLETED:
                dialog = createJoinDomainCompletedDialog();
                break;
            default:
                dialog = null;
        }
        return dialog;
    }

    protected Dialog createJoinDomainCompletedDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                initiateRightsIssuerLicenseAcquisition();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextJoinDomainCompleted(), false, getDialogButtonOK(), positiveListener, null, null);
    }


    protected Dialog createJoiningDomainDialog()
    {
        final DialogInterface.OnClickListener negativeListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                removeDialog(LicenseAcquisitionActivity.RETRIEVING_JOIN_DOMAIN);
                showDialog(LicenseAcquisitionActivity.CANCELLING_RETRIEVING_LICENSE);
                setLicenseAcquisitionResult(LicenseAcquisitionResult.CANCELLED);
            }
        };
        return Tools.createProgressDialog(this, getDialogTitle(), getDialogTextJoiningDomain(), false, null, null, getDialogButtonCancel(), negativeListener);
    }

    private Dialog createAskJoinDomainDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                Log.d(TAG, "Open up connection and such from join domain!");
                initiateJoinDomain();
            }
        };
        final DialogInterface.OnClickListener negativeListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();
                finish();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextJoinDomainQuestion(), false, getDialogButtonYes(), positiveListener, getDialogButtonNo(), negativeListener);
    }

    protected Dialog createPolicyCheckFailedDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                Log.d(TAG, "Finishing because of policy check failure");
                finish();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextPolicyCheckFailed(), false, getDialogButtonOK(), positiveListener, null, null);
    }



    protected Dialog createUntrustedTimeDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                Log.d(TAG, "Finishing because of untrusted time");
                finish();
                return;
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextUntrustedTime(), false, getDialogButtonOK(), positiveListener, null, null);
    }

    protected Dialog createAskRetrieveLicenseDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                Log.d(TAG, "Open up connection and such!");
                initiateRightsIssuerLicenseAcquisition();
            }
        };
        final DialogInterface.OnClickListener negativeListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();
                finish();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextRetrieveLicenseQuestion(), false, getDialogButtonYes(), positiveListener, getDialogButtonNo(), negativeListener);
    }

    protected Dialog createRetrievingLicenseDialog()
    {
        final DialogInterface.OnClickListener negativeListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                removeDialog(LicenseAcquisitionActivity.RETRIEVING_LICENSE);
                showDialog(LicenseAcquisitionActivity.CANCELLING_RETRIEVING_LICENSE);
                setLicenseAcquisitionResult(LicenseAcquisitionResult.CANCELLED);
            }
        };
        mRetrievingLicenseDialog = Tools.createProgressDialog(this, getDialogTitle(),
                getDialogTextRequestingLicense(), false,
                null, null, getDialogButtonCancel(), negativeListener);
        return mRetrievingLicenseDialog;
    }

    protected Dialog createCancellingLicenseDialog()
    {
        return Tools.createProgressDialog(this, getDialogTitle(),
                getDialogTextCancellingLicenseRequest(), false,
                null, null, null, null);
    }

    protected Dialog createErrorRetrievingLicenseDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();
                finish();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextErrorRetrievingLicense(), false, getDialogButtonOK(), positiveListener, null, null);
    }

    protected Dialog createRetrievingLicenseTimeOutDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();
                finish();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextTimeoutRetrievingLicense(), false, getDialogButtonOK(), positiveListener, null, null);
    }

    protected Dialog createLicenseRetrievedDialog()
    {
        final DialogInterface.OnClickListener positiveListener = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                startPlayer();
            }
        };
        return Tools.createAlertDialog(this, getDialogTitle(), getDialogTextLicenseRetrieved(), false, getDialogButtonPlay(), positiveListener, null, null);
    }

    protected CharSequence getDialogTextCancellingLicenseRequest()
    {
        return getText(R.string.dialog_text_cancelling_license_request);
    }

    protected CharSequence getDialogTextUntrustedTime()
    {
        return getText(R.string.dialog_text_untrusted_time);
    }

    protected CharSequence getDialogButtonNo()
    {
        return getText(R.string.no);
    }

    protected CharSequence getDialogButtonYes()
    {
        return getText(R.string.yes);
    }

    protected CharSequence getDialogTextRetrieveLicenseQuestion()
    {
        return getText(R.string.dialog_text_retrieve_license_question);
    }

    protected CharSequence getDialogTextRequestingLicense()
    {
        return getText(R.string.dialog_text_requesting_license);
    }

    protected CharSequence getDialogTextInstallingLicense()
    {
        return getText(R.string.dialog_text_installing_license);
    }

    protected CharSequence getDialogTextAcknowledgingLicense()
    {
        return getText(R.string.dialog_text_acknowledging_license);
    }

    protected CharSequence getDialogButtonCancel()
    {
        return getText(R.string.dialog_button_cancel);
    }

    protected CharSequence getDialogTitle()
    {
        return getText(R.string.dialog_title);
    }

    protected CharSequence getDialogTextErrorRetrievingLicense()
    {
        return getText(R.string.dialog_text_error_retrieving_license);
    }

    protected CharSequence getDialogButtonOK()
    {
        return getText(R.string.dialog_button_ok);
    }

    protected CharSequence getDialogTextTimeoutRetrievingLicense()
    {
        return getText(R.string.dialog_text_timeout_retrieving_license);
    }

    protected CharSequence getDialogButtonPlay()
    {
        return getText(R.string.dialog_button_play);
    }

    protected CharSequence getDialogTextLicenseRetrieved()
    {
        return getText(R.string.dialog_text_license_retrieved);
    }

    public CharSequence getDialogTextPolicyCheckFailed()
    {
        return getText(R.string.dialog_text_policy_check_failed);
    }

    public CharSequence getDialogTextJoinDomainQuestion()
    {
        return getText(R.string.dialog_text_join_domain_question);
    }

    protected CharSequence getDialogTextJoiningDomain()
    {
        return getText(R.string.dialog_text_joining_domain);
    }
    protected CharSequence getDialogTextJoinDomainCompleted()
    {
        return getText(R.string.dialog_text_joining_domain_completed);
    }
    protected boolean getJoinDomainSilently()
    {
        return false;
    }

    /**
     * Method responsible for initiating delegated join domain within the sample application.  The actual
     * join is spun out to a separate thread doing the HTTP Post as well as into one waiting & controlling
     * the UI
     */
    private void initiateJoinDomain()
    {
        // Reset the flag whether or not the acquisition has been cancelled
        // This is set to true if the user cancels
        mLicenseAcquisitionResult = LicenseAcquisitionResult.NONE;

        // Use the latch to synchronize between the two threads
        final CountDownLatch countDownLatch = new CountDownLatch(1);

        removeDialog(LicenseAcquisitionActivity.JOIN_DOMAIN_REQUIRED);
        showDialog(LicenseAcquisitionActivity.RETRIEVING_JOIN_DOMAIN);

        // This thread is responsible for doing the SOAP call out to the PlayReady Domain Controller Server.  It will post the
        // SOAP challenge together with the correct headers etc to the URL provided
        final Thread joinDomainThread = new Thread()
        {
            @Override
            public void run()
            {
                mPlayReadyDRMJoinDomainHandler = new PlayReadyDRMJoinDomainHandler()
                {

                    @Override
                    public void joinDomainInstalled()
                    {
                        setLicenseAcquisitionResult(LicenseAcquisitionResult.JOIN_DOMAIN_SUCCESS);
                        countDownLatch.countDown();
                    }

                    @Override
                    public void error(final String errorMessage, final Exception exception)
                    {
                        super.error(errorMessage, exception);
                        setLicenseAcquisitionResult(LicenseAcquisitionResult.ERROR);
                        countDownLatch.countDown();
                    }
                    @Override
                    public void joinDomain(URL domainControllerURL, String joinDomainChallenge)
                    {
                        super.joinDomain(domainControllerURL, joinDomainChallenge);
                    }

                };
                final boolean b = DRMAgentDelegate.joinDomain(LicenseAcquisitionActivity.this, mAcquireLicenseResponse, mPlayReadyDRMJoinDomainHandler);
            }
        };

        // This is the waiting thread which is responsible for displaying the correct dialog for the progress of
        // the join domain.  It will, after successful installation or a time-out, display the result.
        final Thread waitingThread = new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    // This waits for the activation callback to occur - for up to 20 seconds
                    final boolean activated = countDownLatch.await(LICENSE_ACQUISITION_MAX_WAIT, TimeUnit.SECONDS);

                    if (!activated)
                    {
                        setLicenseAcquisitionResult(LicenseAcquisitionResult.TIMEOUT);
                    }

                    Log.d(TAG,"Wait completed: " + mLicenseAcquisitionResult);

                    // This call will run on the GUI thread, which allows the dialogs to be cleared (removed)
                    // and updated with the status of the entitlement acquisition
                    mHandler.post(new Runnable()
                    {
                        public void run()
                        {
                            handleAcquisitionWaitCompleted(mLicenseAcquisitionResult, LicenseAcquisitionActivity.RETRIEVING_JOIN_DOMAIN);
                        }
                    });
                }
                catch (InterruptedException e)
                {
                    // Safe to ignore
                }
            }
        };

        // Finally, we start the threads
        joinDomainThread.start();
        waitingThread.start();
    }


    /**
     * Method responsible for initiating delegated license acquisition within the sample application.  The actual
     * acquisition is spun out to a separate thread doing the HTTP Post as well as into one waiting & controlling
     * the UI
     */
    protected void initiateRightsIssuerLicenseAcquisition()
    {
        // Reset the flag whether or not the acquisition has been cancelled
        // This is set to true if the user cancels
        mLicenseAcquisitionResult = LicenseAcquisitionResult.NONE;

        // Use the latch to synchronize between the two threads
        final CountDownLatch countDownLatch = new CountDownLatch(1);

        setupDialogsRetrievingLicense();

        // This thread is responsible for doing the SOAP call out to the PlayReady License Server.  It will post the
        // SOAP challenge together with the correct headers etc to the URL provided
        final Thread licenseAcquisitionThread = new Thread()
        {
            @Override
            public void run()
            {
                boolean usePlayReadyDRMLicenseAcquisitionHandler = true;

                final DRMScheme drmScheme = mDRMContentInfo.mDRMContent.getDRMScheme();

                if (mDRMContentInfo.mDRMContent.getDRMContentFormat() == DRMContentFormat.WINDOWS_MEDIA)
                {
                    switch (drmScheme)
                    {
                        case PLAYREADY:
                            Log.d(TAG, "Windows Media Content format detected with DRM scheme of PlayReady, will use cocktail license");
                            usePlayReadyDRMLicenseAcquisitionHandler = true;
                            break;
                        case WMDRM:
                        default:
                            usePlayReadyDRMLicenseAcquisitionHandler = false;
                    }
                }

                if (usePlayReadyDRMLicenseAcquisitionHandler)
                {
                    mDRMLicenseAcquisitionHandler = new PlayReadyDRMLicenseAcquisitionHandler()
                    {
                        private String _profile = null;

                        @Override
                        protected void processResponse(final URL url, final HttpResponse response)
                        {
                            if (mRetrievingLicenseDialog != null)
                            {
                                LicenseAcquisitionActivity.this.runOnUiThread(new Runnable()
                                {
                                    public void run()
                                    {
                                        if (mLicenseAcquisitionResult != LicenseAcquisitionResult.LICENSE_ACKNOWLEDGEMENT_REQUESTED)
                                        {
                                            mRetrievingLicenseDialog.setMessage(getDialogTextInstallingLicense());
                                        }
                                    }
                                });
                            }
                            super.processResponse(url, response);
                        }

                        //override to handle join domain in this activity
                        @Override
                        protected boolean joinDomainRequired(final byte[] acquireLicenseResponse, final String customData)
                        {
                            Log.d(TAG, "Hit joinDomainRequired; joinDomainSilently=" + getJoinDomainSilently());

                            if(getJoinDomainSilently())
                            {
                                return super.joinDomainRequired(acquireLicenseResponse, customData);
                            }
                            else
                            {
                                setLicenseAcquisitionResponse(acquireLicenseResponse);

                                setLicenseAcquisitionResult(LicenseAcquisitionResult.JOIN_DOMAIN_REQUIRED);

                                countDownLatch.countDown();

                                //return false to handle license acquisition in this activity
                                return false;
                            }
                        }

                        @Override
                        protected void processError(final PlayReadySoapError error)
                        {
                            if(error != null)
                            {
                                String faultCode = error.getFaultCode();
                                String faultString = error.getFaultString();
                                String faultActor = error.getFaultActor();
                                String statusCode = error.getStatusCode();
                                String serviceId = error.getServiceId();
                                String customData = error.getCustomData();
                                String redirectUrl = error.getRedirectUrl();

                                Log.d(TAG, "Received PlayReady Soap Error: ");
                                Log.d(TAG, "    FaultCode: " + faultCode);
                                Log.d(TAG, "    FaultString: " + faultString);
                                Log.d(TAG, "    FaultActor: " + faultActor);
                                Log.d(TAG, "    StatusCode: " + statusCode);
                                Log.d(TAG, "    ServiceId: " + serviceId);
                                Log.d(TAG, "    CustomData: " + customData);
                                Log.d(TAG, "    RedirectUrl: " + redirectUrl);
                            }
                            return;
                        }

                        @Override
                        protected boolean isCancelled()
                        {
                            return mLicenseAcquisitionResult == LicenseAcquisitionResult.CANCELLED;
                        }

                        @Override
                        protected void cancelled()
                        {
                            countDownLatch.countDown();
                        }

                        @Override
                        protected void licenseAcknowledged()
                        {
                            if (!useAsynchLicenseAcknowledgement())
                            {
                                setLicenseAcquisitionResult(LicenseAcquisitionResult.SUCCESS);
                                countDownLatch.countDown();
                            }
                            else
                            {
                                LicenseAcquisitionActivity.this.runOnUiThread(new Runnable()
                                {
                                    public void run()
                                    {
                                        Toast.makeText(LicenseAcquisitionActivity.this, "License acknowledged", Toast.LENGTH_SHORT).show();
                                    }
                                });


                            }
                        }

                        @Override
                        public void licenseInstalled()
                        {
                            if (mLicenseAcquisitionResult != LicenseAcquisitionResult.LICENSE_ACKNOWLEDGEMENT_REQUESTED)
                            {
                                setLicenseAcquisitionResult(LicenseAcquisitionResult.SUCCESS);
                                countDownLatch.countDown();
                            }
                        }

                        @Override
                        protected void licenseAcknowledgementRequested(final URL laURL, final String ackMessage)
                        {
                            if (!useAsynchLicenseAcknowledgement())
                            {
                                setLicenseAcquisitionResult(LicenseAcquisitionResult.LICENSE_ACKNOWLEDGEMENT_REQUESTED);
                                if (mRetrievingLicenseDialog != null)
                                {
                                    LicenseAcquisitionActivity.this.runOnUiThread(new Runnable()
                                    {
                                        public void run()
                                        {
                                            mRetrievingLicenseDialog.setMessage(getDialogTextAcknowledgingLicense());
                                        }
                                    });
                                }
                            }
                            super.licenseAcknowledgementRequested(laURL, ackMessage);
                        }


                        @Override
                        public void error(final String errorMessage, final Exception exception)
                        {
                            setLicenseAcquisitionResult(LicenseAcquisitionResult.ERROR);
                            countDownLatch.countDown();
                        }

                        @Override
                        protected void setupRequest(final URL url, final HttpRequestBase httpRequestBase)
                        {
                            if (_profile != null)
                            {
                                Log.d(TAG, "Profile setup, adding to request: " + _profile);

                                httpRequestBase.addHeader("xmlProfile", _profile);
                            }

                            super.setupRequest(url, httpRequestBase);
                        }

                        @Override
                        public void acquireLicense(final DRMContent drmContent, final URL laURL, final String challenge)
                        {
                            Log.d(TAG, "Acquiring license from: " + laURL);

                            if (laURL.toString().contains("Guido"))
                            {
                                final SharedPreferences sharedPreferences = getSharedPreferences(Constants.PREFERENCES_FILENAME, Context.MODE_PRIVATE);
                                final boolean forceTimeBasedLicense = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_TIMEBASED_LICENSE_FOR_CONTENT, false);
                                final boolean forceOPLBasedLicense = sharedPreferences.getBoolean(Constants.PREFERENCES_FORCE_OPL_LICENSE_FOR_CONTENT, false);
                                int numMinutes = sharedPreferences.getInt(Constants.PREFERENCES_TIMEBASED_LICENSE_NUM_MINUTES,5);
                                int oplLevel = sharedPreferences.getInt(Constants.PREFERENCES_OPL_LICENSE_LEVEL,100);

                                Log.d(TAG, "Detected the GUIDO license server issuer - will add required headers");

                                // Add the profile as a header
                                _profile = (forceOPLBasedLicense ? "<profile><play uncompressedDigitalVideoProtection=\"" + oplLevel + "\">" : "<profile><play>");
                                if (forceTimeBasedLicense)
                                {
                                    final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                                    final TimeZone utc = TimeZone.getTimeZone("UTC");
                                    dateFormat.setTimeZone(utc);
                                    dateFormat.setLenient(false);

                                    Calendar now = GregorianCalendar.getInstance(utc);
                                    now.add(Calendar.SECOND, -1 * (numMinutes * 60));
                                    Calendar then = GregorianCalendar.getInstance(utc);
                                    then.add(Calendar.SECOND, numMinutes * 60);

                                   _profile += "<datetime><start>" + dateFormat.format(now.getTime()) + "</start><end>" + dateFormat.format(then.getTime()) + "</end></datetime>";
                                }
                                _profile += "</play></profile>";

                                super.acquireLicense(drmContent, laURL, challenge);
                            }
                            else
                            {
                                // If not a special 'Guido' URL, simply use the acquisition helper to (possibly)
                                // rewrite the LA url (based on configuration settings and such) to the URL to
                                // use
                                final URL newLicenseAcquisitionURL = LicenseAcquisitionHelper.performURLRewrite(LicenseAcquisitionActivity.this,laURL,mDRMContentInfo);
                                super.acquireLicense(drmContent, newLicenseAcquisitionURL, challenge);
                            }

                        }
                    };
                    ((PlayReadyDRMLicenseAcquisitionHandler)mDRMLicenseAcquisitionHandler).setAcknowledgeLicenseAsynchronously(useAsynchLicenseAcknowledgement());
                }
                else
                {
                    mDRMLicenseAcquisitionHandler = new WMDRMLicenseAcquisitionHandler()
                    {

                        @Override
                        protected boolean isCancelled()
                        {
                            return mLicenseAcquisitionResult != LicenseAcquisitionResult.NONE;
                        }

                        @Override
                        protected void cancelled()
                        {
                            countDownLatch.countDown();
                        }

                        @Override
                        public void licenseInstalled()
                        {
                            setLicenseAcquisitionResult(LicenseAcquisitionResult.SUCCESS);
                            countDownLatch.countDown();
                        }

                        @Override
                        public void error(final String errorMessage, final Exception exception)
                        {
                            Log.d(TAG,"Error received: " + errorMessage);
                            setLicenseAcquisitionResult(LicenseAcquisitionResult.ERROR);
                            countDownLatch.countDown();
                        }
                    };
                }

                final boolean b = DRMAgentDelegate.activateDRMContent(LicenseAcquisitionActivity.this, mDRMContentInfo.mDRMContent, mDRMLicenseAcquisitionHandler);


            }
        };

        // This is the waiting thread which is responsible for displaying the correct dialog for the progress of
        // the license acquisition.  It will, after successful installation or a time-out, display the result.
        final Thread waitingThread = new Thread()
        {
            @Override
            public void run()
            {
                try
                {
                    // This waits for the activation callback to occur - for LICENSE_ACQUISITION_MAX_WAIT up to seconds
                    final boolean activated = countDownLatch.await(LICENSE_ACQUISITION_MAX_WAIT, TimeUnit.SECONDS);

                    Log.d(TAG,"Wait completed: " + mLicenseAcquisitionResult);
                    if (!activated)
                    {
                        Log.d(TAG,"Not activated, setting timeout as result");
                        setLicenseAcquisitionResult(LicenseAcquisitionResult.TIMEOUT);
                    }


                    // This call will run on the GUI thread, which allows the dialogs to be cleared (removed)
                    // and updated with the status of the license acquisition
                    mHandler.post(new Runnable()
                    {
                        public void run()
                        {
                            handleAcquisitionWaitCompleted(mLicenseAcquisitionResult, LicenseAcquisitionActivity.RETRIEVING_LICENSE);
                        }
                    });
                }
                catch (InterruptedException e)
                {
                    // Safe to ignore
                }

            }
        };

        // Finally, we start the threads
        licenseAcquisitionThread.start();
        waitingThread.start();

    }

    protected void setupDialogsRetrievingLicense()
    {
        removeDialog(LicenseAcquisitionActivity.NO_LICENSE);
        showDialog(LicenseAcquisitionActivity.RETRIEVING_LICENSE);
    }

    protected void handleAcquisitionWaitCompleted(final LicenseAcquisitionResult licenseAcquisitionResult, final int dialogToRemove)
    {
        removeDialog(dialogToRemove);
        switch (licenseAcquisitionResult)
        {
            case CANCELLED:
                Log.v(TAG, "Entitlement acquisition cancelled on user request, simply returning to home activity");
                removeDialog(LicenseAcquisitionActivity.CANCELLING_RETRIEVING_LICENSE);
                finish();
                return;
            default:
                showDialog(resolveDialogForLicenseAcquisitionResult(licenseAcquisitionResult));
        }
    }

    protected int resolveDialogForLicenseAcquisitionResult(final LicenseAcquisitionResult licenseAcquisitionResult)
    {
        switch (licenseAcquisitionResult)
        {
            case SUCCESS:
                return LicenseAcquisitionActivity.LICENSE_RETRIEVED;
            case TIMEOUT:
                return LicenseAcquisitionActivity.TIMEOUT_RETRIEVING_LICENSE;
            case ERROR:
                return LicenseAcquisitionActivity.ERROR_RETRIEVING_LICENSE;
            case JOIN_DOMAIN_REQUIRED:
                return LicenseAcquisitionActivity.JOIN_DOMAIN_REQUIRED;
            case JOIN_DOMAIN_SUCCESS:
                return LicenseAcquisitionActivity.JOIN_DOMAIN_COMPLETED;
            case NONE:
                throw new IllegalStateException("LicenseAcquisitionResult not even set!");
            default:
                throw new IllegalStateException("Unhandled result: " + licenseAcquisitionResult);
        }
    }

    private void setLicenseAcquisitionResult(final LicenseAcquisitionResult licenseAcquisitionResult)
    {
        mLicenseAcquisitionResultLock.lock();
        try
        {
            if (mLicenseAcquisitionResult == null || mLicenseAcquisitionResult == LicenseAcquisitionResult.NONE || mLicenseAcquisitionResult == LicenseAcquisitionResult.LICENSE_ACKNOWLEDGEMENT_REQUESTED)
            {
                mLicenseAcquisitionResult = licenseAcquisitionResult;
            }
        }
        finally
        {
            mLicenseAcquisitionResultLock.unlock();
        }
    }

    private void setLicenseAcquisitionResponse(final byte[] acquireLicenseResponse)
    {
        mAcquireLicenseResponse = acquireLicenseResponse;
    }

    protected static enum LicenseAcquisitionResult
    {
        NONE, SUCCESS, TIMEOUT, CANCELLED, ERROR, JOIN_DOMAIN_REQUIRED, JOIN_DOMAIN_SUCCESS, LICENSE_ACKNOWLEDGEMENT_REQUESTED
    }
}
