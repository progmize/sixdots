//
//  Fault.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Fault : NSObject {
  NSString *typeName;
  NSString *message;
  NSString *displayMessage;
  NSString *details;
}

@property (copy) NSString *typeName;
@property (copy) NSString *message;
@property (copy) NSString *displayMessage;
@property (copy) NSString *details;

- (BOOL) isSessionTimeout;
- (BOOL) isAccessDenied;
- (BOOL) isAccessToContentDenied;
@end
