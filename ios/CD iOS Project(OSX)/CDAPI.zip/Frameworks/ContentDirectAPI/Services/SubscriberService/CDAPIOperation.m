//
// CHAPIOperation.m
// Chicago
//
// Created by Brian Cooke on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CDAPIOperation.h"

@implementation CDAPIOperation

+ (CHAPIOperation *)operationToSearchForProductsWithFullText:(__unsafe_unretained NSString *)fullText limit:(int)maximumNumberOfProductsToReturn page:(int)pageNumber {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];

	// TODO implement limit and page in underlying API
	SEL sel = @selector(fullTextSearchForString:forPage:pageSize:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation setArgument:&fullText atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
    [ret.invocation setArgument:&pageNumber atIndex:3];
    [ret.invocation setArgument:&maximumNumberOfProductsToReturn atIndex:4];
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveProductByProductID:(__unsafe_unretained NSString *)productID {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveProductByProductID:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation setArgument:&productID atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToViewProductContent:(__unsafe_unretained Product *)product {
    //NSLog(@"CHAPIOperation -operationToViewProductContent:");
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(viewProductContent:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation setArgument:&product atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation retainArguments];

	return ret;
}


+ (CHAPIOperation *)operationToLoginWithLogin:(__unsafe_unretained NSString *)login password:(__unsafe_unretained NSString *)password {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(loginWithLogin:password:);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation setArgument:&login atIndex:2]; // starts at 2 as 0 & 1 are self and cmd
	[ret.invocation setArgument:&password atIndex:3];
	[ret.invocation retainArguments];

	return ret;
}

+ (CHAPIOperation *)operationToLogout {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(requestToLogout);
	
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation retainArguments];
	
	return ret;
}

+ (CHAPIOperation *)operationToRetrieveSubscriberInfo {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveSubscriberInfo);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];

	return ret;
}


+ (CHAPIOperation *)operationToRetrieveCodes {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveCodes);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];

	return ret;
}


+ (CHAPIOperation *)operationToRegisterDevice {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(registerSubscriberDevice);

	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];

	return ret;
}


+ (CHAPIOperation *)operationToSendPing {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(sendPing);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];  
	return ret;  
}


+ (CHAPIOperation *)operationToRetrieveSubscriberProducts {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(retrieveSubscriberProducts);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	return ret;    
}


+ (CHAPIOperation *)operationToUnregisterDeviceWithSubscriberID:(__unsafe_unretained NSString *)subscriberID {
	CHAPIOperation *ret = [[CHAPIOperation alloc] init];
	SEL             sel = @selector(removeSubscriberDeviceWithSubscriberID:);
  
	ret.invocation = [NSInvocation invocationWithMethodSignature:[[CDServiceFacade sharedCDServiceFacade] methodSignatureForSelector:sel]];
	[ret.invocation setSelector:sel];
	[ret.invocation setTarget:[CDServiceFacade sharedCDServiceFacade]];
	[ret.invocation setArgument:&subscriberID atIndex:2];
	[ret.invocation retainArguments];
  
	return ret;      
}


- (void)main
{
	assert(self.delegate);
	[CDServiceFacade sharedCDClient].delegate = self.delegate;
	[self.invocation invoke];
}


@synthesize delegate = ch_delegate, invocation = ch_invocation;
@end
