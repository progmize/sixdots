//
// CHLibraryViewController.m
// Chicago
//
// Created by louie on 8/6/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHLibraryViewController.h"
#import "Product.h"
#import "CHDetailsViewController.h"
#import "CHProductListCell.h"
#import "CHAPIOperation.h"
#import "Fault.h"
#import "CHSettings.h"

@implementation CHLibraryViewController


- (void)cleanup {
    self.products    = nil;
    self.progressHUD = nil;
}


- (void)dealloc {
    [self cleanup];
}


// Reuse the CHBrowseCategoryView NIB since it is pretty much the same look we want.
- (id)init {
    if ((self = [super initWithNibName:@"CHBrowseCategoryView" bundle:nil])) {
        self.libraryItem   = YES;
        self.loggedInRequired = YES;
        self.authenticatedRequired = NO;
        self.products      = [NSArray array];
    }
    
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = NSLocalizedString(@"LIBRARY_TEXT", @"Library");
    
	self.view.backgroundColor = kCHViewBackgroundColor;
	self.tableView.backgroundColor = kCHTableViewBackgroundColor;
	self.tableView.separatorColor = kCHTableViewBackgroundColor;
    
    self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
    [self.view addSubview:self.progressHUD];
    retryCount = 0;
}


- (void)showLoggedInUI {
    [super showLoggedInUI];
    
    if ([self.products count] == 0) {
        self.progressHUD.labelText = NSLocalizedString(@"MEDIA_VIDEO_LOADING", @"Loading...");
        [self.progressHUD show:YES];
    }
    
    CHAPIOperation *op = [CHAPIOperation operationToRetrieveSubscriberProducts];
    op.delegate = self;
    [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}

#pragma mark -
#pragma mark CDClientDelegate
- (void)retrievedSubscriberProducts:(NSArray *)products {
    
    if ([products count] > 0) {
        //NSLog(@"%d subscriber products returned", [products count]);
        // manually go through the products making sure we strip out dupes
        NSMutableArray *tempProducts = [NSMutableArray arrayWithCapacity:[products count]];
        
        for (Product *p in products) {
            if ([tempProducts indexOfObject:p] == NSNotFound) {
                [tempProducts addObject:p]; 
            }
        }
        self.products = tempProducts;
        [self.tableView reloadData];
    }
    else {
        //NSLog(@"NO subscriber products returned");
        CGFloat labelWidth = 300;
        CGFloat labelHeight = 100;
        CGRect labelRect = CGRectMake(self.view.frame.size.width / 2 - labelWidth/2, self.view.frame.size.height / 2 - labelHeight/2, labelWidth, labelHeight);
        UILabel *label = [[UILabel alloc] initWithFrame:labelRect];
        label.backgroundColor = [UIColor whiteColor];
        label.numberOfLines = 2;
        label.textAlignment = UITextAlignmentCenter;
        label.text = NSLocalizedString(@"LIBRARY_NO_ITEMS", @"No items have been added\nto your library yet.");
        [self.view addSubview:label];
    }
    
    [self.progressHUD hide:YES];
    retryCount = 0;
}


- (void)retrievedSubscriberProductsFailedWithFault:(Fault *)aFault {
    if ([aFault isSessionTimeout] && [self.products count] > 0 && retryCount < 3) {
        // try again, the ping failure should cause a new session to be started and we can
        retryCount++;
        [self performSelector:@selector(showLoggedInUI) withObject:nil afterDelay:3.0];
        return;
    } 
    
    if ([aFault isSessionTimeout]) {
        // prevent it from rolling up while it was still rolling down. 
        [self performSelector:@selector(promptLogin) withObject:nil afterDelay:0.5];
    } else {
        [self.progressHUD hide:YES];
        [aFault showWithTitle:NSLocalizedString(@"MEDIA_VIDEO_LOADING", @"Failed to load library")];
    }
}

#pragma mark -
#pragma mark PurchasProductDelegate
- (void)purchaseProduct:(Product *)product {
    [super purchaseProduct:product];
}

- (void)showDetailsForProduct:(Product *)product {
    [super showDetailsForProduct:product];
}


@synthesize products, progressHUD;

@end
