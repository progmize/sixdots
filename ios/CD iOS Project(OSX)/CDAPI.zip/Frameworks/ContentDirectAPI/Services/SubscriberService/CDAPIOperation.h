//
// CHAPIOperation.h
// Chicago
//
// Created by Brian Cooke on 8/4/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CDClient.h"
#import "CDAPIOperationQueue.h"


@interface CDAPIOperation : NSOperation {
	id <CDClientDelegate> __unsafe_unretained ch_delegate;
	NSInvocation        *ch_invocation;
}

@property (nonatomic, unsafe_unretained) id<CDClientDelegate> delegate;
@property (nonatomic, strong) NSInvocation        *invocation;

+ (CDAPIOperation *)operationToViewProductContent:(Product *)product;
+ (CDAPIOperation *)operationToLoginWithLogin:(NSString *)login password:(NSString *)password;
+ (CDAPIOperation *)operationToLogout;
+ (CDAPIOperation *)operationToRetrieveSubscriberInfo;
+ (CDAPIOperation *)operationToSearchForProductsWithFullText:(NSString *)fullText limit:(int)maximumNumberOfProductsToReturn page:(int)pageNumber;
+ (CDAPIOperation *)operationToRetrieveProductByProductID:(NSString *)productID;
+ (CDAPIOperation *)operationToRetrieveCodes;
+ (CDAPIOperation *)operationToRegisterDevice;
+ (CDAPIOperation *)operationToSendPing;
+ (CDAPIOperation *)operationToRetrieveSubscriberProducts;
+ (CDAPIOperation *)operationToUnregisterDeviceWithSubscriberID:(NSString *)subscriberID;

@end
