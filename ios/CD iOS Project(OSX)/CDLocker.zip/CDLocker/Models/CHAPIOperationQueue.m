//
//  CHAPIOperationQueue.m
//  Chicago
//
//  Created by Brian Cooke on 8/4/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHAPIOperationQueue.h"
#import "SynthesizeSingleton.h"

@implementation CHAPIOperationQueue

SYNTHESIZE_SINGLETON_FOR_CLASS(CHAPIOperationQueue);


//------------------------------------------------------------------------------
// init
//------------------------------------------------------------------------------
- (id) init
{
  if ((self = [super init])) {
    self.maxConcurrentOperationCount = 10;
// Only available in iOS 4.  I don't think this contributes much to the app, so commenting out.
//    self.name = @"CDClientOperationQueue";
  }
  return self;
}

- (void)addOperation:(NSOperation *)operation {
    //NSLog(@"CHAPIOperationQueue -addOperation:%@", operation);
    [super addOperation:operation];
}

@end
