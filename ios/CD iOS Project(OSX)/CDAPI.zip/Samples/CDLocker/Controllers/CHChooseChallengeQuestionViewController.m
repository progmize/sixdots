//
// CHChooseChallengeQuestionViewController.m
// Chicago
//
// Created by louie on 8/18/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHChooseChallengeQuestionViewController.h"
#import "Code.h"

@implementation CHChooseChallengeQuestionViewController

@synthesize tableView = ch_tableView;
@synthesize codes;
@synthesize delegate;
@synthesize selectedChallengeQuestion;

- (id)init {
  if ((self = [super initWithNibName:@"CHChooseChallengeQuestionView" bundle:nil])) {
    // Custom initialization
  }

  return self;
}

- (void)viewDidLoad {
  [super viewDidLoad];
  
  self.title = @"Choose Challenge";
  
  self.view.backgroundColor      = kCHViewBackgroundColor;
  self.tableView.backgroundColor = kCHTableViewBackgroundColor;

  self.tableView.dataSource = self;
  self.tableView.delegate   = self;

  self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"ORDER_PROCESS_BILLING_CANCEL", @"Cancel")
                                                                            style:UIBarButtonItemStyleBordered 
                                                                           target:self
                                                                           action:@selector(cancel)];
  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]
                                             initWithTitle:NSLocalizedString(@"ACCOUNT_CHOOSE_BUTTON_TEXT", @"Choose")
                                                     style:UIBarButtonItemStyleDone
                                                    target:self
                                                    action:@selector(done)];
}

- (void)cleanup {
	ch_tableView = nil;
}

- (void)viewDidUnload {
	[self cleanup];
}

- (void)dealloc {
	[self cleanup];
	
}


- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];

  // Store the selected question
  if ([self.selectedChallengeQuestion isEqualToString:kCHChooseAPassword]) {
    [self.tableView selectRowAtIndexPath:nil animated:YES scrollPosition:UITableViewScrollPositionNone];
  }
}


#pragma mark -
#pragma mark UITableViewDataSource/Delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return 1;
}


- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section {
  return [self.codes count];
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  static NSString * cellId = @"passQuestion";

  UITableViewCell * cell = [tv dequeueReusableCellWithIdentifier:cellId];

  if (cell == nil) {
    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		cell.accessoryType  = UITableViewCellAccessoryNone;
		cell.textLabel.numberOfLines  = 2;
		cell.textLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:12];
  }

  cell.textLabel.text = [[self.codes objectAtIndex:indexPath.row] name];
  return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  UITableViewCell * theCell = [tableView cellForRowAtIndexPath:indexPath];

  theCell.accessoryType          = UITableViewCellAccessoryCheckmark;
  self.selectedChallengeQuestion = [[self.codes objectAtIndex:indexPath.row] name];

  for (int i = 0; i < [self.codes count]; ++i) {
    if (i == indexPath.row) {
      continue;
    }

    UITableViewCell * otherCell    = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
    otherCell.accessoryType = UITableViewCellAccessoryNone;
  }
}


#pragma mark Button Actions
- (void)cancel {
  // Pop myself off stack
  [self.navigationController popViewControllerAnimated:YES];
}


- (void)done {
  // Communicate back to my caller which payment method was chosen
  [self.delegate userChoseChallengeQuestion:self.selectedChallengeQuestion];
  // Pop myself off stack
  [self.navigationController popViewControllerAnimated:YES];
}


@end
