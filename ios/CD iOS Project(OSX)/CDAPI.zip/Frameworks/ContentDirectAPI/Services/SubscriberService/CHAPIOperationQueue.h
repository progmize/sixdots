//
//  CHAPIOperationQueue.h
//  Chicago
//
//  Created by Brian Cooke on 8/4/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CHAPIOperationQueue : NSOperationQueue {

}

+ (CHAPIOperationQueue *) sharedCHAPIOperationQueue;
- (void)addOperation:(NSOperation *)operation;

@end
