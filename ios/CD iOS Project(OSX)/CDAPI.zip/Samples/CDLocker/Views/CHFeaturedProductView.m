//
// CHFeaturedProductView.m
// Chicago
//
// Created by Derr on 8/5/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHFeaturedProductView.h"
#import "ImageCache.h"
#import "CDClient.h"
#import "SDWebImageManager.h"

@interface CHFeaturedProductView (Private)
- (void)showThumbnailImage;
@end

@implementation CHFeaturedProductView

@synthesize delegate;
@synthesize thumbnailURL;

- (id)initWithFrame:(CGRect)frame {
    return [self initWithFrame:frame style:CHFeaturedProductViewStyleBrowse];
}


- (id)initWithFrame:(CGRect)frame style:(CHFeaturedProductViewStyle)style {
    if ((self = [super initWithFrame:frame])) {
        self.clipsToBounds = YES;
#include "CHFeaturedProductViewLayout.h"
        ch_image        = imageview10;
        ch_title        = label11;
        ch_subTitle     = label12;
        ch_buyButton    = button13;
        ch_rating       = view17;
        ch_guidence     = label15;
		
        
        
        // Stretch image if needed
        imageview16.contentMode = UIViewContentModeScaleToFill;
        
        if (style == CHFeaturedProductViewStyleFeatured) {
            imageview16.image = [UIImage imageNamed:@"featured_background.png"];
        } else {
            imageview16.image = [UIImage imageNamed:@"browse_background.png"];
        }
        
        [ch_buyButton setBackgroundImage:[UIImage imageNamed:@"button.png"] forState:UIControlStateNormal];
		CGRect view1Frame = view1.frame;
		view1Frame.size = frame.size;
		view1.frame = view1Frame;
        [self addSubview:view1];
        
        [ch_buyButton addTarget:self action:@selector(buyButtonTapped) forControlEvents:UIControlEventTouchUpInside];
        
        [ch_image addTarget:self action:@selector(thumbnailTapped) forControlEvents:UIControlEventTouchUpInside];
    }
    
    return self;
}


- (void)dealloc {
    ch_image = nil;
    ch_title = nil;
    ch_subTitle = nil;
    ch_buyButton = nil;
    ch_rating = nil;
    ch_guidence = nil;
    ch_product = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (void)setUpProductButton:(NSString *)buttonLabel isHidden:(BOOL)isHidden
{
	[ch_buyButton setTitle:buttonLabel forState:UIControlStateNormal];
	[ch_buyButton setHidden:isHidden];
}

- (void)setProduct:(Product *)product {
    ch_title.text    = product.name;
    ch_subTitle.text = product.shortDescription;
    ch_rating.stars = product.peerRating;
    
	/* TODO Remove after testing.
    if (self.libraryItem || [[AppDelegate sharedCDClient] doesUserOwnProduct:product]) {
        if (product.isSubscription) {
            [ch_buyButton setTitle:NSLocalizedString(@"LIBRARY_SUBSCRIBED_BUTTON_TEXT", @"Subscribed") forState:UIControlStateNormal];
            ch_buyButton.enabled = NO;
        } else {
            [ch_buyButton setTitle:NSLocalizedString(@"DIALOG_POPUP_PURCHASE_SUCCESS_VIEW_BUTTON", @"View") forState:UIControlStateNormal];
        }
    }	else {
        [ch_buyButton setTitle:[product formattedPrice] forState:UIControlStateNormal];
    }
	*/
	
	NSString *buttonLabel = @"";
	BOOL isHidden;
	
	if([[product orderingType] isEqualToString:@"BrowseOnlyNotOrderable"]) // Browse only = don't show the button at all
	{
		// Just being explicit here
		buttonLabel = @"";
		isHidden = true;
	}
    else if([[CDLockerAppDelegate sharedCDClient] doesUserOwnProduct:product]) 
	{
		isHidden = false;
		// Orderable (purchased) AvailabilityDate in future = 'Available Soon'
		NSDate *now = [[NSDate alloc] initWithTimeIntervalSinceNow:0];
		if([now compare:product.availabilityStartDate] == NSOrderedDescending)
		{
			buttonLabel = NSLocalizedString(@"PRODUCT_AVAILABLE_SOON", @"Available Soon");
		}
		else
		{
			buttonLabel = NSLocalizedString(@"DIALOG_POPUP_PURCHASE_SUCCESS_VIEW_BUTTON", @"View");
		}
    }
	else if([[product orderingType] isEqualToString:@"InstantlyViewableNotOrderable"])
	{
		isHidden = false;
		buttonLabel = NSLocalizedString(@"DIALOG_POPUP_PURCHASE_SUCCESS_VIEW_BUTTON", @"View");
	}
	else // Orderable (not purchased) = show the price
	{
		isHidden = false;
        buttonLabel = [product formattedPrice];
    }
    
	[self setUpProductButton:buttonLabel isHidden:isHidden];
    
    self.thumbnailURL = [NSURL URLWithString:product.thumbnailURL];
    [self showThumbnailImage];
    
	if( [product getGuidanceRatingLabel] != @"" )
	{
		[ch_guidence setText:[product getGuidanceRatingLabel]];
	}
	
    // Set instance variable
    ch_product = product;
}


- (void)buyButtonTapped {
    [self.delegate purchaseProduct:ch_product];
}


- (void)thumbnailTapped {
    [self.delegate showDetailsForProduct:ch_product];
}



- (void)showThumbnailImage {
    if ( ! self.thumbnailURL ) return;
    
	
    UIImage * thumbnailImage = [[SDWebImageManager sharedManager] imageWithURL:self.thumbnailURL];
    
	if (thumbnailImage) {
		if (ch_image) {
			[ch_image setBackgroundImage:thumbnailImage forState:UIControlStateNormal];
		}
	} else {
		[[SDWebImageManager sharedManager] downloadWithURL:self.thumbnailURL delegate:self];
	}
}


#pragma mark SDWebImageManagerDelegate notifications
- (void)webImageManager:(SDWebImageManager *)imageManager didFinishWithImage:(UIImage *)image {
    //[self performSelectorOnMainThread:@selector(showThumbnailImage) withObject:nil waitUntilDone:NO];
	[ch_image setBackgroundImage:image forState:UIControlStateNormal];
	[self layoutSubviews];
}


#pragma mark ImageCache notifications
- (void)imageWasDownloaded:(id)object {
    [self performSelectorOnMainThread:@selector(showThumbnailImage) withObject:nil waitUntilDone:NO];
}


@synthesize libraryItem = ch_libraryItem;
@end
