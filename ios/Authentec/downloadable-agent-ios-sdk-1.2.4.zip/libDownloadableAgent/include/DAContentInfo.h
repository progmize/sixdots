//
//  DAContentInfo.h
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DADataTypes.h"

/**
 The object that holds all the exposed information about a protected content.
 */
@interface DAContentInfo : NSObject 

/**
 Indicates whether or not the content is protected with PlayReady DRM.
 */
@property (nonatomic, assign, readonly) BOOL isProtected;

/**
 The status of the rights installed for the content (if any).
 */
@property (nonatomic, assign, readonly) DARightsStatus rightsStatus;

/**
 The start date set in the license (nil when none has been specified).
 */
@property (nonatomic, retain, readonly) NSDate *licenseStartDate;

/**
 The expiration date set in the license (nil when none has been specified).
 */
@property (nonatomic, retain, readonly) NSDate *licenseEndDate;

/**
 Indicates whether or not the rights will only expire after the first use
 
 Note: In this case the expiration date is not known until after the rights
 consumption has began (i.e. the playback has started).
 */
@property (nonatomic, assign, readonly) BOOL rightsExpireAfterFirstUse;

/**
 List of audio track names (as NSString's) available in the content.
 
 Note: currently only Smooth Streaming streams support this feature.
 */
@property (nonatomic, retain, readonly) NSArray* audioTrackNames;

@end
