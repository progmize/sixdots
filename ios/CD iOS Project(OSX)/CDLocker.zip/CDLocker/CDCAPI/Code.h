//
//  Code.h
//  Chicago
//
//  Created by louie on 8/18/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//



@interface Code : NSObject {
  NSString *isGlobal;
  NSString *name;
  int numericCode;  
}

@property (copy) NSString *isGlobal;
@property (copy) NSString *name;
@property int numericCode;

@end
