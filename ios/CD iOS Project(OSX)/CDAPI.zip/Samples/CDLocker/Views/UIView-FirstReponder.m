//
//  UIView-FirstReponder.m
//  Chicago
//
//  Created by louie on 8/11/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "UIView-FirstReponder.h"


@implementation UIView (FirstResponder)

- (UIView *)findFirstResponder {
  if (self.isFirstResponder) {
    return self;     
  }
  
  UIView *firstResponderView = nil;
  for (UIView *subView in self.subviews) {
    if ([subView isFirstResponder]) {  
      firstResponderView = subView;
      break;
    }
  }
  return firstResponderView;
}

@end
