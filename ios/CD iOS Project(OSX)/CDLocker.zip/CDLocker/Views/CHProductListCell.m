//
// CHProductListCell.m
// Chicago
//
// Created by Derr on 8/10/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHProductListCell.h"
#import "CHFeaturedProductView.h"
#import "Product.h"
#import "PurchasProductDelegate.h"

@implementation CHProductListCell

- (id)initWithReuseIdentifier:(NSString *)reuseId {
  if ((self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseId])) {
    self.productView = [[CHFeaturedProductView alloc] initWithFrame:CGRectMake(0, 0, 320, 130)];
    self.productView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		[self.contentView addSubview:self.productView];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
  }
	
  return self;
}

- (void)setDelegate:(id <PurchasProductDelegate>)theDelegate {
	self.productView.delegate = theDelegate;
}

- (id<PurchasProductDelegate>)delegate {
	return self.productView.delegate;
}

- (void)setLibraryItem:(BOOL)isLibItem {
	self.productView.libraryItem = isLibItem;
}
- (BOOL)libraryItem {
	return self.productView.libraryItem;
}

- (void)setProduct:(Product *)theProduct {
	[self.productView setProduct:theProduct];
}



@synthesize productView = ch_productView;
@end
