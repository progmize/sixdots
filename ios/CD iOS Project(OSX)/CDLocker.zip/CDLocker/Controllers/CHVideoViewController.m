//
// CHVideoViewController.m
// Chicago
//
// Created by Derr on 8/19/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "CHVideoViewController.h"
#import "Product.h"
#import "CHAPIOperation.h"
#import "CHAPIOperationQueue.h"
#import <MediaPlayer/MediaPlayer.h>

@implementation CHVideoViewController

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)init {
    if ((self = [super initWithNibName:@"CHVideoView" bundle:nil])) {
        self.hidesBottomBarWhenPushed = YES;
        popWhenAppears = NO;
    }
    
    return self;
}

- (void)cleanup {
	ch_progressHUD = nil;
	ch_moviePlayerController = nil;
}

- (void) viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.product.name;
	CHAPIOperation *op = [CHAPIOperation operationToViewProductContent:self.product];
	op.delegate = self;
    NSLog(@"operationCount = %d", [[CHAPIOperationQueue sharedCHAPIOperationQueue] operationCount]);
    //[[CHAPIOperationQueue sharedCHAPIOperationQueue] cancelAllOperations];
	[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
	
	// show loading....
	self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
	//[self.progressHUD release];
	[self.view addSubview:self.progressHUD];
	
	self.progressHUD.labelText = NSLocalizedString(@"MEDIA_VIDEO_LOADING", @"Loading...");
	[self.progressHUD show:YES];
	
	watchdogTimer = [NSTimer scheduledTimerWithTimeInterval:5.0f
													  target:self
													selector:@selector(watchdogTimerSelector)
													userInfo:nil
													 repeats:YES];
	watchdogCounter = 0;
}

- (void)viewDidUnload {
	[self cleanup];

	if ([watchdogTimer isValid]) [watchdogTimer invalidate];
	
	[super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated {
	[super viewWillDisappear:animated];
	
	if ([watchdogTimer isValid]) [watchdogTimer invalidate];
}

- (void)watchdogTimerSelector {
	if (watchdogCounter++ < 5) {
		if ([[CHAPIOperationQueue sharedCHAPIOperationQueue] operationCount] == 0) {
			CHAPIOperation *op = [CHAPIOperation operationToViewProductContent:self.product];
			op.delegate = self;
			[[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
		}
	} else {
		UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Error"
															message:@"Unable to load video."
														   delegate:self
												  cancelButtonTitle:@"OK"
												  otherButtonTitles:nil];
		[alertView show];
	}
}

- (void)petWatchdog {
	if ([watchdogTimer isValid]) [watchdogTimer invalidate];	
}

- (void) viewDidAppear:(BOOL)animated {
    //NSLog(@"CHVideoViewController -viewDidAppear:");
    [super viewDidAppear:animated];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return interfaceOrientation == UIInterfaceOrientationLandscapeRight;
}

- (void)dealloc {
	[self cleanup];
}


#pragma mark -
#pragma mark CDClientDelegate

- (void)productContentRetrieved:(ContentItem *)contentItem {
	if ([watchdogTimer isValid]) [watchdogTimer invalidate];
	
    //NSLog(@"CHVideoViewController -productContentRetrieved:");
	////NSLog(@"video view: vid locked and loaded!");
    NSURL *contentURL = [URLFactory escapedURLWithString:[contentItem.contentURL stringByAddingPercentEscapesUsingEncoding:NSASCIIStringEncoding]];
    
    if ([MPMoviePlayerController instancesRespondToSelector:@selector(view)]) {
        // iOS 4.0
        self.moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL: contentURL];
		
		[[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlaybackStateChanged:)
                                                     name:MPMoviePlayerPlaybackStateDidChangeNotification
                                                   object:self.moviePlayerController];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(movieFinishedCallback:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:self.moviePlayerController];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(movieFinishedCallback:)
                                                     name:MPMoviePlayerDidExitFullscreenNotification
                                                   object:self.moviePlayerController];
        
        UIView *movieView = [self.moviePlayerController view];
        
        [movieView setFrame: CGRectMake(0, 0, 480, 320)];
        
		oldDeviceOrientation = [[UIDevice currentDevice] orientation];
        CGAffineTransform landscapeTransform;
        landscapeTransform = CGAffineTransformMakeRotation(M_PI/2.0);
        landscapeTransform = CGAffineTransformTranslate(landscapeTransform, 80, 80);
		
        [movieView setTransform: landscapeTransform];
        self.moviePlayerController.scalingMode = MPMovieScalingModeAspectFit;
        self.moviePlayerController.fullscreen = TRUE;
        self.moviePlayerController.controlStyle = MPMovieControlStyleFullscreen;
        self.moviePlayerController.shouldAutoplay = TRUE;
        
        [[[UIApplication sharedApplication] keyWindow] addSubview:movieView];
    } else {
        // iOS 3.x
        self.moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:contentURL];
        // this notif exists in 2.0+
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(movieFinishedCallback:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:self.moviePlayerController];
        
        [self.moviePlayerController play];
    }
}

- (void)productContentRetrievalFailedWithFault:(Fault *)fault {
	if ([watchdogTimer isValid]) [watchdogTimer invalidate];

    //NSLog(@"CHVideoViewController -productContentRetrievalFailedWithFault:%@", fault);
    
    UIAlertView *av = nil;
    if ([fault isSessionTimeout]) {
        [self showLoginView];
    } else if ([fault isAccessToContentDenied]) {
        av = [[UIAlertView alloc] initWithTitle:@"Content expired" message:@"Your access to this content has expired." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    } else {
        av = [[UIAlertView alloc] initWithTitle:@"Error retrieving video" message:fault.displayMessage delegate:self cancelButtonTitle:NSLocalizedString(@"DONE_BUTTON_TEXT", @"Done") otherButtonTitles:nil];
    }
    
    if (av) {
        [av show];
    }
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
	[self dismissModalViewControllerAnimated:NO];
}


#pragma mark MPMoviePlayerController notifications
- (void)moviePlaybackStateChanged:(NSNotification*) notification {
	//NSLog(@"movie playing");
	
	switch (self.moviePlayerController.playbackState) {
		case MPMoviePlaybackStatePlaying:
			[self.progressHUD hide:YES];
			break;
		default:
			break;
	}
}


- (void)movieFinishedCallback:(NSNotification*) notification {
    //NSLog(@"CHVideoViewController -movieFinishedCallback:");
    // just stop observing everything. Otherwise we have to conditionalize this for 3.2+ vs. < 3.2
	[[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [self.moviePlayerController stop];
    if ([self.moviePlayerController respondsToSelector:@selector(view)]) {
        [self.moviePlayerController.view removeFromSuperview];
    }
    self.moviePlayerController = nil;
    
    // end of Fix for ticket #64
    NSError *error = [[notification userInfo] objectForKey:@"error"];
    if (error) {
        UIAlertView *av = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"ERROR_MEDIA_PLAYBACK", @"Movie playback failed") message:[error localizedDescription] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [av show];
    }
	[self dismissModalViewControllerAnimated:NO];
}


#pragma mark -
#pragma mark CHLoginViewControllerDelegate
- (void) loginCancelled {
    popWhenAppears = YES;
}

@synthesize progressHUD = ch_progressHUD, product = ch_product, moviePlayerController = ch_moviePlayerController;
@end
