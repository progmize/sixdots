var protocol_license_acquisition_delegate-p =
[
    [ "performDelegatedLicenseAcquisition:withChallenge:", "protocol_license_acquisition_delegate-p.html#af6f425c95f14d935111bb14029ba4864", null ],
    [ "performDelegatedJoinDomain:withChallenge:", "protocol_license_acquisition_delegate-p.html#ad0352b269db2c6ec178e68682a036775", null ]
];