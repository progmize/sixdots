//
//  CHChooseChallengeQuestionViewController.h
//  Chicago
//
//  Created by louie on 8/18/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kCHChooseAPassword NSLocalizedString(@"CONTROL_PASSWORD_RETRIEVAL_CHALLENGE_QUESTION", "Choose a password")

@protocol CHChooseChallengeQuestionViewControllerDelegate;

@interface CHChooseChallengeQuestionViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
  UITableView *ch_tableView;
  NSArray *codes;
  NSString *selectedChallengeQuestion;
  id <CHChooseChallengeQuestionViewControllerDelegate> __unsafe_unretained delegate;
}

@property (nonatomic, strong) IBOutlet UITableView *tableView;
@property (strong) NSArray *codes;
@property (unsafe_unretained) id <CHChooseChallengeQuestionViewControllerDelegate> delegate;
@property (copy) NSString *selectedChallengeQuestion;

@end

@protocol CHChooseChallengeQuestionViewControllerDelegate
- (void)userChoseChallengeQuestion:(NSString *)question;
@end

