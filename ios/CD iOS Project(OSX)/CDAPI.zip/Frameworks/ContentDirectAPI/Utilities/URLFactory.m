//
//  URLFactory.m
//  Chicago
//
//  Created by louie on 12/6/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "URLFactory.h"


@implementation URLFactory

+ (NSURL *)escapedURLWithString:(NSString *)urlString {
  NSString *escapedURLString = [urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
  return [NSURL URLWithString:escapedURLString];
}

@end
