//
//  Code.m
//  Chicago
//
//  Created by louie on 8/18/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "Code.h"


@implementation Code

@synthesize isGlobal;
@synthesize name;
@synthesize numericCode;


- (NSString *)description {
  return [NSString stringWithFormat:@"Code #%d name:%@", self.numericCode, self.name];
}

@end
