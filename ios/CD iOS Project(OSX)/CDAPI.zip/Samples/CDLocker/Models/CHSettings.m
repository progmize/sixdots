//
//  CHSettings.m
//  Chicago
//
//  Created by Brian CookCHe on 9/7/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHSettings.h"
#import "SFHFKeychainUtils.h"
#import "SynthesizeSingleton.h"

#define kCHDeviceID                   @"CH_DEVICE_ID"
#define kCHDeviceAuthenticationkCHey  @"CH_DEVICE_AUTHENTICATION_kCHEY"
#define kCHSubscriberID               @"CH_SUBSCRIBER_ID"
#define kCHLoginName                  @"CH_LOGIN_NAME"

@implementation CHSettings

SYNTHESIZE_SINGLETON_FOR_CLASS(CHSettings);

- (NSString *)deviceIDForLogin:(NSString *)aLogin {
  NSError *error = nil;
  if (aLogin == nil) {
    aLogin = kCHDeviceID;
  } else {
    aLogin = [aLogin stringByAppendingString:kCHDeviceID];
  }
  NSString *ret = [SFHFKeychainUtils getPasswordForUsername:@"Chicago" andServiceName:aLogin error:&error];
  if (ret == nil) {
    ret = [SFHFKeychainUtils getPasswordForUsername:@"Chicago" andServiceName:kCHDeviceID error:&error];
  }
  return ret;
}


- (void) setDeviceID:(NSString *)aDeviceID forLogin:(NSString *)aLogin {
  NSError *error = nil;
  aLogin = [aLogin stringByAppendingString:kCHDeviceID];
  [SFHFKeychainUtils storeUsername:@"Chicago" andPassword:aDeviceID forServiceName:aLogin updateExisting:YES error:&error];  
}


- (NSString *)deviceAuthenticationKey {
  NSError *error;
  return [SFHFKeychainUtils getPasswordForUsername:@"Chicago" andServiceName:kCHDeviceAuthenticationkCHey error:&error];
}


- (void) setDeviceAuthenticationKey:(NSString *)aDeviceAuthenticationkCHey {
  NSError *error = nil;
  [SFHFKeychainUtils storeUsername:@"Chicago" andPassword:aDeviceAuthenticationkCHey forServiceName:kCHDeviceAuthenticationkCHey updateExisting:YES error:&error];    
}


- (NSString *)subscriberID {
  NSError *error;
  return [SFHFKeychainUtils getPasswordForUsername:@"Chicago" andServiceName:kCHSubscriberID error:&error];
}


- (void) setSubscriberID:(NSString *)aSubscriberID {
  NSError *error = nil;
  [SFHFKeychainUtils storeUsername:@"Chicago" andPassword:aSubscriberID forServiceName:kCHSubscriberID updateExisting:YES error:&error];    
}


- (NSString *)loginName {
  return [[NSUserDefaults standardUserDefaults] objectForKey:kCHLoginName];
}


- (void) setLoginName:(NSString *)loginName {
  [[NSUserDefaults standardUserDefaults] setObject:loginName forKey:kCHLoginName];
  [[NSUserDefaults standardUserDefaults] synchronize];
}


- (void) removeSubscriberInfo {
  NSError *error = nil;
  [SFHFKeychainUtils deleteItemForUsername:@"Chicago" andServiceName:kCHDeviceID error:&error];
  [SFHFKeychainUtils deleteItemForUsername:@"Chicago" andServiceName:kCHDeviceAuthenticationkCHey error:&error];
  [SFHFKeychainUtils deleteItemForUsername:@"Chicago" andServiceName:kCHSubscriberID error:&error];
  self.loginName = nil;
}

@end
