//
//  ImageCache.h
//  Chicago
//
//  Created by louie on 8/12/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

// Clients should register for ImageDownloaded notification.

#import <Foundation/Foundation.h>

@interface ImageCache : NSObject {
  NSOperationQueue *operationQueue;
  NSMutableDictionary *urlsToImages;
}

+ (ImageCache *)sharedImageCache;

// This may return nil if the image has not been cached yet.
// Clients should check again when ImageDownloaded notification is received.
- (UIImage *)imageForURL:(NSURL *)url scaled:(BOOL)shouldScale;
- (UIImage *)imageForURL:(NSURL *)url;

- (void)storeImage:(UIImage *)image forURL:(NSURL *)url;
@end