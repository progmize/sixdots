//
//  AVPlayerViewController.m
//
//  This implementation is partially based on Apple's example code at:
//  http://developer.apple.com/library/ios/#samplecode/AVPlayerDemo/
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import "AVPlayerViewController.h"
#import "SampleViewController.h"

static void *AVPlayerItemStatusObservationContext = &AVPlayerItemStatusObservationContext;

@interface AVPlayerViewController(Player)
- (void)play:(id)sender;
- (void)pause:(id)sender;
- (void)initScrubberTimer;
- (void)showPlayButton;
- (void)mPauseButton;
- (void)syncPlayPauseButtons;
- (void)disablePlayerButtons;
- (void)enablePlayerButtons;
- (void)syncScrubber;
- (void)beginScrubbing:(id)sender;
- (void)scrub:(id)sender;
- (void)endScrubbing:(id)sender;
- (BOOL)isScrubbing;
- (void)enableScrubber;
- (void)disableScrubber;
- (void)removePlayerTimeObserver;
- (BOOL)isPlaying;
- (CMTime)playerItemDuration;
- (void)assetFailedToPrepareForPlayback:(NSError *)error;
@end

@implementation AVPlayerViewController

@synthesize player;

// UI elements
@synthesize mToolbar, mPlayButton, mPauseButton, mDoneButton, mScrubber, playerView;

- (void)dealloc
{
    NSLog(@"deallocating AVPlayerViewController");
    
    // remove observers
    [[NSNotificationCenter defaultCenter] removeObserver:self];
	[player removeObserver:self forKeyPath:@"currentItem.status"];
    
	[player pause];
	[player release];
    
    // UI stuff
    [mToolbar release];
    [mPlayButton release];
    [mPauseButton release];
    [mDoneButton release];
    [mScrubber release];
    [playerView release];
    
    [super dealloc];
}

- (id)initWithAVPlayerItem:(AVPlayerItem *)playerItem
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) 
    {
        self = [super initWithNibName:@"AVPlayerView" bundle:nil];
    } 
    else
    {
        self = [super initWithNibName:@"AVPlayerView-iPad" bundle:nil];
    }
    
    if (self)
    {
        self.player = [AVPlayer playerWithPlayerItem:playerItem];
    }
    
    return self;
}

- (IBAction)play:(id)sender
{
	/* If we are at the end of the movie, we must seek to the beginning first 
     before starting playback. */
	if (YES == seekToZeroBeforePlay) 
	{
		seekToZeroBeforePlay = NO;
		[player seekToTime:kCMTimeZero];
	}
    
	[player play];
	
    [self mPauseButton];    
}

- (IBAction)pause:(id)sender
{
	[player pause];
    
    [self showPlayButton];
}

- (IBAction)done:(id)sender
{    
    [player pause];
    
    // tell the parent view controller that we're done with this content so that it can do clean up if needed
    SampleViewController *parentViewController = nil;
    
    if ([self respondsToSelector:@selector(presentingViewController)])
    {
        // iOS 5.0 and later only
        parentViewController = (SampleViewController *)[self presentingViewController];
    }
    else
    {
        // previous versions of iOS
        parentViewController = (SampleViewController *)[self parentViewController];
    }
    
    // the parent will also take care of dismissing this modal view controller
    [parentViewController stopPlayback];
}

#pragma mark - View lifecycle

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidLoad
{
    UIBarButtonItem *scrubberItem = [[UIBarButtonItem alloc] initWithCustomView:mScrubber];
    UIBarButtonItem *flexItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];

    // put the initial set of items in the toolbar
    mToolbar.items = [NSArray arrayWithObjects:mPlayButton, flexItem, scrubberItem, mDoneButton, nil];
    [scrubberItem release];
    [flexItem release];

    // prepare the player rendering view
    [playerView setPlayer:player];
    
    // observe the status of the player's item to know when to begin to play  
    [player addObserver:self forKeyPath:@"currentItem.status" options:(NSKeyValueObservingOptionInitial | NSKeyValueObservingOptionNew) context:AVPlayerItemStatusObservationContext];

    // to mimic the behavior of the MPMoviePlayerController, we dismiss the view when the player reaches the end of the movie
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(done:)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:player.currentItem];
    
    [super viewDidLoad];   
}

- (void)viewWillDisappear:(BOOL)animated
{
    // if the view controller is being popped out (i.e. the parent is dismissing it) then make 
    // sure we remove the timer otherwise it does not get deallocated
    [self removePlayerTimeObserver];
    
    [super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
	return YES;
}

#pragma mark KVO observer

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if (context == AVPlayerItemStatusObservationContext)
	{
		[self syncPlayPauseButtons];
        
        switch (player.currentItem.status)
        {
            case AVPlayerItemStatusUnknown:
            {
                /* Indicates that the status of the player is not yet known because 
                 it has not tried to load new media resources for playback */                
                [self removePlayerTimeObserver];
                [self syncScrubber];                
                [self disableScrubber];
                [self disablePlayerButtons];
            }
            break;
                
            case AVPlayerItemStatusReadyToPlay:
            {
                /* Once the AVPlayerItem becomes ready to play, i.e. 
                 [playerItem status] == AVPlayerItemStatusReadyToPlay,
                 its duration can be fetched from the item. */                
                [self initScrubberTimer];                
                [self enableScrubber];
                [self enablePlayerButtons];
                
                // autoplay
                [self play:nil];
            }
            break;
                
            case AVPlayerItemStatusFailed:
            {
                AVPlayerItem *playerItem = player.currentItem;                
                [self assetFailedToPrepareForPlayback:playerItem.error];
            }
            break;
        }
	}
    else
	{
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}

@end


@implementation AVPlayerViewController(Player)

#pragma mark Button Action Methods

- (IBAction)play:(id)sender
{
	/* If we are at the end of the movie, we must seek to the beginning first 
     before starting playback. */
	if (YES == seekToZeroBeforePlay) 
	{
		seekToZeroBeforePlay = NO;
		[player seekToTime:kCMTimeZero];
	}
    
	[player play];
	
    [self mPauseButton];    
}

- (IBAction)pause:(id)sender
{
	[player pause];
    
    [self showPlayButton];
}

#pragma mark Play, Stop buttons

/* Show the stop button in the movie player controller. */
-(void)mPauseButton
{
    NSMutableArray *toolbarItems = [NSMutableArray arrayWithArray:[mToolbar items]];
    [toolbarItems replaceObjectAtIndex:0 withObject:mPauseButton];
    mToolbar.items = toolbarItems;
}

/* Show the play button in the movie player controller. */
-(void)showPlayButton
{
    NSMutableArray *toolbarItems = [NSMutableArray arrayWithArray:[mToolbar items]];
    [toolbarItems replaceObjectAtIndex:0 withObject:mPlayButton];
    mToolbar.items = toolbarItems;
}

/* If the media is playing, show the stop button; otherwise, show the play button. */
- (void)syncPlayPauseButtons
{
	if ([self isPlaying])
	{
        [self mPauseButton];
	}
	else
	{
        [self showPlayButton];        
	}
}

-(void)enablePlayerButtons
{
    self.mPlayButton.enabled = YES;
    self.mPauseButton.enabled = YES;
}

-(void)disablePlayerButtons
{
    self.mPlayButton.enabled = NO;
    self.mPauseButton.enabled = NO;
}


#pragma mark Movie scrubber control

/* ---------------------------------------------------------
 **  Methods to handle manipulation of the movie scrubber control
 ** ------------------------------------------------------- */

/* Requests invocation of a given block during media playback to update the movie scrubber control. */
-(void)initScrubberTimer
{
	double interval = .1f;	
	
	CMTime playerDuration = [self playerItemDuration];
	if (CMTIME_IS_INVALID(playerDuration)) 
	{
		return;
	} 
	double duration = CMTimeGetSeconds(playerDuration);
	if (isfinite(duration))
	{
		CGFloat width = CGRectGetWidth([mScrubber bounds]);
		interval = 0.5f * duration / width;
	}
    
	/* Update the scrubber during normal playback. */
	mTimeObserver = [[player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(interval, NSEC_PER_SEC) 
                                                           queue:NULL /* If you pass NULL, the main queue is used. */
                                                      usingBlock:^(CMTime time) 
                      {
                          [self syncScrubber];
                      }] retain];
    
}

/* Set the scrubber based on the player current time. */
- (void)syncScrubber
{
	CMTime playerDuration = [self playerItemDuration];
	if (CMTIME_IS_INVALID(playerDuration)) 
	{
		mScrubber.minimumValue = 0.0;
		return;
	} 
    
	double duration = CMTimeGetSeconds(playerDuration);
	if (isfinite(duration))
	{
		float minValue = [mScrubber minimumValue];
		float maxValue = [mScrubber maximumValue];
		double time = CMTimeGetSeconds([player currentTime]);
		
		[mScrubber setValue:(maxValue - minValue) * time / duration + minValue];
	}
}

/* The user is dragging the movie controller thumb to scrub through the movie. */
- (IBAction)beginScrubbing:(id)sender
{
	mRestoreAfterScrubbingRate = [player rate];
	[player setRate:0.f];
	
	/* Remove previous timer. */
	[self removePlayerTimeObserver];
}

/* Set the player current time to match the scrubber position. */
- (IBAction)scrub:(id)sender
{
	if ([sender isKindOfClass:[UISlider class]])
	{
		UISlider* slider = sender;
		
		CMTime playerDuration = [self playerItemDuration];
		if (CMTIME_IS_INVALID(playerDuration)) {
			return;
		} 
		
		double duration = CMTimeGetSeconds(playerDuration);
		if (isfinite(duration))
		{
			float minValue = [slider minimumValue];
			float maxValue = [slider maximumValue];
			float value = [slider value];
			
			double time = duration * (value - minValue) / (maxValue - minValue);
			
			[player seekToTime:CMTimeMakeWithSeconds(time, NSEC_PER_SEC)];
		}
	}
}

/* The user has released the movie thumb control to stop scrubbing through the movie. */
- (IBAction)endScrubbing:(id)sender
{
	if (!mTimeObserver)
	{
		CMTime playerDuration = [self playerItemDuration];
		if (CMTIME_IS_INVALID(playerDuration)) 
		{
			return;
		} 
		
		double duration = CMTimeGetSeconds(playerDuration);
		if (isfinite(duration))
		{
			CGFloat width = CGRectGetWidth([mScrubber bounds]);
			double tolerance = 0.5f * duration / width;
            
			mTimeObserver = [[player addPeriodicTimeObserverForInterval:CMTimeMakeWithSeconds(tolerance, NSEC_PER_SEC) queue:NULL usingBlock:
                              ^(CMTime time)
                              {
                                  [self syncScrubber];
                              }] retain];
		}
	}
    
	if (mRestoreAfterScrubbingRate)
	{
		[player setRate:mRestoreAfterScrubbingRate];
		mRestoreAfterScrubbingRate = 0.f;
	}
}

- (BOOL)isScrubbing
{
	return mRestoreAfterScrubbingRate != 0.f;
}

-(void)enableScrubber
{
    self.mScrubber.enabled = YES;
}

-(void)disableScrubber
{
    self.mScrubber.enabled = NO;    
}

#pragma mark Playback events

- (BOOL)isPlaying
{
	return mRestoreAfterScrubbingRate != 0.f || [player rate] != 0.f;
}

/* ---------------------------------------------------------
 **  Get the duration for a AVPlayerItem. 
 ** ------------------------------------------------------- */

- (CMTime)playerItemDuration
{
	AVPlayerItem *playerItem = [player currentItem];
	if (playerItem.status == AVPlayerItemStatusReadyToPlay)
	{
        /* 
         NOTE:
         Because of the dynamic nature of HTTP Live Streaming Media, the best practice 
         for obtaining the duration of an AVPlayerItem object has changed in iOS 4.3. 
         Prior to iOS 4.3, you would obtain the duration of a player item by fetching 
         the value of the duration property of its associated AVAsset object. However, 
         note that for HTTP Live Streaming Media the duration of a player item during 
         any particular playback session may differ from the duration of its asset. For 
         this reason a new key-value observable duration property has been defined on 
         AVPlayerItem.
         
         See the AV Foundation Release Notes for iOS 4.3 for more information.
         */		
        
		return([playerItem duration]);
	}
	
	return(kCMTimeInvalid);
}


/* Cancels the previously registered time observer. */
-(void)removePlayerTimeObserver
{
	if (mTimeObserver)
	{
		[player removeTimeObserver:mTimeObserver];
		[mTimeObserver release];
		mTimeObserver = nil;
	}
}

#pragma mark -
#pragma mark Error Handling - Preparing Assets for Playback Failed

/* --------------------------------------------------------------
 **  Called when an asset fails to prepare for playback for any of
 **  the following reasons:
 ** 
 **  1) values of asset keys did not load successfully, 
 **  2) the asset keys did load successfully, but the asset is not 
 **     playable
 **  3) the item did not become ready to play. 
 ** ----------------------------------------------------------- */

-(void)assetFailedToPrepareForPlayback:(NSError *)error
{
    [self removePlayerTimeObserver];
    [self syncScrubber];
    [self disableScrubber];
    [self disablePlayerButtons];
    
    // Display the error
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"SampleApp"
														message:[error localizedFailureReason]
													   delegate:nil
											  cancelButtonTitle:@"OK"
											  otherButtonTitles:nil];
	[alertView show];
	[alertView release];
    
    // tell the parent to dismiss this view controller
    [self done:nil];
}

@end


#pragma mark AVPlayerView implementation

@implementation AVPlayerView

+ (Class)layerClass 
{    
    return [AVPlayerLayer class];    
}

- (AVPlayer*)player 
{    
    return [(AVPlayerLayer *)[self layer] player];    
}

- (void)setPlayer:(AVPlayer *)thePlayer 
{    
    AVPlayerLayer *playerLayer = (AVPlayerLayer*)[self layer];
    
    playerLayer.player = thePlayer;
    
    /* Specifies that the player should preserve the video’s aspect ratio and 
     fit the video within the layer’s bounds. */
	playerLayer.videoGravity = AVLayerVideoGravityResizeAspect;
}

@end

