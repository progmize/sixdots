//
// CHResetpasswordViewController.m
// Chicago
//
// Created by Brian Cooke on 8/21/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import "CHResetpasswordViewController.h"
#import "MBProgressHUD.h"
#import "CHAPIOperation.h"
#import "TKLabelTextFieldCell.h"
#import "TKTextViewCell.h"
#import "CHLoginViewController.h"

enum {
  kQuestionSection,
  kFormSection,
  kSectionCount
};


@interface CHResetpasswordViewController (private)
- (void)resetPassword;
@end



@implementation CHResetpasswordViewController


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
	return UIInterfaceOrientationIsLandscape(toInterfaceOrientation) || toInterfaceOrientation == UIInterfaceOrientationPortrait;
}

- (id)initWithLogin:(NSString *)aLogin {
  if ((self = [super initWithStyle:UITableViewStyleGrouped])) {
    self.login = aLogin;
  }

  return self;
}


- (void)viewDidLoad {
  [super viewDidLoad];
	
  self.title = NSLocalizedString(@"LOGIN_RESET_PASSWORD_BUTTON", @"Reset Password");
  
	self.view.backgroundColor = kCHViewBackgroundColor;
  self.tableView.backgroundColor = kCHTableViewBackgroundColor;
  
  self.progressHUD = [[MBProgressHUD alloc] initWithView:self.view];
  [self.view addSubview:self.progressHUD];
  self.progressHUD.labelText = NSLocalizedString(@"PROCESSING_DATA_RETRIEVING_QUESTION_TEXT", @"Retrieving question...");
  [self.progressHUD show:YES];

  self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"CONTROL_LOGIN_RESET", @"Reset") style:UIBarButtonItemStyleDone target:self action:@selector(resetPassword:)];

  self.answerCell                              = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"answer"];
  self.answerCell.field.autocorrectionType     = UITextAutocorrectionTypeNo;
  self.answerCell.field.autocapitalizationType = UITextAutocapitalizationTypeNone;
  self.answerCell.label.text                   = NSLocalizedString(@"CONTROL_PASSWORD_RETRIEVAL_CHALLENGE_RESPONSE", @"answer");
  self.answerCell.field.delegate               = self;
  self.answerCell.field.returnKeyType          = UIReturnKeyNext;

  self.passwordCell                              = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"password"];
  self.passwordCell.field.autocorrectionType     = UITextAutocorrectionTypeNo;
  self.passwordCell.field.autocapitalizationType = UITextAutocapitalizationTypeNone;
  self.passwordCell.field.secureTextEntry        = YES;
  self.passwordCell.label.text                   = NSLocalizedString(@"CONTROL_LOGIN_FORM_PASSWORD", @"password");
  self.passwordCell.field.delegate               = self;
  self.passwordCell.field.returnKeyType          = UIReturnKeyNext;

  self.passwordConfirmationCell                              = [[TKLabelTextFieldCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"passwordConfirmation"];
  self.passwordConfirmationCell.field.autocorrectionType     = UITextAutocorrectionTypeNo;
  self.passwordConfirmationCell.field.autocapitalizationType = UITextAutocapitalizationTypeNone;
  self.passwordConfirmationCell.field.secureTextEntry        = YES;
  self.passwordConfirmationCell.label.text                   = NSLocalizedString(@"CONTROL_CREDENTIAL_CONFIRM_PASSWORD", @"again");
  self.passwordConfirmationCell.field.delegate               = self;
  self.passwordConfirmationCell.field.returnKeyType          = UIReturnKeySend;


  CHAPIOperation * op = [CHAPIOperation operationToRetrieveChallengeQuestionForLogin:self.login];
  op.delegate = self;
  [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];
}


- (void)viewDidAppear:(BOOL)animated {
  [super viewDidAppear:animated];
}


#pragma mark -
#pragma mark actions
- (IBAction)resetPassword:(id)sender {
  if (([self.answerCell.field.text length] == 0) ||
      ([self.passwordCell.field.text length] == 0) ||
      ([self.passwordConfirmationCell.field.text length] == 0)) {
    [Fault showWithTitle:NSLocalizedString(@"ERROR_ALL_FIELD_REQUIRED_MESSAGE", @"All fields required") andMessage:NSLocalizedString(@"ERROR_ALL_FIELD_REQUIRED_MESSAGE", @"All fields required")];
    return;
  }

  if ([self.passwordCell.field.text isEqualToString:self.passwordConfirmationCell.field.text] == NO) {
    [Fault showWithTitle:NSLocalizedString(@"CONTROL_GENERAL_PASSWORD_NOT_MATCH", @"Passwords do not match") andMessage:NSLocalizedString(@"CONTROL_GENERAL_PASSWORD_NOT_MATCH", @"Passwords do not match")];
    return;
  }

  CHAPIOperation * op = [CHAPIOperation operationToResetPasswordForLogin:self.login challengeResponse:self.answerCell.field.text newPassword:self.passwordCell.field.text];
  op.delegate = self;
  [[CHAPIOperationQueue sharedCHAPIOperationQueue] addOperation:op];

  self.progressHUD.labelText = NSLocalizedString(@"PROCESSING_DATA_RESETTING_TEXT", @"Resetting...");
  [self.progressHUD show:YES];
}


#pragma mark -
#pragma mark UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
  if (textField == self.answerCell.field) {
    [self.passwordCell.field becomeFirstResponder];
  } else if (textField == self.passwordCell.field) {
    [self.passwordConfirmationCell becomeFirstResponder];
  } else if (textField == self.passwordConfirmationCell.field) {
    [textField resignFirstResponder];
    [self resetPassword:self];
  }

  return YES;
}


#pragma mark -
#pragma mark tableview datasource & delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
  return kSectionCount;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  if (section == kQuestionSection) {
    return 1;
  }

  return 3;
}


- (UITableViewCell *)questionCell {
  static NSString * cellID = @"questionCellID";
  TKTextViewCell  * cell   = (TKTextViewCell *)[self.tableView dequeueReusableCellWithIdentifier:cellID];

  if (cell == nil) {
    cell = [[TKTextViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
  }

  cell.textView.text = self.question;

  return cell;
}


- (TKLabelTextFieldCell *)formCellForRow:(NSInteger)row {
  switch (row) {
    case 0:
      return self.answerCell;

    case 1:
      return self.passwordCell;

    case 2:
      return self.passwordConfirmationCell;
  }
  return nil;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == kQuestionSection) {
    return [self questionCell];
  } else {
    return (UITableViewCell *)[self formCellForRow:indexPath.row];
  }
}


- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
  return nil;
}


- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
  // delete if every cell is selectable
  return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
  if (indexPath.section == kQuestionSection) {
    return 100.0;
  }

  return 44.0;
}


#pragma mark -
#pragma mark UIAlertViewDelegate
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
  [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark -
#pragma mark CDCLientDelegate
- (void)retrievePasswordChallengeCompleted:(NSString *)challenge {
  self.question = challenge;
  [self.progressHUD hide:YES];
  [self.tableView reloadData];
}


- (void)retrievePasswordChallengeFailedWithFault:(Fault *)fault {
  [self.progressHUD hide:YES];

  UIAlertView * av = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"FORGOT_PASSWORD_ERROR_MESSAGE_CHALLEGE_QUESTION_RETRIEVAL_FAILED", @"Challenge retrieval failed") message:[NSString stringWithFormat:NSLocalizedString(@"FORGOT_PASSWORD_ERROR_MESSAGE_CHALLEGE_QUESTION_RETRIEVAL_FAILED", @"Unable to retrieve the challenge question "), self.login] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
  [av show];
}


- (void)resetPasswordCompleted {
  [self.progressHUD hide:YES];

  for (UIViewController * vc in self.navigationController.viewControllers) {
    if ([vc isKindOfClass:[CHLoginViewController class]]) {
      // TODO: remove the abuse of the knowledge of the usernameCell field in the LoginViewController?
      ((CHLoginViewController *)vc).usernameCell.field.text = self.login;
      [self.navigationController popToViewController:vc animated:YES];
    }
  }

  [Fault showWithTitle:NSLocalizedString(@"LOGIN_PASSWORD_SENT_CONFIRMATION_TITLE", @"Password Reset") andMessage:NSLocalizedString(@"LOGIN_PASSWORD_SENT_CONFIRMATION_MESSAGE", @"You're password has been reset, now login.")];
}


- (void)resetPasswordFailedWithFault:(Fault *)fault {
  [self.progressHUD hide:YES];

  if ([[fault typeName] isEqualToString:@"ContentDirect.AuthorizationManagement.Contract.Fault.AccessDenied"]) {
    [Fault showWithTitle:NSLocalizedString(@"MESSAGE_PASSWORD_CHALLENGE_ANSWER_INVALID", @"Incorrect answer") andMessage:NSLocalizedString(@"MESSAGE_PASSWORD_CHALLENGE_ANSWER_INVALID", @"Your answer was incorrect, please try again")];
  } else if ([[fault typeName] isEqualToString:@"ContentDirect.AuthorizationManagement.Contract.Fault.PasswordStrengthViolation"]) {
    [Fault showWithTitle:NSLocalizedString(@"LOGIN_FORM_ENTER_VALID_PASSWORD", @"Password invalid") andMessage:NSLocalizedString(@"ERROR_MESSAGE_PASSWORD_LENGTH", @"Your new password must be at least 4 characters long. Please try again.")];
  } else {
    [fault showWithTitle:NSLocalizedString(@"ERROR_MESSAGE_GENERAL_ERROR", @"Unknown error")];
  }
}

#pragma mark - 
#pragma mark Fix for multi-treaded view controller error
/*- (oneway void)release
{
    if (![NSThread isMainThread]) {
        [self performSelectorOnMainThread:@selector(release) withObject:nil waitUntilDone:NO];
    } else {
        [super release];
    }
}*/

@synthesize login = ch_login, question = ch_question, progressHUD = ch_progressHUD, answerCell = ch_answerCell, passwordCell = ch_passwordCell, passwordConfirmationCell = ch_passwordConfirmationCell;

@end
