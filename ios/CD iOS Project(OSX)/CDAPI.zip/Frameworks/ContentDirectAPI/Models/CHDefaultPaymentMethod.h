//
//  CHDefaultPaymentMethod.h
//  Chicago
//
//  Created by Derr on 9/23/10.
//  Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CHDefaultPaymentMethod : NSObject {
	NSString *ch_defaultInstrumentId;
}

+ (CHDefaultPaymentMethod *)sharedCHDefaultPaymentMethod;

@property (nonatomic, strong)NSString *defaultInstrumentId;

@end
