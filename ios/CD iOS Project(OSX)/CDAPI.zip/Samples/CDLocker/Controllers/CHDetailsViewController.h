//
// CHDetailsViewController.h
// Chicago
//
// Created by Derr on 8/7/10.
// Copyright 2010 Push.IO Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PurchasProductDelegate.h"
#import "CDClient.h"
#import "CHBaseViewController.h"

@class MBProgressHUD;
@class Product;
@class ProductCategory;
@class CHProductDetailCell;

@interface CHDetailsViewController : CHBaseViewController <UITableViewDataSource, UITableViewDelegate, CDClientDelegate> {
  MBProgressHUD       * ch_progressHUD;
  Product             * ch_product;
  ProductCategory     * ch_category;
  NSArray             * ch_relatedProducts;
  UITableView         * ch_tableView;
  CHProductDetailCell * ch_detailCell;
}

@property (nonatomic, strong) MBProgressHUD        * progressHUD;
@property (nonatomic, strong) Product              * product;
@property (nonatomic, strong) ProductCategory      * category;
@property (nonatomic, strong) NSArray              * relatedProducts;
@property (nonatomic, strong) IBOutlet UITableView * tableView;
@property (nonatomic, strong) CHProductDetailCell  * detailCell;

@end
