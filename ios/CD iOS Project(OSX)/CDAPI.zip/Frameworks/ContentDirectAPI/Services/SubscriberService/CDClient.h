// ContentDirect Client
// This will allow ContentDirect-specific calls to be made instead of using the generic POXClient.
//
// CDClient.h
// ContentDirect POX API
//
// Created by Luis de la Rosa on 7/28/10.
// Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Fault.h"
#import "Product.h"
#import "ContentItem.h"
#import "PaymentInstrument.h"

@protocol CDClientDelegate;
@class POXClient;
@interface CDClient : NSObject {
    id <CDClientDelegate> delegate;
    
    POXClient *poxClient;
    
    // Keep track of the current sessionID
    NSString *sessionID;
    
    NSString *deviceType;
    NSString *distributionChannel;
    NSString *systemID;
    
    // TODO implement this and make this into an enum
    // 0 = anonymous, 1 = unauthenticated, device registered, 2 = authenticated
    NSString *sessionAuthenticationType;
    
    NSString          *subscriberID;
    NSMutableArray    *paymentInstruments;
    PaymentInstrument *paymentInstrumentBeingRemoved;
    NSMutableArray    *subscriberProducts;
    
    NSString *loginName;
    
    NSString *deviceID;
    NSString *deviceAuthenticationKey;
    NSString *storefrontURLString;
	NSString *physicalDeviceTypeCode;
    NSString *language;
	NSString *playlistGUID;
	
	BOOL enableInAppPurchase;
}

@property (strong) id <CDClientDelegate> delegate;
@property (strong) PaymentInstrument    *paymentInstrumentBeingRemoved;
@property (copy) NSString               *sessionID;
@property (copy) NSString               *sessionAuthenticationType;
@property (copy) NSString               *deviceType;
@property (copy) NSString               *distributionChannel;
@property (copy) NSString               *systemID;
@property (copy) NSString               *subscriberID;
@property (copy) NSString               *loginName;
@property (copy) NSString               *deviceID;
@property (copy) NSString               *deviceAuthenticationKey;
@property (copy) NSString				*physicalDeviceTypeCode;
@property (copy) NSString               *storefrontURLString;
@property (strong) NSString				*playlistGUID;
@property (nonatomic, copy) NSString *language;
@property (nonatomic) BOOL enableInAppPurchase;


- (id)initWithDeviceType:(NSString *)aDeviceType 
	 distributionChannel:(NSString *)aDistributionChannel 
				systemID:(NSString *)aSystemID 
	 storefrontURLString:(NSString *)aURLString
  physicalDeviceTypeCode:(NSString *)aPhysicalDeviceTypeCode 
				language:(NSString *)aLanguage
				playlistGUID:(NSString *)playlistGUID
	 enableInAppPurchase:(BOOL)enableInAppPurchase;

- (BOOL)loggedIn;      // possible to be in, but not authenticated (no purchase allowed)
- (BOOL)authenticated; // able to purchase

- (NSArray *)paymentInstruments;
- (NSMutableArray *)subscriberProducts;
- (void) productPurchased:(Product *)aProduct;

- (BOOL)doesUserOwnProduct:(Product *)aProduct;

- (BOOL)deviceHasBeenRegisteredPreviously;

// TODO do we need a variation that passes in a ProductCategory?
// parentCategoryID can be nil to retrieve the top level categories.
// TODO do we need a variation that explicitly gets the top level categories?
- (void)retrieveCategoriesByParentCategoryID:(NSString *)parentCategoryID;

// TODO do we need a variation that passes in a ProductCategory?
// maximumNumberOfProductsToReturn specifies how many products to return.
// TODO Ask Ani about paging - that is, limit to 10 but start at 11, for ezample to get products 11-21
- (void)retrieveProductsByCategoryID:(NSString *)categoryID limit:(int)maximumNumberOfProductsToReturn;
- (void)retrieveProductsByCategoryID:(NSString *)categoryID page:(int)page itemsPerPage:(int)itemsPerPage;

-(void)retrieveFeaturedProducts;

// Demonstration of using the classes to call backend API.
// We could also have used productID and pricingPlanID, but a Product contains both of these.
- (void)viewProductContent:(Product *)product;
- (void)createSubscriberWithLogin:(NSString *)login email:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname password:(NSString *)password challengeQuestion:(NSString *)challengeQuestion challengeAnswer:(NSString *)challengeAnswer;
- (void)updateSubscriberWithId:(NSString *)anID email:(NSString *)email firstName:(NSString *)fname lastName:(NSString *)lname;
- (void)loginWithLogin:(NSString *)login password:(NSString *)password;

// PREREQUISITE CALL: successful loginWithLogin:password:
- (void)retrieveSubscriberInfo;
- (void)calculateOrderQuoteForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument;
- (void)calculateOrderQuoteWithDefaultPaymentInstrumentForProduct:(Product *)product;
- (void)submitOrderForProduct:(Product *)product paymentInstrument:(PaymentInstrument *)paymentInstrument;
- (void)submitOrderForProductWithItunes:(Product *)product receiptCode:(NSString *)receiptCode;
- (void)submitOrderWithDefaultPaymentInstrumentForProduct:(Product *)product;
- (void)fullTextSearchForString:(NSString *)searchString forPage:(NSInteger)page pageSize:(NSInteger)pageSize;
- (void)retrieveProductByProductID:(NSString *)productID;
- (void)retrieveCodes;
- (void)registerSubscriberDevice;
- (void)removeSubscriberDeviceWithSubscriberID:(NSString *)aSubscriberID;
- (void)retrievePasswordChallenge:(NSString *)login;
- (void)resetPasswordForLogin:(NSString *)login challengeResponse:(NSString *)challengeResponse newPassword:(NSString *)newPassword;
- (void)sendNewPasswordForLogin:(NSString *)login;

// pass nil for fields not to update
- (void)updateCredentialsForSubscriberId:(NSString *)anID currentPassword:(NSString *)curPassword newPassword:(NSString *)newPassword newLogin:(NSString *)newLogin newChallengeQuestion:(NSString *)newChallengeQuestion newChallengeResponse:(NSString *)newChallengeResponse;
- (void)createPaymentInstrument:(PaymentInstrument *)paymentInstrument;
- (void)sendPing;
- (void)removePaymentInstrument:(PaymentInstrument *)paymentInstrument;
- (void)retrieveSubscriberProducts;
@end

@protocol CDClientDelegate <NSObject> 
@optional

- (void)createSubscriberCompleted:(NSString *)newUserId;
- (void)createSubscriberFailedWithFault:(Fault *)fault;

- (void)loginCompletedWithSessionID:(NSString *)sessionID usingTemporaryPassword:(BOOL)wasTempPass;
- (void)loginFailedWithFault:(Fault *)fault;

- (void)logoutCompletedSuccess;
- (void)logoutCompletedFault:(Fault *)fault;

- (void)updateSubscriberCompleted:(NSString *)response;
- (void)updateSubscriberFailedWithFault:(Fault *)fault;

- (void)productCategoriesRetrieved:(NSArray *)productCategoryArray;
- (void)productCategoryRetrievalFailedWithFault:(Fault *)fault;

- (void) retrieveFeaturedItemsSucceeded:(NSArray *)productArray;
- (void) retrieveFeaturedItemsWithFault:(Fault *)fault;

- (void)productsRetrieved:(NSArray *)productArray;
- (void)productRetrievalFailedWithFault:(Fault *)fault;

- (void)productContentRetrieved:(ContentItem *)contentItem;
- (void)productContentRetrievalFailedWithFault:(Fault *)fault;

- (void)retrieveSubscriberInfoSucceeded:(NSDictionary *)subscriberInfo;
- (void)retrieveSubscriberInfoFailedWithFault:(Fault *)fault;

- (void)fullTextSearchResults:(NSArray *)products pageCount:(int)pages;
- (void)fullTextSearchFailedWithFault:(Fault *)fault;

- (void)codesRetrieved:(NSDictionary *)codeTypesToCodes;
- (void)codeRetrievalFailedWithFault:(Fault *)fault;

- (void)deviceRegisteredWithDeviceID:(NSString *)deviceID deviceAuthenticationKey:(NSString *)deviceAuthenticationKey subscriberID:(NSString *)subscriberID;
- (void)deviceRegistrationFailedWithFault:(Fault *)fault;

- (void)retrievePasswordChallengeCompleted:(NSString *)challenge;
- (void)retrievePasswordChallengeFailedWithFault:(Fault *)fault;

- (void)resetPasswordCompleted;
- (void)resetPasswordFailedWithFault:(Fault *)fault;

- (void)calculateOrderSucceededWithSubtotal:(NSString *)subtotal tax:(NSString *)tax total:(NSString *)total;
- (void)calculateOrdedFailedWithFault:(Fault *)fault;

- (void)newPasswordSentTo:(NSString *)email;
- (void)newPasswordFailed:(Fault *)fault;

- (void)submitOrderSucceeded;
- (void)submitOrderFailedWithFault:(Fault *)fault;

- (void)updateCredentialsSucceeded;
- (void)updateCredentialsFailedWithFault:(Fault *)fault;

- (void)createPaymentInstrumentSucceeded:(PaymentInstrument *)paymentInstrument;
- (void)createPaymentInstrumentFailedWithFault:(Fault *)fault;

- (void)pingSuccess;
- (void)pingFailedWithFault:(Fault *)fault;

- (void)removePaymentInstrumentSucceeded;
- (void)removePaymentInstrumentFailedWithFault:(Fault *)fault;

- (void)retrievedSubscriberProducts:(NSArray *)products;
- (void)retrievedSubscriberProductsFailedWithFault:(Fault *)aFault;

- (void)deviceUnregistrationSucceeded;
- (void)deviceUnregistrationFailedWithFault:(Fault *)aFault;

- (void)retrieveProductSucceededWithLicense:(NSString *)license             externalTypeValue:(NSString *)externalTypeValue 
    recommendedProducts:(NSArray *)productArray 
    runtime:(NSString *)runtime 
    product:(Product *)product;
- (void)retrieveProductFailedWithFault:(Fault *)aFault;
@end
