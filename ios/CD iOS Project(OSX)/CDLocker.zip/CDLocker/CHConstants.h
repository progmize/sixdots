#define kCHTableViewBackgroundColor ([UIColor clearColor])
#define kCHViewBackgroundColor ([UIColor colorWithWhite:0.5 alpha:1.])
