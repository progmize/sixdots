//
//  ContentItem.h
//  SampleApp
//
//  Copyright (c) 2012 AuthenTec Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DADataTypes.h"


@interface ContentItem : NSObject 
{
	NSString *contentName;
	NSString *contentURL;
	DAContentType contentType;
}

@property (copy) NSString *contentName;
@property (copy) NSString *contentURL;
@property (assign) DAContentType contentType;

+ (ContentItem *)contentItemWithName:(NSString *)name andURL:(NSString *)url ofType:(DAContentType)type;

@end
