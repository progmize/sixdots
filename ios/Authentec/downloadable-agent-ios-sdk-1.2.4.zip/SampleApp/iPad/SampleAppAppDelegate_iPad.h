//
//  SampleAppAppDelegate_iPad.h
//  SampleApp
//
//  Copyright (c) 2010 AuthenTec Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SampleAppAppDelegate.h"

@interface SampleAppAppDelegate_iPad : SampleAppAppDelegate {
}


@end
