#!/bin/bash

if [ "${ANDROID_HOME}" = "" ] ; then
  echo "Please set the environment variable ANDROID_HOME to point to you installation of the Android SDK"
  echo "export ANDROID_HOME=path/to/android/sdk"
  exit 1
fi

CURR_DIR=`pwd`

if [ ! -f "${CURR_DIR}/BUILDING.txt" ] && [ ! -f "${CURR_DIR}/build.sh" ] && [ ! "${CURR_DIR}/AndroidManifest.xml" ] ; then
  echo "Not 100% sure you are running this script from within the DRM Agent reference implementation directory"
  echo "Current directory is $CURR_DIR and I expected to find the files BUILDING.txt, build.sh and AndroidManifest.xml"
  echo "in here.  Please verify your location!"
  exit 1
fi

if [ ! -d ../maven2-repository ] ; then
  echo "Could not find the directory named 'maven2-repository' up in the directory structure.  Suspect I am not"
  echo "running within the DRM Agent distribution directory structure.  Please verify your location"
  exit 1
fi

echo ########################################################################
echo #
echo # AuthenTec Inc 2011
echo #
echo # Initiating build of DRM Agent Downloadable - Reference Implementation
echo #
echo ########################################################################

mvn clean install -Dmaven.repo.local=`pwd`/../maven2-repository