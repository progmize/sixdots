//
//  Product.m
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import "Product.h"
#import "Code.h"


static NSString *defaultLicenseText = @"Licensing Info Not Available";
static NSString *INSTANTLY_VIEWABLE_NOT_ORDERABLE = @"InstantlyViewableNotOrderable";

@implementation Product

@synthesize productID;
@synthesize name;
@synthesize shortDescription;
@synthesize peerRating;
@synthesize peerRatingCount;
@synthesize thumbnailURL;
//@synthesize pricingPlanID;
@synthesize purchasedPricingPlanID;
@synthesize guidanceRatingCode;
@synthesize orderingType;
@synthesize price;
@synthesize isOnDemand;
@synthesize expirationDate;
@synthesize licensingText;
@synthesize isSubscription;
@synthesize pricingPlanReferenceID;
@synthesize availabilityEndDate;
@synthesize availabilityStartDate;

// iPad-specific
@synthesize imageURL;
@synthesize hasPreview;
@synthesize previewID;
@synthesize runtime;


- (id)init {
    if ((self = [super init])) {
      licensingText = defaultLicenseText;
    }
    return self;
}

- (NSString *)pricingPlanID {
    return pricingPlanID;
}
- (void)setPricingPlanID:(NSString *)pricingPlanId
{
    pricingPlanID = pricingPlanId;
    NSLog(@"setting product pricingPlaID to %@", pricingPlanID);
}

- (NSString *)description {
  return [NSString stringWithFormat:@"Product ID:%@ Name:%@ Rating:%d Price:%@ Purchased  isOnDemand:%d Expires: %@", self.productID, self.name, self.peerRating, self.price, self.isOnDemand, self.expirationDate];
}

- (NSString *)formattedPrice {
	if ([self.pricingPlanID isEqualToString:@"1832"] && ![[CDServiceFacade sharedCDServiceFacade] isAuthenticated]) {
		return @"LOGIN";
  } else if ([self isFree]) {
    return @"View";
  } else {
    return [Product formatAsCurrency:self.price];    
  }
}

- (BOOL)isFree {
  return [self.price isEqual:@"0.0"] || [self.price isEqual:@"0.0000"];  
}

- (BOOL)isExpired {
  if (self.expirationDate == nil || [self.expirationDate compare:[NSDate date]] == NSOrderedDescending) {
    return NO;
  }
  return YES;
}

- (BOOL)isPurchased
{
	if(purchasedPricingPlanID != nil)
	{
		return YES;
	}
	return NO;
}

- (BOOL)isInstantlyViewableNotOrderable
{
	if(orderingType	!= nil && [orderingType isEqualToString:INSTANTLY_VIEWABLE_NOT_ORDERABLE])
	{
		return YES;
	}
	return NO;
}

+ (NSString *)formatAsCurrency:(NSString *)decimalString {
  
  NSDecimalNumber *decimal = [NSDecimalNumber decimalNumberWithString:decimalString];
  NSNumberFormatter *currencyFormatter = [[NSNumberFormatter alloc] init];
  [currencyFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
  NSString *currencyString = [currencyFormatter stringFromNumber:decimal];
  return currencyString;
}

- (BOOL) isEqual:(id)object {
  return ([object isKindOfClass:[Product class]] && [[self productID] isEqual:[object productID]]);
}

- (NSString *) getGuidanceRatingLabel
{
	// Get the codes
	NSArray *codes = [[CDServiceFacade sharedCDServiceFacade] ratingCodes];
	
	// For each code check the id against what we have for this product
	for (int i = 0; i<[codes count]; i++) 
	{
		Code *code = [codes objectAtIndex:i]; // the current code
		if([code numericCode] == [self guidanceRatingCode]) // If the code matches return the name as the label
		{
			return code.name;
		}
	}
	
	// Or we have nothing to display 
	return @"";
}

@end
