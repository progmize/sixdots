//
//  ContentItem.h
//  ContentDirect POX API
//
//  Created by Luis de la Rosa on 7/29/10.
//  Copyright 2010 CSG Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface ContentItem : NSObject {
  NSString *contentItemID;
  NSString *contentURL;
}

@property (copy) NSString *contentItemID;
@property (copy) NSString *contentURL;

@end
